
/**
 * Client
**/

import * as runtime from './runtime/library.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model eventos
 * This model contains row level security and requires additional setup for migrations. Visit https://pris.ly/d/row-level-security for more info.
 */
export type eventos = $Result.DefaultSelection<Prisma.$eventosPayload>
/**
 * Model inscricoes
 * This model contains row level security and requires additional setup for migrations. Visit https://pris.ly/d/row-level-security for more info.
 */
export type inscricoes = $Result.DefaultSelection<Prisma.$inscricoesPayload>
/**
 * Model local
 * This model contains row level security and requires additional setup for migrations. Visit https://pris.ly/d/row-level-security for more info.
 */
export type local = $Result.DefaultSelection<Prisma.$localPayload>
/**
 * Model tipo_perfil
 * This model contains row level security and requires additional setup for migrations. Visit https://pris.ly/d/row-level-security for more info.
 */
export type tipo_perfil = $Result.DefaultSelection<Prisma.$tipo_perfilPayload>
/**
 * Model usuarios
 * This model contains row level security and requires additional setup for migrations. Visit https://pris.ly/d/row-level-security for more info.
 */
export type usuarios = $Result.DefaultSelection<Prisma.$usuariosPayload>

/**
 * ##  Prisma Client ʲˢ
 *
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient()
 * // Fetch zero or more Eventos
 * const eventos = await prisma.eventos.findMany()
 * ```
 *
 *
 * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
 */
export class PrismaClient<
  ClientOptions extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  const U = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   *
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient()
   * // Fetch zero or more Eventos
   * const eventos = await prisma.eventos.findMany()
   * ```
   *
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
   */

  constructor(optionsArg ?: Prisma.Subset<ClientOptions, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): PrismaClient;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;


  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/concepts/components/prisma-client/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>


  $extends: $Extensions.ExtendsHook<"extends", Prisma.TypeMapCb<ClientOptions>, ExtArgs, $Utils.Call<Prisma.TypeMapCb<ClientOptions>, {
    extArgs: ExtArgs
  }>>

      /**
   * `prisma.eventos`: Exposes CRUD operations for the **eventos** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Eventos
    * const eventos = await prisma.eventos.findMany()
    * ```
    */
  get eventos(): Prisma.eventosDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.inscricoes`: Exposes CRUD operations for the **inscricoes** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Inscricoes
    * const inscricoes = await prisma.inscricoes.findMany()
    * ```
    */
  get inscricoes(): Prisma.inscricoesDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.local`: Exposes CRUD operations for the **local** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Locals
    * const locals = await prisma.local.findMany()
    * ```
    */
  get local(): Prisma.localDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.tipo_perfil`: Exposes CRUD operations for the **tipo_perfil** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Tipo_perfils
    * const tipo_perfils = await prisma.tipo_perfil.findMany()
    * ```
    */
  get tipo_perfil(): Prisma.tipo_perfilDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.usuarios`: Exposes CRUD operations for the **usuarios** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Usuarios
    * const usuarios = await prisma.usuarios.findMany()
    * ```
    */
  get usuarios(): Prisma.usuariosDelegate<ExtArgs, ClientOptions>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql



  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
   * Metrics
   */
  export type Metrics = runtime.Metrics
  export type Metric<T> = runtime.Metric<T>
  export type MetricHistogram = runtime.MetricHistogram
  export type MetricHistogramBucket = runtime.MetricHistogramBucket

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 6.19.3
   * Query Engine version: c2990dca591cba766e3b7ef5d9e8a84796e47ab7
   */
  export type PrismaVersion = {
    client: string
  }

  export const prismaVersion: PrismaVersion

  /**
   * Utility Types
   */


  export import Bytes = runtime.Bytes
  export import JsonObject = runtime.JsonObject
  export import JsonArray = runtime.JsonArray
  export import JsonValue = runtime.JsonValue
  export import InputJsonObject = runtime.InputJsonObject
  export import InputJsonArray = runtime.InputJsonArray
  export import InputJsonValue = runtime.InputJsonValue

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? P : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    eventos: 'eventos',
    inscricoes: 'inscricoes',
    local: 'local',
    tipo_perfil: 'tipo_perfil',
    usuarios: 'usuarios'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]


  export type Datasources = {
    db?: Datasource
  }

  interface TypeMapCb<ClientOptions = {}> extends $Utils.Fn<{extArgs: $Extensions.InternalArgs }, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs'], ClientOptions extends { omit: infer OmitOptions } ? OmitOptions : {}>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> = {
    globalOmitOptions: {
      omit: GlobalOmitOptions
    }
    meta: {
      modelProps: "eventos" | "inscricoes" | "local" | "tipo_perfil" | "usuarios"
      txIsolationLevel: Prisma.TransactionIsolationLevel
    }
    model: {
      eventos: {
        payload: Prisma.$eventosPayload<ExtArgs>
        fields: Prisma.eventosFieldRefs
        operations: {
          findUnique: {
            args: Prisma.eventosFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eventosPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.eventosFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eventosPayload>
          }
          findFirst: {
            args: Prisma.eventosFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eventosPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.eventosFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eventosPayload>
          }
          findMany: {
            args: Prisma.eventosFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eventosPayload>[]
          }
          create: {
            args: Prisma.eventosCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eventosPayload>
          }
          createMany: {
            args: Prisma.eventosCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.eventosCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eventosPayload>[]
          }
          delete: {
            args: Prisma.eventosDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eventosPayload>
          }
          update: {
            args: Prisma.eventosUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eventosPayload>
          }
          deleteMany: {
            args: Prisma.eventosDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.eventosUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.eventosUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eventosPayload>[]
          }
          upsert: {
            args: Prisma.eventosUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eventosPayload>
          }
          aggregate: {
            args: Prisma.EventosAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateEventos>
          }
          groupBy: {
            args: Prisma.eventosGroupByArgs<ExtArgs>
            result: $Utils.Optional<EventosGroupByOutputType>[]
          }
          count: {
            args: Prisma.eventosCountArgs<ExtArgs>
            result: $Utils.Optional<EventosCountAggregateOutputType> | number
          }
        }
      }
      inscricoes: {
        payload: Prisma.$inscricoesPayload<ExtArgs>
        fields: Prisma.inscricoesFieldRefs
        operations: {
          findUnique: {
            args: Prisma.inscricoesFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$inscricoesPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.inscricoesFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$inscricoesPayload>
          }
          findFirst: {
            args: Prisma.inscricoesFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$inscricoesPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.inscricoesFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$inscricoesPayload>
          }
          findMany: {
            args: Prisma.inscricoesFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$inscricoesPayload>[]
          }
          create: {
            args: Prisma.inscricoesCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$inscricoesPayload>
          }
          createMany: {
            args: Prisma.inscricoesCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.inscricoesCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$inscricoesPayload>[]
          }
          delete: {
            args: Prisma.inscricoesDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$inscricoesPayload>
          }
          update: {
            args: Prisma.inscricoesUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$inscricoesPayload>
          }
          deleteMany: {
            args: Prisma.inscricoesDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.inscricoesUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.inscricoesUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$inscricoesPayload>[]
          }
          upsert: {
            args: Prisma.inscricoesUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$inscricoesPayload>
          }
          aggregate: {
            args: Prisma.InscricoesAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateInscricoes>
          }
          groupBy: {
            args: Prisma.inscricoesGroupByArgs<ExtArgs>
            result: $Utils.Optional<InscricoesGroupByOutputType>[]
          }
          count: {
            args: Prisma.inscricoesCountArgs<ExtArgs>
            result: $Utils.Optional<InscricoesCountAggregateOutputType> | number
          }
        }
      }
      local: {
        payload: Prisma.$localPayload<ExtArgs>
        fields: Prisma.localFieldRefs
        operations: {
          findUnique: {
            args: Prisma.localFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$localPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.localFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$localPayload>
          }
          findFirst: {
            args: Prisma.localFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$localPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.localFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$localPayload>
          }
          findMany: {
            args: Prisma.localFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$localPayload>[]
          }
          create: {
            args: Prisma.localCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$localPayload>
          }
          createMany: {
            args: Prisma.localCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.localCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$localPayload>[]
          }
          delete: {
            args: Prisma.localDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$localPayload>
          }
          update: {
            args: Prisma.localUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$localPayload>
          }
          deleteMany: {
            args: Prisma.localDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.localUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.localUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$localPayload>[]
          }
          upsert: {
            args: Prisma.localUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$localPayload>
          }
          aggregate: {
            args: Prisma.LocalAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateLocal>
          }
          groupBy: {
            args: Prisma.localGroupByArgs<ExtArgs>
            result: $Utils.Optional<LocalGroupByOutputType>[]
          }
          count: {
            args: Prisma.localCountArgs<ExtArgs>
            result: $Utils.Optional<LocalCountAggregateOutputType> | number
          }
        }
      }
      tipo_perfil: {
        payload: Prisma.$tipo_perfilPayload<ExtArgs>
        fields: Prisma.tipo_perfilFieldRefs
        operations: {
          findUnique: {
            args: Prisma.tipo_perfilFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$tipo_perfilPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.tipo_perfilFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$tipo_perfilPayload>
          }
          findFirst: {
            args: Prisma.tipo_perfilFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$tipo_perfilPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.tipo_perfilFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$tipo_perfilPayload>
          }
          findMany: {
            args: Prisma.tipo_perfilFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$tipo_perfilPayload>[]
          }
          create: {
            args: Prisma.tipo_perfilCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$tipo_perfilPayload>
          }
          createMany: {
            args: Prisma.tipo_perfilCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.tipo_perfilCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$tipo_perfilPayload>[]
          }
          delete: {
            args: Prisma.tipo_perfilDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$tipo_perfilPayload>
          }
          update: {
            args: Prisma.tipo_perfilUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$tipo_perfilPayload>
          }
          deleteMany: {
            args: Prisma.tipo_perfilDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.tipo_perfilUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.tipo_perfilUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$tipo_perfilPayload>[]
          }
          upsert: {
            args: Prisma.tipo_perfilUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$tipo_perfilPayload>
          }
          aggregate: {
            args: Prisma.Tipo_perfilAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateTipo_perfil>
          }
          groupBy: {
            args: Prisma.tipo_perfilGroupByArgs<ExtArgs>
            result: $Utils.Optional<Tipo_perfilGroupByOutputType>[]
          }
          count: {
            args: Prisma.tipo_perfilCountArgs<ExtArgs>
            result: $Utils.Optional<Tipo_perfilCountAggregateOutputType> | number
          }
        }
      }
      usuarios: {
        payload: Prisma.$usuariosPayload<ExtArgs>
        fields: Prisma.usuariosFieldRefs
        operations: {
          findUnique: {
            args: Prisma.usuariosFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usuariosPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.usuariosFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usuariosPayload>
          }
          findFirst: {
            args: Prisma.usuariosFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usuariosPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.usuariosFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usuariosPayload>
          }
          findMany: {
            args: Prisma.usuariosFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usuariosPayload>[]
          }
          create: {
            args: Prisma.usuariosCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usuariosPayload>
          }
          createMany: {
            args: Prisma.usuariosCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.usuariosCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usuariosPayload>[]
          }
          delete: {
            args: Prisma.usuariosDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usuariosPayload>
          }
          update: {
            args: Prisma.usuariosUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usuariosPayload>
          }
          deleteMany: {
            args: Prisma.usuariosDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.usuariosUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.usuariosUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usuariosPayload>[]
          }
          upsert: {
            args: Prisma.usuariosUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usuariosPayload>
          }
          aggregate: {
            args: Prisma.UsuariosAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateUsuarios>
          }
          groupBy: {
            args: Prisma.usuariosGroupByArgs<ExtArgs>
            result: $Utils.Optional<UsuariosGroupByOutputType>[]
          }
          count: {
            args: Prisma.usuariosCountArgs<ExtArgs>
            result: $Utils.Optional<UsuariosCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<"define", Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasources?: Datasources
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasourceUrl?: string
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Shorthand for `emit: 'stdout'`
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events only
     * log: [
     *   { emit: 'event', level: 'query' },
     *   { emit: 'event', level: 'info' },
     *   { emit: 'event', level: 'warn' }
     *   { emit: 'event', level: 'error' }
     * ]
     * 
     * / Emit as events and log to stdout
     * og: [
     *  { emit: 'stdout', level: 'query' },
     *  { emit: 'stdout', level: 'info' },
     *  { emit: 'stdout', level: 'warn' }
     *  { emit: 'stdout', level: 'error' }
     * 
     * ```
     * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/logging#the-log-option).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
    /**
     * Instance of a Driver Adapter, e.g., like one provided by `@prisma/adapter-planetscale`
     */
    adapter?: runtime.SqlDriverAdapterFactory | null
    /**
     * Global configuration for omitting model fields by default.
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   omit: {
     *     user: {
     *       password: true
     *     }
     *   }
     * })
     * ```
     */
    omit?: Prisma.GlobalOmitConfig
  }
  export type GlobalOmitConfig = {
    eventos?: eventosOmit
    inscricoes?: inscricoesOmit
    local?: localOmit
    tipo_perfil?: tipo_perfilOmit
    usuarios?: usuariosOmit
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type CheckIsLogLevel<T> = T extends LogLevel ? T : never;

  export type GetLogType<T> = CheckIsLogLevel<
    T extends LogDefinition ? T['level'] : T
  >;

  export type GetEvents<T extends any[]> = T extends Array<LogLevel | LogDefinition>
    ? GetLogType<T[number]>
    : never;

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'updateManyAndReturn'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */


  /**
   * Count Type EventosCountOutputType
   */

  export type EventosCountOutputType = {
    inscricoes: number
  }

  export type EventosCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    inscricoes?: boolean | EventosCountOutputTypeCountInscricoesArgs
  }

  // Custom InputTypes
  /**
   * EventosCountOutputType without action
   */
  export type EventosCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the EventosCountOutputType
     */
    select?: EventosCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * EventosCountOutputType without action
   */
  export type EventosCountOutputTypeCountInscricoesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: inscricoesWhereInput
  }


  /**
   * Count Type LocalCountOutputType
   */

  export type LocalCountOutputType = {
    eventos: number
  }

  export type LocalCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    eventos?: boolean | LocalCountOutputTypeCountEventosArgs
  }

  // Custom InputTypes
  /**
   * LocalCountOutputType without action
   */
  export type LocalCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the LocalCountOutputType
     */
    select?: LocalCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * LocalCountOutputType without action
   */
  export type LocalCountOutputTypeCountEventosArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: eventosWhereInput
  }


  /**
   * Count Type Tipo_perfilCountOutputType
   */

  export type Tipo_perfilCountOutputType = {
    usuarios: number
  }

  export type Tipo_perfilCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    usuarios?: boolean | Tipo_perfilCountOutputTypeCountUsuariosArgs
  }

  // Custom InputTypes
  /**
   * Tipo_perfilCountOutputType without action
   */
  export type Tipo_perfilCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Tipo_perfilCountOutputType
     */
    select?: Tipo_perfilCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * Tipo_perfilCountOutputType without action
   */
  export type Tipo_perfilCountOutputTypeCountUsuariosArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: usuariosWhereInput
  }


  /**
   * Count Type UsuariosCountOutputType
   */

  export type UsuariosCountOutputType = {
    eventos: number
    inscricoes: number
  }

  export type UsuariosCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    eventos?: boolean | UsuariosCountOutputTypeCountEventosArgs
    inscricoes?: boolean | UsuariosCountOutputTypeCountInscricoesArgs
  }

  // Custom InputTypes
  /**
   * UsuariosCountOutputType without action
   */
  export type UsuariosCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UsuariosCountOutputType
     */
    select?: UsuariosCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * UsuariosCountOutputType without action
   */
  export type UsuariosCountOutputTypeCountEventosArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: eventosWhereInput
  }

  /**
   * UsuariosCountOutputType without action
   */
  export type UsuariosCountOutputTypeCountInscricoesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: inscricoesWhereInput
  }


  /**
   * Models
   */

  /**
   * Model eventos
   */

  export type AggregateEventos = {
    _count: EventosCountAggregateOutputType | null
    _avg: EventosAvgAggregateOutputType | null
    _sum: EventosSumAggregateOutputType | null
    _min: EventosMinAggregateOutputType | null
    _max: EventosMaxAggregateOutputType | null
  }

  export type EventosAvgAggregateOutputType = {
    id_evento: number | null
    carga_horaria: number | null
    vagas_limite: number | null
    id_usuario: number | null
  }

  export type EventosSumAggregateOutputType = {
    id_evento: number | null
    carga_horaria: number | null
    vagas_limite: number | null
    id_usuario: number | null
  }

  export type EventosMinAggregateOutputType = {
    id_evento: number | null
    titulo: string | null
    descricao: string | null
    palestrante: string | null
    carga_horaria: number | null
    vagas_limite: number | null
    data_inicio: Date | null
    data_fim: Date | null
    hora_inicio: Date | null
    hora_fim: Date | null
    objetivo_pedagogico: string | null
    id_local: string | null
    id_usuario: number | null
  }

  export type EventosMaxAggregateOutputType = {
    id_evento: number | null
    titulo: string | null
    descricao: string | null
    palestrante: string | null
    carga_horaria: number | null
    vagas_limite: number | null
    data_inicio: Date | null
    data_fim: Date | null
    hora_inicio: Date | null
    hora_fim: Date | null
    objetivo_pedagogico: string | null
    id_local: string | null
    id_usuario: number | null
  }

  export type EventosCountAggregateOutputType = {
    id_evento: number
    titulo: number
    descricao: number
    palestrante: number
    carga_horaria: number
    vagas_limite: number
    data_inicio: number
    data_fim: number
    hora_inicio: number
    hora_fim: number
    objetivo_pedagogico: number
    id_local: number
    id_usuario: number
    _all: number
  }


  export type EventosAvgAggregateInputType = {
    id_evento?: true
    carga_horaria?: true
    vagas_limite?: true
    id_usuario?: true
  }

  export type EventosSumAggregateInputType = {
    id_evento?: true
    carga_horaria?: true
    vagas_limite?: true
    id_usuario?: true
  }

  export type EventosMinAggregateInputType = {
    id_evento?: true
    titulo?: true
    descricao?: true
    palestrante?: true
    carga_horaria?: true
    vagas_limite?: true
    data_inicio?: true
    data_fim?: true
    hora_inicio?: true
    hora_fim?: true
    objetivo_pedagogico?: true
    id_local?: true
    id_usuario?: true
  }

  export type EventosMaxAggregateInputType = {
    id_evento?: true
    titulo?: true
    descricao?: true
    palestrante?: true
    carga_horaria?: true
    vagas_limite?: true
    data_inicio?: true
    data_fim?: true
    hora_inicio?: true
    hora_fim?: true
    objetivo_pedagogico?: true
    id_local?: true
    id_usuario?: true
  }

  export type EventosCountAggregateInputType = {
    id_evento?: true
    titulo?: true
    descricao?: true
    palestrante?: true
    carga_horaria?: true
    vagas_limite?: true
    data_inicio?: true
    data_fim?: true
    hora_inicio?: true
    hora_fim?: true
    objetivo_pedagogico?: true
    id_local?: true
    id_usuario?: true
    _all?: true
  }

  export type EventosAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which eventos to aggregate.
     */
    where?: eventosWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of eventos to fetch.
     */
    orderBy?: eventosOrderByWithRelationInput | eventosOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: eventosWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` eventos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` eventos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned eventos
    **/
    _count?: true | EventosCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: EventosAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: EventosSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: EventosMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: EventosMaxAggregateInputType
  }

  export type GetEventosAggregateType<T extends EventosAggregateArgs> = {
        [P in keyof T & keyof AggregateEventos]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateEventos[P]>
      : GetScalarType<T[P], AggregateEventos[P]>
  }




  export type eventosGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: eventosWhereInput
    orderBy?: eventosOrderByWithAggregationInput | eventosOrderByWithAggregationInput[]
    by: EventosScalarFieldEnum[] | EventosScalarFieldEnum
    having?: eventosScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: EventosCountAggregateInputType | true
    _avg?: EventosAvgAggregateInputType
    _sum?: EventosSumAggregateInputType
    _min?: EventosMinAggregateInputType
    _max?: EventosMaxAggregateInputType
  }

  export type EventosGroupByOutputType = {
    id_evento: number
    titulo: string
    descricao: string
    palestrante: string
    carga_horaria: number
    vagas_limite: number
    data_inicio: Date
    data_fim: Date
    hora_inicio: Date
    hora_fim: Date
    objetivo_pedagogico: string | null
    id_local: string | null
    id_usuario: number
    _count: EventosCountAggregateOutputType | null
    _avg: EventosAvgAggregateOutputType | null
    _sum: EventosSumAggregateOutputType | null
    _min: EventosMinAggregateOutputType | null
    _max: EventosMaxAggregateOutputType | null
  }

  type GetEventosGroupByPayload<T extends eventosGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<EventosGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof EventosGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], EventosGroupByOutputType[P]>
            : GetScalarType<T[P], EventosGroupByOutputType[P]>
        }
      >
    >


  export type eventosSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id_evento?: boolean
    titulo?: boolean
    descricao?: boolean
    palestrante?: boolean
    carga_horaria?: boolean
    vagas_limite?: boolean
    data_inicio?: boolean
    data_fim?: boolean
    hora_inicio?: boolean
    hora_fim?: boolean
    objetivo_pedagogico?: boolean
    id_local?: boolean
    id_usuario?: boolean
    usuarios?: boolean | usuariosDefaultArgs<ExtArgs>
    local?: boolean | eventos$localArgs<ExtArgs>
    inscricoes?: boolean | eventos$inscricoesArgs<ExtArgs>
    _count?: boolean | EventosCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["eventos"]>

  export type eventosSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id_evento?: boolean
    titulo?: boolean
    descricao?: boolean
    palestrante?: boolean
    carga_horaria?: boolean
    vagas_limite?: boolean
    data_inicio?: boolean
    data_fim?: boolean
    hora_inicio?: boolean
    hora_fim?: boolean
    objetivo_pedagogico?: boolean
    id_local?: boolean
    id_usuario?: boolean
    usuarios?: boolean | usuariosDefaultArgs<ExtArgs>
    local?: boolean | eventos$localArgs<ExtArgs>
  }, ExtArgs["result"]["eventos"]>

  export type eventosSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id_evento?: boolean
    titulo?: boolean
    descricao?: boolean
    palestrante?: boolean
    carga_horaria?: boolean
    vagas_limite?: boolean
    data_inicio?: boolean
    data_fim?: boolean
    hora_inicio?: boolean
    hora_fim?: boolean
    objetivo_pedagogico?: boolean
    id_local?: boolean
    id_usuario?: boolean
    usuarios?: boolean | usuariosDefaultArgs<ExtArgs>
    local?: boolean | eventos$localArgs<ExtArgs>
  }, ExtArgs["result"]["eventos"]>

  export type eventosSelectScalar = {
    id_evento?: boolean
    titulo?: boolean
    descricao?: boolean
    palestrante?: boolean
    carga_horaria?: boolean
    vagas_limite?: boolean
    data_inicio?: boolean
    data_fim?: boolean
    hora_inicio?: boolean
    hora_fim?: boolean
    objetivo_pedagogico?: boolean
    id_local?: boolean
    id_usuario?: boolean
  }

  export type eventosOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id_evento" | "titulo" | "descricao" | "palestrante" | "carga_horaria" | "vagas_limite" | "data_inicio" | "data_fim" | "hora_inicio" | "hora_fim" | "objetivo_pedagogico" | "id_local" | "id_usuario", ExtArgs["result"]["eventos"]>
  export type eventosInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    usuarios?: boolean | usuariosDefaultArgs<ExtArgs>
    local?: boolean | eventos$localArgs<ExtArgs>
    inscricoes?: boolean | eventos$inscricoesArgs<ExtArgs>
    _count?: boolean | EventosCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type eventosIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    usuarios?: boolean | usuariosDefaultArgs<ExtArgs>
    local?: boolean | eventos$localArgs<ExtArgs>
  }
  export type eventosIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    usuarios?: boolean | usuariosDefaultArgs<ExtArgs>
    local?: boolean | eventos$localArgs<ExtArgs>
  }

  export type $eventosPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "eventos"
    objects: {
      usuarios: Prisma.$usuariosPayload<ExtArgs>
      local: Prisma.$localPayload<ExtArgs> | null
      inscricoes: Prisma.$inscricoesPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id_evento: number
      titulo: string
      descricao: string
      palestrante: string
      carga_horaria: number
      vagas_limite: number
      data_inicio: Date
      data_fim: Date
      hora_inicio: Date
      hora_fim: Date
      objetivo_pedagogico: string | null
      id_local: string | null
      id_usuario: number
    }, ExtArgs["result"]["eventos"]>
    composites: {}
  }

  type eventosGetPayload<S extends boolean | null | undefined | eventosDefaultArgs> = $Result.GetResult<Prisma.$eventosPayload, S>

  type eventosCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<eventosFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: EventosCountAggregateInputType | true
    }

  export interface eventosDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['eventos'], meta: { name: 'eventos' } }
    /**
     * Find zero or one Eventos that matches the filter.
     * @param {eventosFindUniqueArgs} args - Arguments to find a Eventos
     * @example
     * // Get one Eventos
     * const eventos = await prisma.eventos.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends eventosFindUniqueArgs>(args: SelectSubset<T, eventosFindUniqueArgs<ExtArgs>>): Prisma__eventosClient<$Result.GetResult<Prisma.$eventosPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Eventos that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {eventosFindUniqueOrThrowArgs} args - Arguments to find a Eventos
     * @example
     * // Get one Eventos
     * const eventos = await prisma.eventos.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends eventosFindUniqueOrThrowArgs>(args: SelectSubset<T, eventosFindUniqueOrThrowArgs<ExtArgs>>): Prisma__eventosClient<$Result.GetResult<Prisma.$eventosPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Eventos that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eventosFindFirstArgs} args - Arguments to find a Eventos
     * @example
     * // Get one Eventos
     * const eventos = await prisma.eventos.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends eventosFindFirstArgs>(args?: SelectSubset<T, eventosFindFirstArgs<ExtArgs>>): Prisma__eventosClient<$Result.GetResult<Prisma.$eventosPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Eventos that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eventosFindFirstOrThrowArgs} args - Arguments to find a Eventos
     * @example
     * // Get one Eventos
     * const eventos = await prisma.eventos.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends eventosFindFirstOrThrowArgs>(args?: SelectSubset<T, eventosFindFirstOrThrowArgs<ExtArgs>>): Prisma__eventosClient<$Result.GetResult<Prisma.$eventosPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Eventos that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eventosFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Eventos
     * const eventos = await prisma.eventos.findMany()
     * 
     * // Get first 10 Eventos
     * const eventos = await prisma.eventos.findMany({ take: 10 })
     * 
     * // Only select the `id_evento`
     * const eventosWithId_eventoOnly = await prisma.eventos.findMany({ select: { id_evento: true } })
     * 
     */
    findMany<T extends eventosFindManyArgs>(args?: SelectSubset<T, eventosFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$eventosPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Eventos.
     * @param {eventosCreateArgs} args - Arguments to create a Eventos.
     * @example
     * // Create one Eventos
     * const Eventos = await prisma.eventos.create({
     *   data: {
     *     // ... data to create a Eventos
     *   }
     * })
     * 
     */
    create<T extends eventosCreateArgs>(args: SelectSubset<T, eventosCreateArgs<ExtArgs>>): Prisma__eventosClient<$Result.GetResult<Prisma.$eventosPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Eventos.
     * @param {eventosCreateManyArgs} args - Arguments to create many Eventos.
     * @example
     * // Create many Eventos
     * const eventos = await prisma.eventos.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends eventosCreateManyArgs>(args?: SelectSubset<T, eventosCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Eventos and returns the data saved in the database.
     * @param {eventosCreateManyAndReturnArgs} args - Arguments to create many Eventos.
     * @example
     * // Create many Eventos
     * const eventos = await prisma.eventos.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Eventos and only return the `id_evento`
     * const eventosWithId_eventoOnly = await prisma.eventos.createManyAndReturn({
     *   select: { id_evento: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends eventosCreateManyAndReturnArgs>(args?: SelectSubset<T, eventosCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$eventosPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Eventos.
     * @param {eventosDeleteArgs} args - Arguments to delete one Eventos.
     * @example
     * // Delete one Eventos
     * const Eventos = await prisma.eventos.delete({
     *   where: {
     *     // ... filter to delete one Eventos
     *   }
     * })
     * 
     */
    delete<T extends eventosDeleteArgs>(args: SelectSubset<T, eventosDeleteArgs<ExtArgs>>): Prisma__eventosClient<$Result.GetResult<Prisma.$eventosPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Eventos.
     * @param {eventosUpdateArgs} args - Arguments to update one Eventos.
     * @example
     * // Update one Eventos
     * const eventos = await prisma.eventos.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends eventosUpdateArgs>(args: SelectSubset<T, eventosUpdateArgs<ExtArgs>>): Prisma__eventosClient<$Result.GetResult<Prisma.$eventosPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Eventos.
     * @param {eventosDeleteManyArgs} args - Arguments to filter Eventos to delete.
     * @example
     * // Delete a few Eventos
     * const { count } = await prisma.eventos.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends eventosDeleteManyArgs>(args?: SelectSubset<T, eventosDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Eventos.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eventosUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Eventos
     * const eventos = await prisma.eventos.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends eventosUpdateManyArgs>(args: SelectSubset<T, eventosUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Eventos and returns the data updated in the database.
     * @param {eventosUpdateManyAndReturnArgs} args - Arguments to update many Eventos.
     * @example
     * // Update many Eventos
     * const eventos = await prisma.eventos.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Eventos and only return the `id_evento`
     * const eventosWithId_eventoOnly = await prisma.eventos.updateManyAndReturn({
     *   select: { id_evento: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends eventosUpdateManyAndReturnArgs>(args: SelectSubset<T, eventosUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$eventosPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Eventos.
     * @param {eventosUpsertArgs} args - Arguments to update or create a Eventos.
     * @example
     * // Update or create a Eventos
     * const eventos = await prisma.eventos.upsert({
     *   create: {
     *     // ... data to create a Eventos
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Eventos we want to update
     *   }
     * })
     */
    upsert<T extends eventosUpsertArgs>(args: SelectSubset<T, eventosUpsertArgs<ExtArgs>>): Prisma__eventosClient<$Result.GetResult<Prisma.$eventosPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Eventos.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eventosCountArgs} args - Arguments to filter Eventos to count.
     * @example
     * // Count the number of Eventos
     * const count = await prisma.eventos.count({
     *   where: {
     *     // ... the filter for the Eventos we want to count
     *   }
     * })
    **/
    count<T extends eventosCountArgs>(
      args?: Subset<T, eventosCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], EventosCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Eventos.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EventosAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends EventosAggregateArgs>(args: Subset<T, EventosAggregateArgs>): Prisma.PrismaPromise<GetEventosAggregateType<T>>

    /**
     * Group by Eventos.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eventosGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends eventosGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: eventosGroupByArgs['orderBy'] }
        : { orderBy?: eventosGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, eventosGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetEventosGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the eventos model
   */
  readonly fields: eventosFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for eventos.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__eventosClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    usuarios<T extends usuariosDefaultArgs<ExtArgs> = {}>(args?: Subset<T, usuariosDefaultArgs<ExtArgs>>): Prisma__usuariosClient<$Result.GetResult<Prisma.$usuariosPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    local<T extends eventos$localArgs<ExtArgs> = {}>(args?: Subset<T, eventos$localArgs<ExtArgs>>): Prisma__localClient<$Result.GetResult<Prisma.$localPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    inscricoes<T extends eventos$inscricoesArgs<ExtArgs> = {}>(args?: Subset<T, eventos$inscricoesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$inscricoesPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the eventos model
   */
  interface eventosFieldRefs {
    readonly id_evento: FieldRef<"eventos", 'Int'>
    readonly titulo: FieldRef<"eventos", 'String'>
    readonly descricao: FieldRef<"eventos", 'String'>
    readonly palestrante: FieldRef<"eventos", 'String'>
    readonly carga_horaria: FieldRef<"eventos", 'Int'>
    readonly vagas_limite: FieldRef<"eventos", 'Int'>
    readonly data_inicio: FieldRef<"eventos", 'DateTime'>
    readonly data_fim: FieldRef<"eventos", 'DateTime'>
    readonly hora_inicio: FieldRef<"eventos", 'DateTime'>
    readonly hora_fim: FieldRef<"eventos", 'DateTime'>
    readonly objetivo_pedagogico: FieldRef<"eventos", 'String'>
    readonly id_local: FieldRef<"eventos", 'String'>
    readonly id_usuario: FieldRef<"eventos", 'Int'>
  }
    

  // Custom InputTypes
  /**
   * eventos findUnique
   */
  export type eventosFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eventos
     */
    select?: eventosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eventos
     */
    omit?: eventosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: eventosInclude<ExtArgs> | null
    /**
     * Filter, which eventos to fetch.
     */
    where: eventosWhereUniqueInput
  }

  /**
   * eventos findUniqueOrThrow
   */
  export type eventosFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eventos
     */
    select?: eventosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eventos
     */
    omit?: eventosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: eventosInclude<ExtArgs> | null
    /**
     * Filter, which eventos to fetch.
     */
    where: eventosWhereUniqueInput
  }

  /**
   * eventos findFirst
   */
  export type eventosFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eventos
     */
    select?: eventosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eventos
     */
    omit?: eventosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: eventosInclude<ExtArgs> | null
    /**
     * Filter, which eventos to fetch.
     */
    where?: eventosWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of eventos to fetch.
     */
    orderBy?: eventosOrderByWithRelationInput | eventosOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for eventos.
     */
    cursor?: eventosWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` eventos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` eventos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of eventos.
     */
    distinct?: EventosScalarFieldEnum | EventosScalarFieldEnum[]
  }

  /**
   * eventos findFirstOrThrow
   */
  export type eventosFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eventos
     */
    select?: eventosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eventos
     */
    omit?: eventosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: eventosInclude<ExtArgs> | null
    /**
     * Filter, which eventos to fetch.
     */
    where?: eventosWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of eventos to fetch.
     */
    orderBy?: eventosOrderByWithRelationInput | eventosOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for eventos.
     */
    cursor?: eventosWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` eventos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` eventos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of eventos.
     */
    distinct?: EventosScalarFieldEnum | EventosScalarFieldEnum[]
  }

  /**
   * eventos findMany
   */
  export type eventosFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eventos
     */
    select?: eventosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eventos
     */
    omit?: eventosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: eventosInclude<ExtArgs> | null
    /**
     * Filter, which eventos to fetch.
     */
    where?: eventosWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of eventos to fetch.
     */
    orderBy?: eventosOrderByWithRelationInput | eventosOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing eventos.
     */
    cursor?: eventosWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` eventos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` eventos.
     */
    skip?: number
    distinct?: EventosScalarFieldEnum | EventosScalarFieldEnum[]
  }

  /**
   * eventos create
   */
  export type eventosCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eventos
     */
    select?: eventosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eventos
     */
    omit?: eventosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: eventosInclude<ExtArgs> | null
    /**
     * The data needed to create a eventos.
     */
    data: XOR<eventosCreateInput, eventosUncheckedCreateInput>
  }

  /**
   * eventos createMany
   */
  export type eventosCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many eventos.
     */
    data: eventosCreateManyInput | eventosCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * eventos createManyAndReturn
   */
  export type eventosCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eventos
     */
    select?: eventosSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the eventos
     */
    omit?: eventosOmit<ExtArgs> | null
    /**
     * The data used to create many eventos.
     */
    data: eventosCreateManyInput | eventosCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: eventosIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * eventos update
   */
  export type eventosUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eventos
     */
    select?: eventosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eventos
     */
    omit?: eventosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: eventosInclude<ExtArgs> | null
    /**
     * The data needed to update a eventos.
     */
    data: XOR<eventosUpdateInput, eventosUncheckedUpdateInput>
    /**
     * Choose, which eventos to update.
     */
    where: eventosWhereUniqueInput
  }

  /**
   * eventos updateMany
   */
  export type eventosUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update eventos.
     */
    data: XOR<eventosUpdateManyMutationInput, eventosUncheckedUpdateManyInput>
    /**
     * Filter which eventos to update
     */
    where?: eventosWhereInput
    /**
     * Limit how many eventos to update.
     */
    limit?: number
  }

  /**
   * eventos updateManyAndReturn
   */
  export type eventosUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eventos
     */
    select?: eventosSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the eventos
     */
    omit?: eventosOmit<ExtArgs> | null
    /**
     * The data used to update eventos.
     */
    data: XOR<eventosUpdateManyMutationInput, eventosUncheckedUpdateManyInput>
    /**
     * Filter which eventos to update
     */
    where?: eventosWhereInput
    /**
     * Limit how many eventos to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: eventosIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * eventos upsert
   */
  export type eventosUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eventos
     */
    select?: eventosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eventos
     */
    omit?: eventosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: eventosInclude<ExtArgs> | null
    /**
     * The filter to search for the eventos to update in case it exists.
     */
    where: eventosWhereUniqueInput
    /**
     * In case the eventos found by the `where` argument doesn't exist, create a new eventos with this data.
     */
    create: XOR<eventosCreateInput, eventosUncheckedCreateInput>
    /**
     * In case the eventos was found with the provided `where` argument, update it with this data.
     */
    update: XOR<eventosUpdateInput, eventosUncheckedUpdateInput>
  }

  /**
   * eventos delete
   */
  export type eventosDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eventos
     */
    select?: eventosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eventos
     */
    omit?: eventosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: eventosInclude<ExtArgs> | null
    /**
     * Filter which eventos to delete.
     */
    where: eventosWhereUniqueInput
  }

  /**
   * eventos deleteMany
   */
  export type eventosDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which eventos to delete
     */
    where?: eventosWhereInput
    /**
     * Limit how many eventos to delete.
     */
    limit?: number
  }

  /**
   * eventos.local
   */
  export type eventos$localArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the local
     */
    select?: localSelect<ExtArgs> | null
    /**
     * Omit specific fields from the local
     */
    omit?: localOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: localInclude<ExtArgs> | null
    where?: localWhereInput
  }

  /**
   * eventos.inscricoes
   */
  export type eventos$inscricoesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the inscricoes
     */
    select?: inscricoesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the inscricoes
     */
    omit?: inscricoesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: inscricoesInclude<ExtArgs> | null
    where?: inscricoesWhereInput
    orderBy?: inscricoesOrderByWithRelationInput | inscricoesOrderByWithRelationInput[]
    cursor?: inscricoesWhereUniqueInput
    take?: number
    skip?: number
    distinct?: InscricoesScalarFieldEnum | InscricoesScalarFieldEnum[]
  }

  /**
   * eventos without action
   */
  export type eventosDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eventos
     */
    select?: eventosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eventos
     */
    omit?: eventosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: eventosInclude<ExtArgs> | null
  }


  /**
   * Model inscricoes
   */

  export type AggregateInscricoes = {
    _count: InscricoesCountAggregateOutputType | null
    _avg: InscricoesAvgAggregateOutputType | null
    _sum: InscricoesSumAggregateOutputType | null
    _min: InscricoesMinAggregateOutputType | null
    _max: InscricoesMaxAggregateOutputType | null
  }

  export type InscricoesAvgAggregateOutputType = {
    id_inscricao: number | null
    id_aluno: number | null
    id_evento: number | null
  }

  export type InscricoesSumAggregateOutputType = {
    id_inscricao: number | null
    id_aluno: number | null
    id_evento: number | null
  }

  export type InscricoesMinAggregateOutputType = {
    id_inscricao: number | null
    id_aluno: number | null
    id_evento: number | null
    presenca_entrada: boolean | null
    horario_entrada: Date | null
    presenca_saida: boolean | null
    horario_saida: Date | null
    codigo_validacao: string | null
    data_inscricao: Date | null
  }

  export type InscricoesMaxAggregateOutputType = {
    id_inscricao: number | null
    id_aluno: number | null
    id_evento: number | null
    presenca_entrada: boolean | null
    horario_entrada: Date | null
    presenca_saida: boolean | null
    horario_saida: Date | null
    codigo_validacao: string | null
    data_inscricao: Date | null
  }

  export type InscricoesCountAggregateOutputType = {
    id_inscricao: number
    id_aluno: number
    id_evento: number
    presenca_entrada: number
    horario_entrada: number
    presenca_saida: number
    horario_saida: number
    codigo_validacao: number
    data_inscricao: number
    _all: number
  }


  export type InscricoesAvgAggregateInputType = {
    id_inscricao?: true
    id_aluno?: true
    id_evento?: true
  }

  export type InscricoesSumAggregateInputType = {
    id_inscricao?: true
    id_aluno?: true
    id_evento?: true
  }

  export type InscricoesMinAggregateInputType = {
    id_inscricao?: true
    id_aluno?: true
    id_evento?: true
    presenca_entrada?: true
    horario_entrada?: true
    presenca_saida?: true
    horario_saida?: true
    codigo_validacao?: true
    data_inscricao?: true
  }

  export type InscricoesMaxAggregateInputType = {
    id_inscricao?: true
    id_aluno?: true
    id_evento?: true
    presenca_entrada?: true
    horario_entrada?: true
    presenca_saida?: true
    horario_saida?: true
    codigo_validacao?: true
    data_inscricao?: true
  }

  export type InscricoesCountAggregateInputType = {
    id_inscricao?: true
    id_aluno?: true
    id_evento?: true
    presenca_entrada?: true
    horario_entrada?: true
    presenca_saida?: true
    horario_saida?: true
    codigo_validacao?: true
    data_inscricao?: true
    _all?: true
  }

  export type InscricoesAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which inscricoes to aggregate.
     */
    where?: inscricoesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of inscricoes to fetch.
     */
    orderBy?: inscricoesOrderByWithRelationInput | inscricoesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: inscricoesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` inscricoes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` inscricoes.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned inscricoes
    **/
    _count?: true | InscricoesCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: InscricoesAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: InscricoesSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: InscricoesMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: InscricoesMaxAggregateInputType
  }

  export type GetInscricoesAggregateType<T extends InscricoesAggregateArgs> = {
        [P in keyof T & keyof AggregateInscricoes]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateInscricoes[P]>
      : GetScalarType<T[P], AggregateInscricoes[P]>
  }




  export type inscricoesGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: inscricoesWhereInput
    orderBy?: inscricoesOrderByWithAggregationInput | inscricoesOrderByWithAggregationInput[]
    by: InscricoesScalarFieldEnum[] | InscricoesScalarFieldEnum
    having?: inscricoesScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: InscricoesCountAggregateInputType | true
    _avg?: InscricoesAvgAggregateInputType
    _sum?: InscricoesSumAggregateInputType
    _min?: InscricoesMinAggregateInputType
    _max?: InscricoesMaxAggregateInputType
  }

  export type InscricoesGroupByOutputType = {
    id_inscricao: number
    id_aluno: number
    id_evento: number
    presenca_entrada: boolean | null
    horario_entrada: Date | null
    presenca_saida: boolean | null
    horario_saida: Date | null
    codigo_validacao: string | null
    data_inscricao: Date | null
    _count: InscricoesCountAggregateOutputType | null
    _avg: InscricoesAvgAggregateOutputType | null
    _sum: InscricoesSumAggregateOutputType | null
    _min: InscricoesMinAggregateOutputType | null
    _max: InscricoesMaxAggregateOutputType | null
  }

  type GetInscricoesGroupByPayload<T extends inscricoesGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<InscricoesGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof InscricoesGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], InscricoesGroupByOutputType[P]>
            : GetScalarType<T[P], InscricoesGroupByOutputType[P]>
        }
      >
    >


  export type inscricoesSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id_inscricao?: boolean
    id_aluno?: boolean
    id_evento?: boolean
    presenca_entrada?: boolean
    horario_entrada?: boolean
    presenca_saida?: boolean
    horario_saida?: boolean
    codigo_validacao?: boolean
    data_inscricao?: boolean
    usuarios?: boolean | usuariosDefaultArgs<ExtArgs>
    eventos?: boolean | eventosDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["inscricoes"]>

  export type inscricoesSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id_inscricao?: boolean
    id_aluno?: boolean
    id_evento?: boolean
    presenca_entrada?: boolean
    horario_entrada?: boolean
    presenca_saida?: boolean
    horario_saida?: boolean
    codigo_validacao?: boolean
    data_inscricao?: boolean
    usuarios?: boolean | usuariosDefaultArgs<ExtArgs>
    eventos?: boolean | eventosDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["inscricoes"]>

  export type inscricoesSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id_inscricao?: boolean
    id_aluno?: boolean
    id_evento?: boolean
    presenca_entrada?: boolean
    horario_entrada?: boolean
    presenca_saida?: boolean
    horario_saida?: boolean
    codigo_validacao?: boolean
    data_inscricao?: boolean
    usuarios?: boolean | usuariosDefaultArgs<ExtArgs>
    eventos?: boolean | eventosDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["inscricoes"]>

  export type inscricoesSelectScalar = {
    id_inscricao?: boolean
    id_aluno?: boolean
    id_evento?: boolean
    presenca_entrada?: boolean
    horario_entrada?: boolean
    presenca_saida?: boolean
    horario_saida?: boolean
    codigo_validacao?: boolean
    data_inscricao?: boolean
  }

  export type inscricoesOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id_inscricao" | "id_aluno" | "id_evento" | "presenca_entrada" | "horario_entrada" | "presenca_saida" | "horario_saida" | "codigo_validacao" | "data_inscricao", ExtArgs["result"]["inscricoes"]>
  export type inscricoesInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    usuarios?: boolean | usuariosDefaultArgs<ExtArgs>
    eventos?: boolean | eventosDefaultArgs<ExtArgs>
  }
  export type inscricoesIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    usuarios?: boolean | usuariosDefaultArgs<ExtArgs>
    eventos?: boolean | eventosDefaultArgs<ExtArgs>
  }
  export type inscricoesIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    usuarios?: boolean | usuariosDefaultArgs<ExtArgs>
    eventos?: boolean | eventosDefaultArgs<ExtArgs>
  }

  export type $inscricoesPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "inscricoes"
    objects: {
      usuarios: Prisma.$usuariosPayload<ExtArgs>
      eventos: Prisma.$eventosPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id_inscricao: number
      id_aluno: number
      id_evento: number
      presenca_entrada: boolean | null
      horario_entrada: Date | null
      presenca_saida: boolean | null
      horario_saida: Date | null
      codigo_validacao: string | null
      data_inscricao: Date | null
    }, ExtArgs["result"]["inscricoes"]>
    composites: {}
  }

  type inscricoesGetPayload<S extends boolean | null | undefined | inscricoesDefaultArgs> = $Result.GetResult<Prisma.$inscricoesPayload, S>

  type inscricoesCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<inscricoesFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: InscricoesCountAggregateInputType | true
    }

  export interface inscricoesDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['inscricoes'], meta: { name: 'inscricoes' } }
    /**
     * Find zero or one Inscricoes that matches the filter.
     * @param {inscricoesFindUniqueArgs} args - Arguments to find a Inscricoes
     * @example
     * // Get one Inscricoes
     * const inscricoes = await prisma.inscricoes.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends inscricoesFindUniqueArgs>(args: SelectSubset<T, inscricoesFindUniqueArgs<ExtArgs>>): Prisma__inscricoesClient<$Result.GetResult<Prisma.$inscricoesPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Inscricoes that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {inscricoesFindUniqueOrThrowArgs} args - Arguments to find a Inscricoes
     * @example
     * // Get one Inscricoes
     * const inscricoes = await prisma.inscricoes.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends inscricoesFindUniqueOrThrowArgs>(args: SelectSubset<T, inscricoesFindUniqueOrThrowArgs<ExtArgs>>): Prisma__inscricoesClient<$Result.GetResult<Prisma.$inscricoesPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Inscricoes that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {inscricoesFindFirstArgs} args - Arguments to find a Inscricoes
     * @example
     * // Get one Inscricoes
     * const inscricoes = await prisma.inscricoes.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends inscricoesFindFirstArgs>(args?: SelectSubset<T, inscricoesFindFirstArgs<ExtArgs>>): Prisma__inscricoesClient<$Result.GetResult<Prisma.$inscricoesPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Inscricoes that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {inscricoesFindFirstOrThrowArgs} args - Arguments to find a Inscricoes
     * @example
     * // Get one Inscricoes
     * const inscricoes = await prisma.inscricoes.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends inscricoesFindFirstOrThrowArgs>(args?: SelectSubset<T, inscricoesFindFirstOrThrowArgs<ExtArgs>>): Prisma__inscricoesClient<$Result.GetResult<Prisma.$inscricoesPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Inscricoes that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {inscricoesFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Inscricoes
     * const inscricoes = await prisma.inscricoes.findMany()
     * 
     * // Get first 10 Inscricoes
     * const inscricoes = await prisma.inscricoes.findMany({ take: 10 })
     * 
     * // Only select the `id_inscricao`
     * const inscricoesWithId_inscricaoOnly = await prisma.inscricoes.findMany({ select: { id_inscricao: true } })
     * 
     */
    findMany<T extends inscricoesFindManyArgs>(args?: SelectSubset<T, inscricoesFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$inscricoesPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Inscricoes.
     * @param {inscricoesCreateArgs} args - Arguments to create a Inscricoes.
     * @example
     * // Create one Inscricoes
     * const Inscricoes = await prisma.inscricoes.create({
     *   data: {
     *     // ... data to create a Inscricoes
     *   }
     * })
     * 
     */
    create<T extends inscricoesCreateArgs>(args: SelectSubset<T, inscricoesCreateArgs<ExtArgs>>): Prisma__inscricoesClient<$Result.GetResult<Prisma.$inscricoesPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Inscricoes.
     * @param {inscricoesCreateManyArgs} args - Arguments to create many Inscricoes.
     * @example
     * // Create many Inscricoes
     * const inscricoes = await prisma.inscricoes.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends inscricoesCreateManyArgs>(args?: SelectSubset<T, inscricoesCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Inscricoes and returns the data saved in the database.
     * @param {inscricoesCreateManyAndReturnArgs} args - Arguments to create many Inscricoes.
     * @example
     * // Create many Inscricoes
     * const inscricoes = await prisma.inscricoes.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Inscricoes and only return the `id_inscricao`
     * const inscricoesWithId_inscricaoOnly = await prisma.inscricoes.createManyAndReturn({
     *   select: { id_inscricao: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends inscricoesCreateManyAndReturnArgs>(args?: SelectSubset<T, inscricoesCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$inscricoesPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Inscricoes.
     * @param {inscricoesDeleteArgs} args - Arguments to delete one Inscricoes.
     * @example
     * // Delete one Inscricoes
     * const Inscricoes = await prisma.inscricoes.delete({
     *   where: {
     *     // ... filter to delete one Inscricoes
     *   }
     * })
     * 
     */
    delete<T extends inscricoesDeleteArgs>(args: SelectSubset<T, inscricoesDeleteArgs<ExtArgs>>): Prisma__inscricoesClient<$Result.GetResult<Prisma.$inscricoesPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Inscricoes.
     * @param {inscricoesUpdateArgs} args - Arguments to update one Inscricoes.
     * @example
     * // Update one Inscricoes
     * const inscricoes = await prisma.inscricoes.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends inscricoesUpdateArgs>(args: SelectSubset<T, inscricoesUpdateArgs<ExtArgs>>): Prisma__inscricoesClient<$Result.GetResult<Prisma.$inscricoesPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Inscricoes.
     * @param {inscricoesDeleteManyArgs} args - Arguments to filter Inscricoes to delete.
     * @example
     * // Delete a few Inscricoes
     * const { count } = await prisma.inscricoes.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends inscricoesDeleteManyArgs>(args?: SelectSubset<T, inscricoesDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Inscricoes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {inscricoesUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Inscricoes
     * const inscricoes = await prisma.inscricoes.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends inscricoesUpdateManyArgs>(args: SelectSubset<T, inscricoesUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Inscricoes and returns the data updated in the database.
     * @param {inscricoesUpdateManyAndReturnArgs} args - Arguments to update many Inscricoes.
     * @example
     * // Update many Inscricoes
     * const inscricoes = await prisma.inscricoes.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Inscricoes and only return the `id_inscricao`
     * const inscricoesWithId_inscricaoOnly = await prisma.inscricoes.updateManyAndReturn({
     *   select: { id_inscricao: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends inscricoesUpdateManyAndReturnArgs>(args: SelectSubset<T, inscricoesUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$inscricoesPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Inscricoes.
     * @param {inscricoesUpsertArgs} args - Arguments to update or create a Inscricoes.
     * @example
     * // Update or create a Inscricoes
     * const inscricoes = await prisma.inscricoes.upsert({
     *   create: {
     *     // ... data to create a Inscricoes
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Inscricoes we want to update
     *   }
     * })
     */
    upsert<T extends inscricoesUpsertArgs>(args: SelectSubset<T, inscricoesUpsertArgs<ExtArgs>>): Prisma__inscricoesClient<$Result.GetResult<Prisma.$inscricoesPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Inscricoes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {inscricoesCountArgs} args - Arguments to filter Inscricoes to count.
     * @example
     * // Count the number of Inscricoes
     * const count = await prisma.inscricoes.count({
     *   where: {
     *     // ... the filter for the Inscricoes we want to count
     *   }
     * })
    **/
    count<T extends inscricoesCountArgs>(
      args?: Subset<T, inscricoesCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], InscricoesCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Inscricoes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {InscricoesAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends InscricoesAggregateArgs>(args: Subset<T, InscricoesAggregateArgs>): Prisma.PrismaPromise<GetInscricoesAggregateType<T>>

    /**
     * Group by Inscricoes.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {inscricoesGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends inscricoesGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: inscricoesGroupByArgs['orderBy'] }
        : { orderBy?: inscricoesGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, inscricoesGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetInscricoesGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the inscricoes model
   */
  readonly fields: inscricoesFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for inscricoes.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__inscricoesClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    usuarios<T extends usuariosDefaultArgs<ExtArgs> = {}>(args?: Subset<T, usuariosDefaultArgs<ExtArgs>>): Prisma__usuariosClient<$Result.GetResult<Prisma.$usuariosPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    eventos<T extends eventosDefaultArgs<ExtArgs> = {}>(args?: Subset<T, eventosDefaultArgs<ExtArgs>>): Prisma__eventosClient<$Result.GetResult<Prisma.$eventosPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the inscricoes model
   */
  interface inscricoesFieldRefs {
    readonly id_inscricao: FieldRef<"inscricoes", 'Int'>
    readonly id_aluno: FieldRef<"inscricoes", 'Int'>
    readonly id_evento: FieldRef<"inscricoes", 'Int'>
    readonly presenca_entrada: FieldRef<"inscricoes", 'Boolean'>
    readonly horario_entrada: FieldRef<"inscricoes", 'DateTime'>
    readonly presenca_saida: FieldRef<"inscricoes", 'Boolean'>
    readonly horario_saida: FieldRef<"inscricoes", 'DateTime'>
    readonly codigo_validacao: FieldRef<"inscricoes", 'String'>
    readonly data_inscricao: FieldRef<"inscricoes", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * inscricoes findUnique
   */
  export type inscricoesFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the inscricoes
     */
    select?: inscricoesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the inscricoes
     */
    omit?: inscricoesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: inscricoesInclude<ExtArgs> | null
    /**
     * Filter, which inscricoes to fetch.
     */
    where: inscricoesWhereUniqueInput
  }

  /**
   * inscricoes findUniqueOrThrow
   */
  export type inscricoesFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the inscricoes
     */
    select?: inscricoesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the inscricoes
     */
    omit?: inscricoesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: inscricoesInclude<ExtArgs> | null
    /**
     * Filter, which inscricoes to fetch.
     */
    where: inscricoesWhereUniqueInput
  }

  /**
   * inscricoes findFirst
   */
  export type inscricoesFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the inscricoes
     */
    select?: inscricoesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the inscricoes
     */
    omit?: inscricoesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: inscricoesInclude<ExtArgs> | null
    /**
     * Filter, which inscricoes to fetch.
     */
    where?: inscricoesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of inscricoes to fetch.
     */
    orderBy?: inscricoesOrderByWithRelationInput | inscricoesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for inscricoes.
     */
    cursor?: inscricoesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` inscricoes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` inscricoes.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of inscricoes.
     */
    distinct?: InscricoesScalarFieldEnum | InscricoesScalarFieldEnum[]
  }

  /**
   * inscricoes findFirstOrThrow
   */
  export type inscricoesFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the inscricoes
     */
    select?: inscricoesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the inscricoes
     */
    omit?: inscricoesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: inscricoesInclude<ExtArgs> | null
    /**
     * Filter, which inscricoes to fetch.
     */
    where?: inscricoesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of inscricoes to fetch.
     */
    orderBy?: inscricoesOrderByWithRelationInput | inscricoesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for inscricoes.
     */
    cursor?: inscricoesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` inscricoes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` inscricoes.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of inscricoes.
     */
    distinct?: InscricoesScalarFieldEnum | InscricoesScalarFieldEnum[]
  }

  /**
   * inscricoes findMany
   */
  export type inscricoesFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the inscricoes
     */
    select?: inscricoesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the inscricoes
     */
    omit?: inscricoesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: inscricoesInclude<ExtArgs> | null
    /**
     * Filter, which inscricoes to fetch.
     */
    where?: inscricoesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of inscricoes to fetch.
     */
    orderBy?: inscricoesOrderByWithRelationInput | inscricoesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing inscricoes.
     */
    cursor?: inscricoesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` inscricoes from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` inscricoes.
     */
    skip?: number
    distinct?: InscricoesScalarFieldEnum | InscricoesScalarFieldEnum[]
  }

  /**
   * inscricoes create
   */
  export type inscricoesCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the inscricoes
     */
    select?: inscricoesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the inscricoes
     */
    omit?: inscricoesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: inscricoesInclude<ExtArgs> | null
    /**
     * The data needed to create a inscricoes.
     */
    data: XOR<inscricoesCreateInput, inscricoesUncheckedCreateInput>
  }

  /**
   * inscricoes createMany
   */
  export type inscricoesCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many inscricoes.
     */
    data: inscricoesCreateManyInput | inscricoesCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * inscricoes createManyAndReturn
   */
  export type inscricoesCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the inscricoes
     */
    select?: inscricoesSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the inscricoes
     */
    omit?: inscricoesOmit<ExtArgs> | null
    /**
     * The data used to create many inscricoes.
     */
    data: inscricoesCreateManyInput | inscricoesCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: inscricoesIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * inscricoes update
   */
  export type inscricoesUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the inscricoes
     */
    select?: inscricoesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the inscricoes
     */
    omit?: inscricoesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: inscricoesInclude<ExtArgs> | null
    /**
     * The data needed to update a inscricoes.
     */
    data: XOR<inscricoesUpdateInput, inscricoesUncheckedUpdateInput>
    /**
     * Choose, which inscricoes to update.
     */
    where: inscricoesWhereUniqueInput
  }

  /**
   * inscricoes updateMany
   */
  export type inscricoesUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update inscricoes.
     */
    data: XOR<inscricoesUpdateManyMutationInput, inscricoesUncheckedUpdateManyInput>
    /**
     * Filter which inscricoes to update
     */
    where?: inscricoesWhereInput
    /**
     * Limit how many inscricoes to update.
     */
    limit?: number
  }

  /**
   * inscricoes updateManyAndReturn
   */
  export type inscricoesUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the inscricoes
     */
    select?: inscricoesSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the inscricoes
     */
    omit?: inscricoesOmit<ExtArgs> | null
    /**
     * The data used to update inscricoes.
     */
    data: XOR<inscricoesUpdateManyMutationInput, inscricoesUncheckedUpdateManyInput>
    /**
     * Filter which inscricoes to update
     */
    where?: inscricoesWhereInput
    /**
     * Limit how many inscricoes to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: inscricoesIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * inscricoes upsert
   */
  export type inscricoesUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the inscricoes
     */
    select?: inscricoesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the inscricoes
     */
    omit?: inscricoesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: inscricoesInclude<ExtArgs> | null
    /**
     * The filter to search for the inscricoes to update in case it exists.
     */
    where: inscricoesWhereUniqueInput
    /**
     * In case the inscricoes found by the `where` argument doesn't exist, create a new inscricoes with this data.
     */
    create: XOR<inscricoesCreateInput, inscricoesUncheckedCreateInput>
    /**
     * In case the inscricoes was found with the provided `where` argument, update it with this data.
     */
    update: XOR<inscricoesUpdateInput, inscricoesUncheckedUpdateInput>
  }

  /**
   * inscricoes delete
   */
  export type inscricoesDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the inscricoes
     */
    select?: inscricoesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the inscricoes
     */
    omit?: inscricoesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: inscricoesInclude<ExtArgs> | null
    /**
     * Filter which inscricoes to delete.
     */
    where: inscricoesWhereUniqueInput
  }

  /**
   * inscricoes deleteMany
   */
  export type inscricoesDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which inscricoes to delete
     */
    where?: inscricoesWhereInput
    /**
     * Limit how many inscricoes to delete.
     */
    limit?: number
  }

  /**
   * inscricoes without action
   */
  export type inscricoesDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the inscricoes
     */
    select?: inscricoesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the inscricoes
     */
    omit?: inscricoesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: inscricoesInclude<ExtArgs> | null
  }


  /**
   * Model local
   */

  export type AggregateLocal = {
    _count: LocalCountAggregateOutputType | null
    _avg: LocalAvgAggregateOutputType | null
    _sum: LocalSumAggregateOutputType | null
    _min: LocalMinAggregateOutputType | null
    _max: LocalMaxAggregateOutputType | null
  }

  export type LocalAvgAggregateOutputType = {
    capacidade: number | null
  }

  export type LocalSumAggregateOutputType = {
    capacidade: number | null
  }

  export type LocalMinAggregateOutputType = {
    id_local: string | null
    nome_local: string | null
    capacidade: number | null
  }

  export type LocalMaxAggregateOutputType = {
    id_local: string | null
    nome_local: string | null
    capacidade: number | null
  }

  export type LocalCountAggregateOutputType = {
    id_local: number
    nome_local: number
    capacidade: number
    _all: number
  }


  export type LocalAvgAggregateInputType = {
    capacidade?: true
  }

  export type LocalSumAggregateInputType = {
    capacidade?: true
  }

  export type LocalMinAggregateInputType = {
    id_local?: true
    nome_local?: true
    capacidade?: true
  }

  export type LocalMaxAggregateInputType = {
    id_local?: true
    nome_local?: true
    capacidade?: true
  }

  export type LocalCountAggregateInputType = {
    id_local?: true
    nome_local?: true
    capacidade?: true
    _all?: true
  }

  export type LocalAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which local to aggregate.
     */
    where?: localWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of locals to fetch.
     */
    orderBy?: localOrderByWithRelationInput | localOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: localWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` locals from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` locals.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned locals
    **/
    _count?: true | LocalCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: LocalAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: LocalSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: LocalMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: LocalMaxAggregateInputType
  }

  export type GetLocalAggregateType<T extends LocalAggregateArgs> = {
        [P in keyof T & keyof AggregateLocal]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateLocal[P]>
      : GetScalarType<T[P], AggregateLocal[P]>
  }




  export type localGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: localWhereInput
    orderBy?: localOrderByWithAggregationInput | localOrderByWithAggregationInput[]
    by: LocalScalarFieldEnum[] | LocalScalarFieldEnum
    having?: localScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: LocalCountAggregateInputType | true
    _avg?: LocalAvgAggregateInputType
    _sum?: LocalSumAggregateInputType
    _min?: LocalMinAggregateInputType
    _max?: LocalMaxAggregateInputType
  }

  export type LocalGroupByOutputType = {
    id_local: string
    nome_local: string
    capacidade: number | null
    _count: LocalCountAggregateOutputType | null
    _avg: LocalAvgAggregateOutputType | null
    _sum: LocalSumAggregateOutputType | null
    _min: LocalMinAggregateOutputType | null
    _max: LocalMaxAggregateOutputType | null
  }

  type GetLocalGroupByPayload<T extends localGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<LocalGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof LocalGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], LocalGroupByOutputType[P]>
            : GetScalarType<T[P], LocalGroupByOutputType[P]>
        }
      >
    >


  export type localSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id_local?: boolean
    nome_local?: boolean
    capacidade?: boolean
    eventos?: boolean | local$eventosArgs<ExtArgs>
    _count?: boolean | LocalCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["local"]>

  export type localSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id_local?: boolean
    nome_local?: boolean
    capacidade?: boolean
  }, ExtArgs["result"]["local"]>

  export type localSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id_local?: boolean
    nome_local?: boolean
    capacidade?: boolean
  }, ExtArgs["result"]["local"]>

  export type localSelectScalar = {
    id_local?: boolean
    nome_local?: boolean
    capacidade?: boolean
  }

  export type localOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id_local" | "nome_local" | "capacidade", ExtArgs["result"]["local"]>
  export type localInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    eventos?: boolean | local$eventosArgs<ExtArgs>
    _count?: boolean | LocalCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type localIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type localIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $localPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "local"
    objects: {
      eventos: Prisma.$eventosPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id_local: string
      nome_local: string
      capacidade: number | null
    }, ExtArgs["result"]["local"]>
    composites: {}
  }

  type localGetPayload<S extends boolean | null | undefined | localDefaultArgs> = $Result.GetResult<Prisma.$localPayload, S>

  type localCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<localFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: LocalCountAggregateInputType | true
    }

  export interface localDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['local'], meta: { name: 'local' } }
    /**
     * Find zero or one Local that matches the filter.
     * @param {localFindUniqueArgs} args - Arguments to find a Local
     * @example
     * // Get one Local
     * const local = await prisma.local.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends localFindUniqueArgs>(args: SelectSubset<T, localFindUniqueArgs<ExtArgs>>): Prisma__localClient<$Result.GetResult<Prisma.$localPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Local that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {localFindUniqueOrThrowArgs} args - Arguments to find a Local
     * @example
     * // Get one Local
     * const local = await prisma.local.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends localFindUniqueOrThrowArgs>(args: SelectSubset<T, localFindUniqueOrThrowArgs<ExtArgs>>): Prisma__localClient<$Result.GetResult<Prisma.$localPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Local that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {localFindFirstArgs} args - Arguments to find a Local
     * @example
     * // Get one Local
     * const local = await prisma.local.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends localFindFirstArgs>(args?: SelectSubset<T, localFindFirstArgs<ExtArgs>>): Prisma__localClient<$Result.GetResult<Prisma.$localPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Local that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {localFindFirstOrThrowArgs} args - Arguments to find a Local
     * @example
     * // Get one Local
     * const local = await prisma.local.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends localFindFirstOrThrowArgs>(args?: SelectSubset<T, localFindFirstOrThrowArgs<ExtArgs>>): Prisma__localClient<$Result.GetResult<Prisma.$localPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Locals that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {localFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Locals
     * const locals = await prisma.local.findMany()
     * 
     * // Get first 10 Locals
     * const locals = await prisma.local.findMany({ take: 10 })
     * 
     * // Only select the `id_local`
     * const localWithId_localOnly = await prisma.local.findMany({ select: { id_local: true } })
     * 
     */
    findMany<T extends localFindManyArgs>(args?: SelectSubset<T, localFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$localPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Local.
     * @param {localCreateArgs} args - Arguments to create a Local.
     * @example
     * // Create one Local
     * const Local = await prisma.local.create({
     *   data: {
     *     // ... data to create a Local
     *   }
     * })
     * 
     */
    create<T extends localCreateArgs>(args: SelectSubset<T, localCreateArgs<ExtArgs>>): Prisma__localClient<$Result.GetResult<Prisma.$localPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Locals.
     * @param {localCreateManyArgs} args - Arguments to create many Locals.
     * @example
     * // Create many Locals
     * const local = await prisma.local.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends localCreateManyArgs>(args?: SelectSubset<T, localCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Locals and returns the data saved in the database.
     * @param {localCreateManyAndReturnArgs} args - Arguments to create many Locals.
     * @example
     * // Create many Locals
     * const local = await prisma.local.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Locals and only return the `id_local`
     * const localWithId_localOnly = await prisma.local.createManyAndReturn({
     *   select: { id_local: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends localCreateManyAndReturnArgs>(args?: SelectSubset<T, localCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$localPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Local.
     * @param {localDeleteArgs} args - Arguments to delete one Local.
     * @example
     * // Delete one Local
     * const Local = await prisma.local.delete({
     *   where: {
     *     // ... filter to delete one Local
     *   }
     * })
     * 
     */
    delete<T extends localDeleteArgs>(args: SelectSubset<T, localDeleteArgs<ExtArgs>>): Prisma__localClient<$Result.GetResult<Prisma.$localPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Local.
     * @param {localUpdateArgs} args - Arguments to update one Local.
     * @example
     * // Update one Local
     * const local = await prisma.local.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends localUpdateArgs>(args: SelectSubset<T, localUpdateArgs<ExtArgs>>): Prisma__localClient<$Result.GetResult<Prisma.$localPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Locals.
     * @param {localDeleteManyArgs} args - Arguments to filter Locals to delete.
     * @example
     * // Delete a few Locals
     * const { count } = await prisma.local.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends localDeleteManyArgs>(args?: SelectSubset<T, localDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Locals.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {localUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Locals
     * const local = await prisma.local.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends localUpdateManyArgs>(args: SelectSubset<T, localUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Locals and returns the data updated in the database.
     * @param {localUpdateManyAndReturnArgs} args - Arguments to update many Locals.
     * @example
     * // Update many Locals
     * const local = await prisma.local.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Locals and only return the `id_local`
     * const localWithId_localOnly = await prisma.local.updateManyAndReturn({
     *   select: { id_local: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends localUpdateManyAndReturnArgs>(args: SelectSubset<T, localUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$localPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Local.
     * @param {localUpsertArgs} args - Arguments to update or create a Local.
     * @example
     * // Update or create a Local
     * const local = await prisma.local.upsert({
     *   create: {
     *     // ... data to create a Local
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Local we want to update
     *   }
     * })
     */
    upsert<T extends localUpsertArgs>(args: SelectSubset<T, localUpsertArgs<ExtArgs>>): Prisma__localClient<$Result.GetResult<Prisma.$localPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Locals.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {localCountArgs} args - Arguments to filter Locals to count.
     * @example
     * // Count the number of Locals
     * const count = await prisma.local.count({
     *   where: {
     *     // ... the filter for the Locals we want to count
     *   }
     * })
    **/
    count<T extends localCountArgs>(
      args?: Subset<T, localCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], LocalCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Local.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {LocalAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends LocalAggregateArgs>(args: Subset<T, LocalAggregateArgs>): Prisma.PrismaPromise<GetLocalAggregateType<T>>

    /**
     * Group by Local.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {localGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends localGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: localGroupByArgs['orderBy'] }
        : { orderBy?: localGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, localGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetLocalGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the local model
   */
  readonly fields: localFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for local.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__localClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    eventos<T extends local$eventosArgs<ExtArgs> = {}>(args?: Subset<T, local$eventosArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$eventosPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the local model
   */
  interface localFieldRefs {
    readonly id_local: FieldRef<"local", 'String'>
    readonly nome_local: FieldRef<"local", 'String'>
    readonly capacidade: FieldRef<"local", 'Int'>
  }
    

  // Custom InputTypes
  /**
   * local findUnique
   */
  export type localFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the local
     */
    select?: localSelect<ExtArgs> | null
    /**
     * Omit specific fields from the local
     */
    omit?: localOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: localInclude<ExtArgs> | null
    /**
     * Filter, which local to fetch.
     */
    where: localWhereUniqueInput
  }

  /**
   * local findUniqueOrThrow
   */
  export type localFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the local
     */
    select?: localSelect<ExtArgs> | null
    /**
     * Omit specific fields from the local
     */
    omit?: localOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: localInclude<ExtArgs> | null
    /**
     * Filter, which local to fetch.
     */
    where: localWhereUniqueInput
  }

  /**
   * local findFirst
   */
  export type localFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the local
     */
    select?: localSelect<ExtArgs> | null
    /**
     * Omit specific fields from the local
     */
    omit?: localOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: localInclude<ExtArgs> | null
    /**
     * Filter, which local to fetch.
     */
    where?: localWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of locals to fetch.
     */
    orderBy?: localOrderByWithRelationInput | localOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for locals.
     */
    cursor?: localWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` locals from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` locals.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of locals.
     */
    distinct?: LocalScalarFieldEnum | LocalScalarFieldEnum[]
  }

  /**
   * local findFirstOrThrow
   */
  export type localFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the local
     */
    select?: localSelect<ExtArgs> | null
    /**
     * Omit specific fields from the local
     */
    omit?: localOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: localInclude<ExtArgs> | null
    /**
     * Filter, which local to fetch.
     */
    where?: localWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of locals to fetch.
     */
    orderBy?: localOrderByWithRelationInput | localOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for locals.
     */
    cursor?: localWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` locals from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` locals.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of locals.
     */
    distinct?: LocalScalarFieldEnum | LocalScalarFieldEnum[]
  }

  /**
   * local findMany
   */
  export type localFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the local
     */
    select?: localSelect<ExtArgs> | null
    /**
     * Omit specific fields from the local
     */
    omit?: localOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: localInclude<ExtArgs> | null
    /**
     * Filter, which locals to fetch.
     */
    where?: localWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of locals to fetch.
     */
    orderBy?: localOrderByWithRelationInput | localOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing locals.
     */
    cursor?: localWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` locals from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` locals.
     */
    skip?: number
    distinct?: LocalScalarFieldEnum | LocalScalarFieldEnum[]
  }

  /**
   * local create
   */
  export type localCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the local
     */
    select?: localSelect<ExtArgs> | null
    /**
     * Omit specific fields from the local
     */
    omit?: localOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: localInclude<ExtArgs> | null
    /**
     * The data needed to create a local.
     */
    data: XOR<localCreateInput, localUncheckedCreateInput>
  }

  /**
   * local createMany
   */
  export type localCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many locals.
     */
    data: localCreateManyInput | localCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * local createManyAndReturn
   */
  export type localCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the local
     */
    select?: localSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the local
     */
    omit?: localOmit<ExtArgs> | null
    /**
     * The data used to create many locals.
     */
    data: localCreateManyInput | localCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * local update
   */
  export type localUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the local
     */
    select?: localSelect<ExtArgs> | null
    /**
     * Omit specific fields from the local
     */
    omit?: localOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: localInclude<ExtArgs> | null
    /**
     * The data needed to update a local.
     */
    data: XOR<localUpdateInput, localUncheckedUpdateInput>
    /**
     * Choose, which local to update.
     */
    where: localWhereUniqueInput
  }

  /**
   * local updateMany
   */
  export type localUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update locals.
     */
    data: XOR<localUpdateManyMutationInput, localUncheckedUpdateManyInput>
    /**
     * Filter which locals to update
     */
    where?: localWhereInput
    /**
     * Limit how many locals to update.
     */
    limit?: number
  }

  /**
   * local updateManyAndReturn
   */
  export type localUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the local
     */
    select?: localSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the local
     */
    omit?: localOmit<ExtArgs> | null
    /**
     * The data used to update locals.
     */
    data: XOR<localUpdateManyMutationInput, localUncheckedUpdateManyInput>
    /**
     * Filter which locals to update
     */
    where?: localWhereInput
    /**
     * Limit how many locals to update.
     */
    limit?: number
  }

  /**
   * local upsert
   */
  export type localUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the local
     */
    select?: localSelect<ExtArgs> | null
    /**
     * Omit specific fields from the local
     */
    omit?: localOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: localInclude<ExtArgs> | null
    /**
     * The filter to search for the local to update in case it exists.
     */
    where: localWhereUniqueInput
    /**
     * In case the local found by the `where` argument doesn't exist, create a new local with this data.
     */
    create: XOR<localCreateInput, localUncheckedCreateInput>
    /**
     * In case the local was found with the provided `where` argument, update it with this data.
     */
    update: XOR<localUpdateInput, localUncheckedUpdateInput>
  }

  /**
   * local delete
   */
  export type localDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the local
     */
    select?: localSelect<ExtArgs> | null
    /**
     * Omit specific fields from the local
     */
    omit?: localOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: localInclude<ExtArgs> | null
    /**
     * Filter which local to delete.
     */
    where: localWhereUniqueInput
  }

  /**
   * local deleteMany
   */
  export type localDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which locals to delete
     */
    where?: localWhereInput
    /**
     * Limit how many locals to delete.
     */
    limit?: number
  }

  /**
   * local.eventos
   */
  export type local$eventosArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eventos
     */
    select?: eventosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eventos
     */
    omit?: eventosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: eventosInclude<ExtArgs> | null
    where?: eventosWhereInput
    orderBy?: eventosOrderByWithRelationInput | eventosOrderByWithRelationInput[]
    cursor?: eventosWhereUniqueInput
    take?: number
    skip?: number
    distinct?: EventosScalarFieldEnum | EventosScalarFieldEnum[]
  }

  /**
   * local without action
   */
  export type localDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the local
     */
    select?: localSelect<ExtArgs> | null
    /**
     * Omit specific fields from the local
     */
    omit?: localOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: localInclude<ExtArgs> | null
  }


  /**
   * Model tipo_perfil
   */

  export type AggregateTipo_perfil = {
    _count: Tipo_perfilCountAggregateOutputType | null
    _min: Tipo_perfilMinAggregateOutputType | null
    _max: Tipo_perfilMaxAggregateOutputType | null
  }

  export type Tipo_perfilMinAggregateOutputType = {
    id_tipo_perfil: string | null
    descricao: string | null
  }

  export type Tipo_perfilMaxAggregateOutputType = {
    id_tipo_perfil: string | null
    descricao: string | null
  }

  export type Tipo_perfilCountAggregateOutputType = {
    id_tipo_perfil: number
    descricao: number
    _all: number
  }


  export type Tipo_perfilMinAggregateInputType = {
    id_tipo_perfil?: true
    descricao?: true
  }

  export type Tipo_perfilMaxAggregateInputType = {
    id_tipo_perfil?: true
    descricao?: true
  }

  export type Tipo_perfilCountAggregateInputType = {
    id_tipo_perfil?: true
    descricao?: true
    _all?: true
  }

  export type Tipo_perfilAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which tipo_perfil to aggregate.
     */
    where?: tipo_perfilWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of tipo_perfils to fetch.
     */
    orderBy?: tipo_perfilOrderByWithRelationInput | tipo_perfilOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: tipo_perfilWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` tipo_perfils from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` tipo_perfils.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned tipo_perfils
    **/
    _count?: true | Tipo_perfilCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: Tipo_perfilMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: Tipo_perfilMaxAggregateInputType
  }

  export type GetTipo_perfilAggregateType<T extends Tipo_perfilAggregateArgs> = {
        [P in keyof T & keyof AggregateTipo_perfil]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateTipo_perfil[P]>
      : GetScalarType<T[P], AggregateTipo_perfil[P]>
  }




  export type tipo_perfilGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: tipo_perfilWhereInput
    orderBy?: tipo_perfilOrderByWithAggregationInput | tipo_perfilOrderByWithAggregationInput[]
    by: Tipo_perfilScalarFieldEnum[] | Tipo_perfilScalarFieldEnum
    having?: tipo_perfilScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: Tipo_perfilCountAggregateInputType | true
    _min?: Tipo_perfilMinAggregateInputType
    _max?: Tipo_perfilMaxAggregateInputType
  }

  export type Tipo_perfilGroupByOutputType = {
    id_tipo_perfil: string
    descricao: string
    _count: Tipo_perfilCountAggregateOutputType | null
    _min: Tipo_perfilMinAggregateOutputType | null
    _max: Tipo_perfilMaxAggregateOutputType | null
  }

  type GetTipo_perfilGroupByPayload<T extends tipo_perfilGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<Tipo_perfilGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof Tipo_perfilGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], Tipo_perfilGroupByOutputType[P]>
            : GetScalarType<T[P], Tipo_perfilGroupByOutputType[P]>
        }
      >
    >


  export type tipo_perfilSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id_tipo_perfil?: boolean
    descricao?: boolean
    usuarios?: boolean | tipo_perfil$usuariosArgs<ExtArgs>
    _count?: boolean | Tipo_perfilCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["tipo_perfil"]>

  export type tipo_perfilSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id_tipo_perfil?: boolean
    descricao?: boolean
  }, ExtArgs["result"]["tipo_perfil"]>

  export type tipo_perfilSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id_tipo_perfil?: boolean
    descricao?: boolean
  }, ExtArgs["result"]["tipo_perfil"]>

  export type tipo_perfilSelectScalar = {
    id_tipo_perfil?: boolean
    descricao?: boolean
  }

  export type tipo_perfilOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id_tipo_perfil" | "descricao", ExtArgs["result"]["tipo_perfil"]>
  export type tipo_perfilInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    usuarios?: boolean | tipo_perfil$usuariosArgs<ExtArgs>
    _count?: boolean | Tipo_perfilCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type tipo_perfilIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type tipo_perfilIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $tipo_perfilPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "tipo_perfil"
    objects: {
      usuarios: Prisma.$usuariosPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id_tipo_perfil: string
      descricao: string
    }, ExtArgs["result"]["tipo_perfil"]>
    composites: {}
  }

  type tipo_perfilGetPayload<S extends boolean | null | undefined | tipo_perfilDefaultArgs> = $Result.GetResult<Prisma.$tipo_perfilPayload, S>

  type tipo_perfilCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<tipo_perfilFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: Tipo_perfilCountAggregateInputType | true
    }

  export interface tipo_perfilDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['tipo_perfil'], meta: { name: 'tipo_perfil' } }
    /**
     * Find zero or one Tipo_perfil that matches the filter.
     * @param {tipo_perfilFindUniqueArgs} args - Arguments to find a Tipo_perfil
     * @example
     * // Get one Tipo_perfil
     * const tipo_perfil = await prisma.tipo_perfil.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends tipo_perfilFindUniqueArgs>(args: SelectSubset<T, tipo_perfilFindUniqueArgs<ExtArgs>>): Prisma__tipo_perfilClient<$Result.GetResult<Prisma.$tipo_perfilPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Tipo_perfil that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {tipo_perfilFindUniqueOrThrowArgs} args - Arguments to find a Tipo_perfil
     * @example
     * // Get one Tipo_perfil
     * const tipo_perfil = await prisma.tipo_perfil.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends tipo_perfilFindUniqueOrThrowArgs>(args: SelectSubset<T, tipo_perfilFindUniqueOrThrowArgs<ExtArgs>>): Prisma__tipo_perfilClient<$Result.GetResult<Prisma.$tipo_perfilPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Tipo_perfil that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {tipo_perfilFindFirstArgs} args - Arguments to find a Tipo_perfil
     * @example
     * // Get one Tipo_perfil
     * const tipo_perfil = await prisma.tipo_perfil.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends tipo_perfilFindFirstArgs>(args?: SelectSubset<T, tipo_perfilFindFirstArgs<ExtArgs>>): Prisma__tipo_perfilClient<$Result.GetResult<Prisma.$tipo_perfilPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Tipo_perfil that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {tipo_perfilFindFirstOrThrowArgs} args - Arguments to find a Tipo_perfil
     * @example
     * // Get one Tipo_perfil
     * const tipo_perfil = await prisma.tipo_perfil.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends tipo_perfilFindFirstOrThrowArgs>(args?: SelectSubset<T, tipo_perfilFindFirstOrThrowArgs<ExtArgs>>): Prisma__tipo_perfilClient<$Result.GetResult<Prisma.$tipo_perfilPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Tipo_perfils that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {tipo_perfilFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Tipo_perfils
     * const tipo_perfils = await prisma.tipo_perfil.findMany()
     * 
     * // Get first 10 Tipo_perfils
     * const tipo_perfils = await prisma.tipo_perfil.findMany({ take: 10 })
     * 
     * // Only select the `id_tipo_perfil`
     * const tipo_perfilWithId_tipo_perfilOnly = await prisma.tipo_perfil.findMany({ select: { id_tipo_perfil: true } })
     * 
     */
    findMany<T extends tipo_perfilFindManyArgs>(args?: SelectSubset<T, tipo_perfilFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$tipo_perfilPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Tipo_perfil.
     * @param {tipo_perfilCreateArgs} args - Arguments to create a Tipo_perfil.
     * @example
     * // Create one Tipo_perfil
     * const Tipo_perfil = await prisma.tipo_perfil.create({
     *   data: {
     *     // ... data to create a Tipo_perfil
     *   }
     * })
     * 
     */
    create<T extends tipo_perfilCreateArgs>(args: SelectSubset<T, tipo_perfilCreateArgs<ExtArgs>>): Prisma__tipo_perfilClient<$Result.GetResult<Prisma.$tipo_perfilPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Tipo_perfils.
     * @param {tipo_perfilCreateManyArgs} args - Arguments to create many Tipo_perfils.
     * @example
     * // Create many Tipo_perfils
     * const tipo_perfil = await prisma.tipo_perfil.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends tipo_perfilCreateManyArgs>(args?: SelectSubset<T, tipo_perfilCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Tipo_perfils and returns the data saved in the database.
     * @param {tipo_perfilCreateManyAndReturnArgs} args - Arguments to create many Tipo_perfils.
     * @example
     * // Create many Tipo_perfils
     * const tipo_perfil = await prisma.tipo_perfil.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Tipo_perfils and only return the `id_tipo_perfil`
     * const tipo_perfilWithId_tipo_perfilOnly = await prisma.tipo_perfil.createManyAndReturn({
     *   select: { id_tipo_perfil: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends tipo_perfilCreateManyAndReturnArgs>(args?: SelectSubset<T, tipo_perfilCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$tipo_perfilPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Tipo_perfil.
     * @param {tipo_perfilDeleteArgs} args - Arguments to delete one Tipo_perfil.
     * @example
     * // Delete one Tipo_perfil
     * const Tipo_perfil = await prisma.tipo_perfil.delete({
     *   where: {
     *     // ... filter to delete one Tipo_perfil
     *   }
     * })
     * 
     */
    delete<T extends tipo_perfilDeleteArgs>(args: SelectSubset<T, tipo_perfilDeleteArgs<ExtArgs>>): Prisma__tipo_perfilClient<$Result.GetResult<Prisma.$tipo_perfilPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Tipo_perfil.
     * @param {tipo_perfilUpdateArgs} args - Arguments to update one Tipo_perfil.
     * @example
     * // Update one Tipo_perfil
     * const tipo_perfil = await prisma.tipo_perfil.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends tipo_perfilUpdateArgs>(args: SelectSubset<T, tipo_perfilUpdateArgs<ExtArgs>>): Prisma__tipo_perfilClient<$Result.GetResult<Prisma.$tipo_perfilPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Tipo_perfils.
     * @param {tipo_perfilDeleteManyArgs} args - Arguments to filter Tipo_perfils to delete.
     * @example
     * // Delete a few Tipo_perfils
     * const { count } = await prisma.tipo_perfil.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends tipo_perfilDeleteManyArgs>(args?: SelectSubset<T, tipo_perfilDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Tipo_perfils.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {tipo_perfilUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Tipo_perfils
     * const tipo_perfil = await prisma.tipo_perfil.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends tipo_perfilUpdateManyArgs>(args: SelectSubset<T, tipo_perfilUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Tipo_perfils and returns the data updated in the database.
     * @param {tipo_perfilUpdateManyAndReturnArgs} args - Arguments to update many Tipo_perfils.
     * @example
     * // Update many Tipo_perfils
     * const tipo_perfil = await prisma.tipo_perfil.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Tipo_perfils and only return the `id_tipo_perfil`
     * const tipo_perfilWithId_tipo_perfilOnly = await prisma.tipo_perfil.updateManyAndReturn({
     *   select: { id_tipo_perfil: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends tipo_perfilUpdateManyAndReturnArgs>(args: SelectSubset<T, tipo_perfilUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$tipo_perfilPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Tipo_perfil.
     * @param {tipo_perfilUpsertArgs} args - Arguments to update or create a Tipo_perfil.
     * @example
     * // Update or create a Tipo_perfil
     * const tipo_perfil = await prisma.tipo_perfil.upsert({
     *   create: {
     *     // ... data to create a Tipo_perfil
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Tipo_perfil we want to update
     *   }
     * })
     */
    upsert<T extends tipo_perfilUpsertArgs>(args: SelectSubset<T, tipo_perfilUpsertArgs<ExtArgs>>): Prisma__tipo_perfilClient<$Result.GetResult<Prisma.$tipo_perfilPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Tipo_perfils.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {tipo_perfilCountArgs} args - Arguments to filter Tipo_perfils to count.
     * @example
     * // Count the number of Tipo_perfils
     * const count = await prisma.tipo_perfil.count({
     *   where: {
     *     // ... the filter for the Tipo_perfils we want to count
     *   }
     * })
    **/
    count<T extends tipo_perfilCountArgs>(
      args?: Subset<T, tipo_perfilCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], Tipo_perfilCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Tipo_perfil.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Tipo_perfilAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends Tipo_perfilAggregateArgs>(args: Subset<T, Tipo_perfilAggregateArgs>): Prisma.PrismaPromise<GetTipo_perfilAggregateType<T>>

    /**
     * Group by Tipo_perfil.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {tipo_perfilGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends tipo_perfilGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: tipo_perfilGroupByArgs['orderBy'] }
        : { orderBy?: tipo_perfilGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, tipo_perfilGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetTipo_perfilGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the tipo_perfil model
   */
  readonly fields: tipo_perfilFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for tipo_perfil.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__tipo_perfilClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    usuarios<T extends tipo_perfil$usuariosArgs<ExtArgs> = {}>(args?: Subset<T, tipo_perfil$usuariosArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$usuariosPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the tipo_perfil model
   */
  interface tipo_perfilFieldRefs {
    readonly id_tipo_perfil: FieldRef<"tipo_perfil", 'String'>
    readonly descricao: FieldRef<"tipo_perfil", 'String'>
  }
    

  // Custom InputTypes
  /**
   * tipo_perfil findUnique
   */
  export type tipo_perfilFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the tipo_perfil
     */
    select?: tipo_perfilSelect<ExtArgs> | null
    /**
     * Omit specific fields from the tipo_perfil
     */
    omit?: tipo_perfilOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: tipo_perfilInclude<ExtArgs> | null
    /**
     * Filter, which tipo_perfil to fetch.
     */
    where: tipo_perfilWhereUniqueInput
  }

  /**
   * tipo_perfil findUniqueOrThrow
   */
  export type tipo_perfilFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the tipo_perfil
     */
    select?: tipo_perfilSelect<ExtArgs> | null
    /**
     * Omit specific fields from the tipo_perfil
     */
    omit?: tipo_perfilOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: tipo_perfilInclude<ExtArgs> | null
    /**
     * Filter, which tipo_perfil to fetch.
     */
    where: tipo_perfilWhereUniqueInput
  }

  /**
   * tipo_perfil findFirst
   */
  export type tipo_perfilFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the tipo_perfil
     */
    select?: tipo_perfilSelect<ExtArgs> | null
    /**
     * Omit specific fields from the tipo_perfil
     */
    omit?: tipo_perfilOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: tipo_perfilInclude<ExtArgs> | null
    /**
     * Filter, which tipo_perfil to fetch.
     */
    where?: tipo_perfilWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of tipo_perfils to fetch.
     */
    orderBy?: tipo_perfilOrderByWithRelationInput | tipo_perfilOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for tipo_perfils.
     */
    cursor?: tipo_perfilWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` tipo_perfils from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` tipo_perfils.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of tipo_perfils.
     */
    distinct?: Tipo_perfilScalarFieldEnum | Tipo_perfilScalarFieldEnum[]
  }

  /**
   * tipo_perfil findFirstOrThrow
   */
  export type tipo_perfilFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the tipo_perfil
     */
    select?: tipo_perfilSelect<ExtArgs> | null
    /**
     * Omit specific fields from the tipo_perfil
     */
    omit?: tipo_perfilOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: tipo_perfilInclude<ExtArgs> | null
    /**
     * Filter, which tipo_perfil to fetch.
     */
    where?: tipo_perfilWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of tipo_perfils to fetch.
     */
    orderBy?: tipo_perfilOrderByWithRelationInput | tipo_perfilOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for tipo_perfils.
     */
    cursor?: tipo_perfilWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` tipo_perfils from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` tipo_perfils.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of tipo_perfils.
     */
    distinct?: Tipo_perfilScalarFieldEnum | Tipo_perfilScalarFieldEnum[]
  }

  /**
   * tipo_perfil findMany
   */
  export type tipo_perfilFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the tipo_perfil
     */
    select?: tipo_perfilSelect<ExtArgs> | null
    /**
     * Omit specific fields from the tipo_perfil
     */
    omit?: tipo_perfilOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: tipo_perfilInclude<ExtArgs> | null
    /**
     * Filter, which tipo_perfils to fetch.
     */
    where?: tipo_perfilWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of tipo_perfils to fetch.
     */
    orderBy?: tipo_perfilOrderByWithRelationInput | tipo_perfilOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing tipo_perfils.
     */
    cursor?: tipo_perfilWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` tipo_perfils from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` tipo_perfils.
     */
    skip?: number
    distinct?: Tipo_perfilScalarFieldEnum | Tipo_perfilScalarFieldEnum[]
  }

  /**
   * tipo_perfil create
   */
  export type tipo_perfilCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the tipo_perfil
     */
    select?: tipo_perfilSelect<ExtArgs> | null
    /**
     * Omit specific fields from the tipo_perfil
     */
    omit?: tipo_perfilOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: tipo_perfilInclude<ExtArgs> | null
    /**
     * The data needed to create a tipo_perfil.
     */
    data: XOR<tipo_perfilCreateInput, tipo_perfilUncheckedCreateInput>
  }

  /**
   * tipo_perfil createMany
   */
  export type tipo_perfilCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many tipo_perfils.
     */
    data: tipo_perfilCreateManyInput | tipo_perfilCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * tipo_perfil createManyAndReturn
   */
  export type tipo_perfilCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the tipo_perfil
     */
    select?: tipo_perfilSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the tipo_perfil
     */
    omit?: tipo_perfilOmit<ExtArgs> | null
    /**
     * The data used to create many tipo_perfils.
     */
    data: tipo_perfilCreateManyInput | tipo_perfilCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * tipo_perfil update
   */
  export type tipo_perfilUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the tipo_perfil
     */
    select?: tipo_perfilSelect<ExtArgs> | null
    /**
     * Omit specific fields from the tipo_perfil
     */
    omit?: tipo_perfilOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: tipo_perfilInclude<ExtArgs> | null
    /**
     * The data needed to update a tipo_perfil.
     */
    data: XOR<tipo_perfilUpdateInput, tipo_perfilUncheckedUpdateInput>
    /**
     * Choose, which tipo_perfil to update.
     */
    where: tipo_perfilWhereUniqueInput
  }

  /**
   * tipo_perfil updateMany
   */
  export type tipo_perfilUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update tipo_perfils.
     */
    data: XOR<tipo_perfilUpdateManyMutationInput, tipo_perfilUncheckedUpdateManyInput>
    /**
     * Filter which tipo_perfils to update
     */
    where?: tipo_perfilWhereInput
    /**
     * Limit how many tipo_perfils to update.
     */
    limit?: number
  }

  /**
   * tipo_perfil updateManyAndReturn
   */
  export type tipo_perfilUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the tipo_perfil
     */
    select?: tipo_perfilSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the tipo_perfil
     */
    omit?: tipo_perfilOmit<ExtArgs> | null
    /**
     * The data used to update tipo_perfils.
     */
    data: XOR<tipo_perfilUpdateManyMutationInput, tipo_perfilUncheckedUpdateManyInput>
    /**
     * Filter which tipo_perfils to update
     */
    where?: tipo_perfilWhereInput
    /**
     * Limit how many tipo_perfils to update.
     */
    limit?: number
  }

  /**
   * tipo_perfil upsert
   */
  export type tipo_perfilUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the tipo_perfil
     */
    select?: tipo_perfilSelect<ExtArgs> | null
    /**
     * Omit specific fields from the tipo_perfil
     */
    omit?: tipo_perfilOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: tipo_perfilInclude<ExtArgs> | null
    /**
     * The filter to search for the tipo_perfil to update in case it exists.
     */
    where: tipo_perfilWhereUniqueInput
    /**
     * In case the tipo_perfil found by the `where` argument doesn't exist, create a new tipo_perfil with this data.
     */
    create: XOR<tipo_perfilCreateInput, tipo_perfilUncheckedCreateInput>
    /**
     * In case the tipo_perfil was found with the provided `where` argument, update it with this data.
     */
    update: XOR<tipo_perfilUpdateInput, tipo_perfilUncheckedUpdateInput>
  }

  /**
   * tipo_perfil delete
   */
  export type tipo_perfilDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the tipo_perfil
     */
    select?: tipo_perfilSelect<ExtArgs> | null
    /**
     * Omit specific fields from the tipo_perfil
     */
    omit?: tipo_perfilOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: tipo_perfilInclude<ExtArgs> | null
    /**
     * Filter which tipo_perfil to delete.
     */
    where: tipo_perfilWhereUniqueInput
  }

  /**
   * tipo_perfil deleteMany
   */
  export type tipo_perfilDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which tipo_perfils to delete
     */
    where?: tipo_perfilWhereInput
    /**
     * Limit how many tipo_perfils to delete.
     */
    limit?: number
  }

  /**
   * tipo_perfil.usuarios
   */
  export type tipo_perfil$usuariosArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usuarios
     */
    select?: usuariosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usuarios
     */
    omit?: usuariosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usuariosInclude<ExtArgs> | null
    where?: usuariosWhereInput
    orderBy?: usuariosOrderByWithRelationInput | usuariosOrderByWithRelationInput[]
    cursor?: usuariosWhereUniqueInput
    take?: number
    skip?: number
    distinct?: UsuariosScalarFieldEnum | UsuariosScalarFieldEnum[]
  }

  /**
   * tipo_perfil without action
   */
  export type tipo_perfilDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the tipo_perfil
     */
    select?: tipo_perfilSelect<ExtArgs> | null
    /**
     * Omit specific fields from the tipo_perfil
     */
    omit?: tipo_perfilOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: tipo_perfilInclude<ExtArgs> | null
  }


  /**
   * Model usuarios
   */

  export type AggregateUsuarios = {
    _count: UsuariosCountAggregateOutputType | null
    _avg: UsuariosAvgAggregateOutputType | null
    _sum: UsuariosSumAggregateOutputType | null
    _min: UsuariosMinAggregateOutputType | null
    _max: UsuariosMaxAggregateOutputType | null
  }

  export type UsuariosAvgAggregateOutputType = {
    id_usuario: number | null
  }

  export type UsuariosSumAggregateOutputType = {
    id_usuario: number | null
  }

  export type UsuariosMinAggregateOutputType = {
    id_usuario: number | null
    nome: string | null
    email: string | null
    senha: string | null
    id_tipo_perfil: string | null
  }

  export type UsuariosMaxAggregateOutputType = {
    id_usuario: number | null
    nome: string | null
    email: string | null
    senha: string | null
    id_tipo_perfil: string | null
  }

  export type UsuariosCountAggregateOutputType = {
    id_usuario: number
    nome: number
    email: number
    senha: number
    id_tipo_perfil: number
    _all: number
  }


  export type UsuariosAvgAggregateInputType = {
    id_usuario?: true
  }

  export type UsuariosSumAggregateInputType = {
    id_usuario?: true
  }

  export type UsuariosMinAggregateInputType = {
    id_usuario?: true
    nome?: true
    email?: true
    senha?: true
    id_tipo_perfil?: true
  }

  export type UsuariosMaxAggregateInputType = {
    id_usuario?: true
    nome?: true
    email?: true
    senha?: true
    id_tipo_perfil?: true
  }

  export type UsuariosCountAggregateInputType = {
    id_usuario?: true
    nome?: true
    email?: true
    senha?: true
    id_tipo_perfil?: true
    _all?: true
  }

  export type UsuariosAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which usuarios to aggregate.
     */
    where?: usuariosWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of usuarios to fetch.
     */
    orderBy?: usuariosOrderByWithRelationInput | usuariosOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: usuariosWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` usuarios from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` usuarios.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned usuarios
    **/
    _count?: true | UsuariosCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: UsuariosAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: UsuariosSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: UsuariosMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: UsuariosMaxAggregateInputType
  }

  export type GetUsuariosAggregateType<T extends UsuariosAggregateArgs> = {
        [P in keyof T & keyof AggregateUsuarios]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUsuarios[P]>
      : GetScalarType<T[P], AggregateUsuarios[P]>
  }




  export type usuariosGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: usuariosWhereInput
    orderBy?: usuariosOrderByWithAggregationInput | usuariosOrderByWithAggregationInput[]
    by: UsuariosScalarFieldEnum[] | UsuariosScalarFieldEnum
    having?: usuariosScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: UsuariosCountAggregateInputType | true
    _avg?: UsuariosAvgAggregateInputType
    _sum?: UsuariosSumAggregateInputType
    _min?: UsuariosMinAggregateInputType
    _max?: UsuariosMaxAggregateInputType
  }

  export type UsuariosGroupByOutputType = {
    id_usuario: number
    nome: string
    email: string
    senha: string
    id_tipo_perfil: string
    _count: UsuariosCountAggregateOutputType | null
    _avg: UsuariosAvgAggregateOutputType | null
    _sum: UsuariosSumAggregateOutputType | null
    _min: UsuariosMinAggregateOutputType | null
    _max: UsuariosMaxAggregateOutputType | null
  }

  type GetUsuariosGroupByPayload<T extends usuariosGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<UsuariosGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof UsuariosGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], UsuariosGroupByOutputType[P]>
            : GetScalarType<T[P], UsuariosGroupByOutputType[P]>
        }
      >
    >


  export type usuariosSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id_usuario?: boolean
    nome?: boolean
    email?: boolean
    senha?: boolean
    id_tipo_perfil?: boolean
    eventos?: boolean | usuarios$eventosArgs<ExtArgs>
    inscricoes?: boolean | usuarios$inscricoesArgs<ExtArgs>
    tipo_perfil?: boolean | tipo_perfilDefaultArgs<ExtArgs>
    _count?: boolean | UsuariosCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["usuarios"]>

  export type usuariosSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id_usuario?: boolean
    nome?: boolean
    email?: boolean
    senha?: boolean
    id_tipo_perfil?: boolean
    tipo_perfil?: boolean | tipo_perfilDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["usuarios"]>

  export type usuariosSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id_usuario?: boolean
    nome?: boolean
    email?: boolean
    senha?: boolean
    id_tipo_perfil?: boolean
    tipo_perfil?: boolean | tipo_perfilDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["usuarios"]>

  export type usuariosSelectScalar = {
    id_usuario?: boolean
    nome?: boolean
    email?: boolean
    senha?: boolean
    id_tipo_perfil?: boolean
  }

  export type usuariosOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id_usuario" | "nome" | "email" | "senha" | "id_tipo_perfil", ExtArgs["result"]["usuarios"]>
  export type usuariosInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    eventos?: boolean | usuarios$eventosArgs<ExtArgs>
    inscricoes?: boolean | usuarios$inscricoesArgs<ExtArgs>
    tipo_perfil?: boolean | tipo_perfilDefaultArgs<ExtArgs>
    _count?: boolean | UsuariosCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type usuariosIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    tipo_perfil?: boolean | tipo_perfilDefaultArgs<ExtArgs>
  }
  export type usuariosIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    tipo_perfil?: boolean | tipo_perfilDefaultArgs<ExtArgs>
  }

  export type $usuariosPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "usuarios"
    objects: {
      eventos: Prisma.$eventosPayload<ExtArgs>[]
      inscricoes: Prisma.$inscricoesPayload<ExtArgs>[]
      tipo_perfil: Prisma.$tipo_perfilPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id_usuario: number
      nome: string
      email: string
      senha: string
      id_tipo_perfil: string
    }, ExtArgs["result"]["usuarios"]>
    composites: {}
  }

  type usuariosGetPayload<S extends boolean | null | undefined | usuariosDefaultArgs> = $Result.GetResult<Prisma.$usuariosPayload, S>

  type usuariosCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<usuariosFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: UsuariosCountAggregateInputType | true
    }

  export interface usuariosDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['usuarios'], meta: { name: 'usuarios' } }
    /**
     * Find zero or one Usuarios that matches the filter.
     * @param {usuariosFindUniqueArgs} args - Arguments to find a Usuarios
     * @example
     * // Get one Usuarios
     * const usuarios = await prisma.usuarios.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends usuariosFindUniqueArgs>(args: SelectSubset<T, usuariosFindUniqueArgs<ExtArgs>>): Prisma__usuariosClient<$Result.GetResult<Prisma.$usuariosPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Usuarios that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {usuariosFindUniqueOrThrowArgs} args - Arguments to find a Usuarios
     * @example
     * // Get one Usuarios
     * const usuarios = await prisma.usuarios.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends usuariosFindUniqueOrThrowArgs>(args: SelectSubset<T, usuariosFindUniqueOrThrowArgs<ExtArgs>>): Prisma__usuariosClient<$Result.GetResult<Prisma.$usuariosPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Usuarios that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usuariosFindFirstArgs} args - Arguments to find a Usuarios
     * @example
     * // Get one Usuarios
     * const usuarios = await prisma.usuarios.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends usuariosFindFirstArgs>(args?: SelectSubset<T, usuariosFindFirstArgs<ExtArgs>>): Prisma__usuariosClient<$Result.GetResult<Prisma.$usuariosPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Usuarios that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usuariosFindFirstOrThrowArgs} args - Arguments to find a Usuarios
     * @example
     * // Get one Usuarios
     * const usuarios = await prisma.usuarios.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends usuariosFindFirstOrThrowArgs>(args?: SelectSubset<T, usuariosFindFirstOrThrowArgs<ExtArgs>>): Prisma__usuariosClient<$Result.GetResult<Prisma.$usuariosPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Usuarios that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usuariosFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Usuarios
     * const usuarios = await prisma.usuarios.findMany()
     * 
     * // Get first 10 Usuarios
     * const usuarios = await prisma.usuarios.findMany({ take: 10 })
     * 
     * // Only select the `id_usuario`
     * const usuariosWithId_usuarioOnly = await prisma.usuarios.findMany({ select: { id_usuario: true } })
     * 
     */
    findMany<T extends usuariosFindManyArgs>(args?: SelectSubset<T, usuariosFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$usuariosPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Usuarios.
     * @param {usuariosCreateArgs} args - Arguments to create a Usuarios.
     * @example
     * // Create one Usuarios
     * const Usuarios = await prisma.usuarios.create({
     *   data: {
     *     // ... data to create a Usuarios
     *   }
     * })
     * 
     */
    create<T extends usuariosCreateArgs>(args: SelectSubset<T, usuariosCreateArgs<ExtArgs>>): Prisma__usuariosClient<$Result.GetResult<Prisma.$usuariosPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Usuarios.
     * @param {usuariosCreateManyArgs} args - Arguments to create many Usuarios.
     * @example
     * // Create many Usuarios
     * const usuarios = await prisma.usuarios.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends usuariosCreateManyArgs>(args?: SelectSubset<T, usuariosCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Usuarios and returns the data saved in the database.
     * @param {usuariosCreateManyAndReturnArgs} args - Arguments to create many Usuarios.
     * @example
     * // Create many Usuarios
     * const usuarios = await prisma.usuarios.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Usuarios and only return the `id_usuario`
     * const usuariosWithId_usuarioOnly = await prisma.usuarios.createManyAndReturn({
     *   select: { id_usuario: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends usuariosCreateManyAndReturnArgs>(args?: SelectSubset<T, usuariosCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$usuariosPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Usuarios.
     * @param {usuariosDeleteArgs} args - Arguments to delete one Usuarios.
     * @example
     * // Delete one Usuarios
     * const Usuarios = await prisma.usuarios.delete({
     *   where: {
     *     // ... filter to delete one Usuarios
     *   }
     * })
     * 
     */
    delete<T extends usuariosDeleteArgs>(args: SelectSubset<T, usuariosDeleteArgs<ExtArgs>>): Prisma__usuariosClient<$Result.GetResult<Prisma.$usuariosPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Usuarios.
     * @param {usuariosUpdateArgs} args - Arguments to update one Usuarios.
     * @example
     * // Update one Usuarios
     * const usuarios = await prisma.usuarios.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends usuariosUpdateArgs>(args: SelectSubset<T, usuariosUpdateArgs<ExtArgs>>): Prisma__usuariosClient<$Result.GetResult<Prisma.$usuariosPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Usuarios.
     * @param {usuariosDeleteManyArgs} args - Arguments to filter Usuarios to delete.
     * @example
     * // Delete a few Usuarios
     * const { count } = await prisma.usuarios.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends usuariosDeleteManyArgs>(args?: SelectSubset<T, usuariosDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Usuarios.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usuariosUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Usuarios
     * const usuarios = await prisma.usuarios.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends usuariosUpdateManyArgs>(args: SelectSubset<T, usuariosUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Usuarios and returns the data updated in the database.
     * @param {usuariosUpdateManyAndReturnArgs} args - Arguments to update many Usuarios.
     * @example
     * // Update many Usuarios
     * const usuarios = await prisma.usuarios.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Usuarios and only return the `id_usuario`
     * const usuariosWithId_usuarioOnly = await prisma.usuarios.updateManyAndReturn({
     *   select: { id_usuario: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends usuariosUpdateManyAndReturnArgs>(args: SelectSubset<T, usuariosUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$usuariosPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Usuarios.
     * @param {usuariosUpsertArgs} args - Arguments to update or create a Usuarios.
     * @example
     * // Update or create a Usuarios
     * const usuarios = await prisma.usuarios.upsert({
     *   create: {
     *     // ... data to create a Usuarios
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Usuarios we want to update
     *   }
     * })
     */
    upsert<T extends usuariosUpsertArgs>(args: SelectSubset<T, usuariosUpsertArgs<ExtArgs>>): Prisma__usuariosClient<$Result.GetResult<Prisma.$usuariosPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Usuarios.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usuariosCountArgs} args - Arguments to filter Usuarios to count.
     * @example
     * // Count the number of Usuarios
     * const count = await prisma.usuarios.count({
     *   where: {
     *     // ... the filter for the Usuarios we want to count
     *   }
     * })
    **/
    count<T extends usuariosCountArgs>(
      args?: Subset<T, usuariosCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], UsuariosCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Usuarios.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UsuariosAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends UsuariosAggregateArgs>(args: Subset<T, UsuariosAggregateArgs>): Prisma.PrismaPromise<GetUsuariosAggregateType<T>>

    /**
     * Group by Usuarios.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usuariosGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends usuariosGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: usuariosGroupByArgs['orderBy'] }
        : { orderBy?: usuariosGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, usuariosGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUsuariosGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the usuarios model
   */
  readonly fields: usuariosFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for usuarios.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__usuariosClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    eventos<T extends usuarios$eventosArgs<ExtArgs> = {}>(args?: Subset<T, usuarios$eventosArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$eventosPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    inscricoes<T extends usuarios$inscricoesArgs<ExtArgs> = {}>(args?: Subset<T, usuarios$inscricoesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$inscricoesPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    tipo_perfil<T extends tipo_perfilDefaultArgs<ExtArgs> = {}>(args?: Subset<T, tipo_perfilDefaultArgs<ExtArgs>>): Prisma__tipo_perfilClient<$Result.GetResult<Prisma.$tipo_perfilPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the usuarios model
   */
  interface usuariosFieldRefs {
    readonly id_usuario: FieldRef<"usuarios", 'Int'>
    readonly nome: FieldRef<"usuarios", 'String'>
    readonly email: FieldRef<"usuarios", 'String'>
    readonly senha: FieldRef<"usuarios", 'String'>
    readonly id_tipo_perfil: FieldRef<"usuarios", 'String'>
  }
    

  // Custom InputTypes
  /**
   * usuarios findUnique
   */
  export type usuariosFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usuarios
     */
    select?: usuariosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usuarios
     */
    omit?: usuariosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usuariosInclude<ExtArgs> | null
    /**
     * Filter, which usuarios to fetch.
     */
    where: usuariosWhereUniqueInput
  }

  /**
   * usuarios findUniqueOrThrow
   */
  export type usuariosFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usuarios
     */
    select?: usuariosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usuarios
     */
    omit?: usuariosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usuariosInclude<ExtArgs> | null
    /**
     * Filter, which usuarios to fetch.
     */
    where: usuariosWhereUniqueInput
  }

  /**
   * usuarios findFirst
   */
  export type usuariosFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usuarios
     */
    select?: usuariosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usuarios
     */
    omit?: usuariosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usuariosInclude<ExtArgs> | null
    /**
     * Filter, which usuarios to fetch.
     */
    where?: usuariosWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of usuarios to fetch.
     */
    orderBy?: usuariosOrderByWithRelationInput | usuariosOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for usuarios.
     */
    cursor?: usuariosWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` usuarios from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` usuarios.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of usuarios.
     */
    distinct?: UsuariosScalarFieldEnum | UsuariosScalarFieldEnum[]
  }

  /**
   * usuarios findFirstOrThrow
   */
  export type usuariosFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usuarios
     */
    select?: usuariosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usuarios
     */
    omit?: usuariosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usuariosInclude<ExtArgs> | null
    /**
     * Filter, which usuarios to fetch.
     */
    where?: usuariosWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of usuarios to fetch.
     */
    orderBy?: usuariosOrderByWithRelationInput | usuariosOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for usuarios.
     */
    cursor?: usuariosWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` usuarios from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` usuarios.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of usuarios.
     */
    distinct?: UsuariosScalarFieldEnum | UsuariosScalarFieldEnum[]
  }

  /**
   * usuarios findMany
   */
  export type usuariosFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usuarios
     */
    select?: usuariosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usuarios
     */
    omit?: usuariosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usuariosInclude<ExtArgs> | null
    /**
     * Filter, which usuarios to fetch.
     */
    where?: usuariosWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of usuarios to fetch.
     */
    orderBy?: usuariosOrderByWithRelationInput | usuariosOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing usuarios.
     */
    cursor?: usuariosWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` usuarios from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` usuarios.
     */
    skip?: number
    distinct?: UsuariosScalarFieldEnum | UsuariosScalarFieldEnum[]
  }

  /**
   * usuarios create
   */
  export type usuariosCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usuarios
     */
    select?: usuariosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usuarios
     */
    omit?: usuariosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usuariosInclude<ExtArgs> | null
    /**
     * The data needed to create a usuarios.
     */
    data: XOR<usuariosCreateInput, usuariosUncheckedCreateInput>
  }

  /**
   * usuarios createMany
   */
  export type usuariosCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many usuarios.
     */
    data: usuariosCreateManyInput | usuariosCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * usuarios createManyAndReturn
   */
  export type usuariosCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usuarios
     */
    select?: usuariosSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the usuarios
     */
    omit?: usuariosOmit<ExtArgs> | null
    /**
     * The data used to create many usuarios.
     */
    data: usuariosCreateManyInput | usuariosCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usuariosIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * usuarios update
   */
  export type usuariosUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usuarios
     */
    select?: usuariosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usuarios
     */
    omit?: usuariosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usuariosInclude<ExtArgs> | null
    /**
     * The data needed to update a usuarios.
     */
    data: XOR<usuariosUpdateInput, usuariosUncheckedUpdateInput>
    /**
     * Choose, which usuarios to update.
     */
    where: usuariosWhereUniqueInput
  }

  /**
   * usuarios updateMany
   */
  export type usuariosUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update usuarios.
     */
    data: XOR<usuariosUpdateManyMutationInput, usuariosUncheckedUpdateManyInput>
    /**
     * Filter which usuarios to update
     */
    where?: usuariosWhereInput
    /**
     * Limit how many usuarios to update.
     */
    limit?: number
  }

  /**
   * usuarios updateManyAndReturn
   */
  export type usuariosUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usuarios
     */
    select?: usuariosSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the usuarios
     */
    omit?: usuariosOmit<ExtArgs> | null
    /**
     * The data used to update usuarios.
     */
    data: XOR<usuariosUpdateManyMutationInput, usuariosUncheckedUpdateManyInput>
    /**
     * Filter which usuarios to update
     */
    where?: usuariosWhereInput
    /**
     * Limit how many usuarios to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usuariosIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * usuarios upsert
   */
  export type usuariosUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usuarios
     */
    select?: usuariosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usuarios
     */
    omit?: usuariosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usuariosInclude<ExtArgs> | null
    /**
     * The filter to search for the usuarios to update in case it exists.
     */
    where: usuariosWhereUniqueInput
    /**
     * In case the usuarios found by the `where` argument doesn't exist, create a new usuarios with this data.
     */
    create: XOR<usuariosCreateInput, usuariosUncheckedCreateInput>
    /**
     * In case the usuarios was found with the provided `where` argument, update it with this data.
     */
    update: XOR<usuariosUpdateInput, usuariosUncheckedUpdateInput>
  }

  /**
   * usuarios delete
   */
  export type usuariosDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usuarios
     */
    select?: usuariosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usuarios
     */
    omit?: usuariosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usuariosInclude<ExtArgs> | null
    /**
     * Filter which usuarios to delete.
     */
    where: usuariosWhereUniqueInput
  }

  /**
   * usuarios deleteMany
   */
  export type usuariosDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which usuarios to delete
     */
    where?: usuariosWhereInput
    /**
     * Limit how many usuarios to delete.
     */
    limit?: number
  }

  /**
   * usuarios.eventos
   */
  export type usuarios$eventosArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eventos
     */
    select?: eventosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eventos
     */
    omit?: eventosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: eventosInclude<ExtArgs> | null
    where?: eventosWhereInput
    orderBy?: eventosOrderByWithRelationInput | eventosOrderByWithRelationInput[]
    cursor?: eventosWhereUniqueInput
    take?: number
    skip?: number
    distinct?: EventosScalarFieldEnum | EventosScalarFieldEnum[]
  }

  /**
   * usuarios.inscricoes
   */
  export type usuarios$inscricoesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the inscricoes
     */
    select?: inscricoesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the inscricoes
     */
    omit?: inscricoesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: inscricoesInclude<ExtArgs> | null
    where?: inscricoesWhereInput
    orderBy?: inscricoesOrderByWithRelationInput | inscricoesOrderByWithRelationInput[]
    cursor?: inscricoesWhereUniqueInput
    take?: number
    skip?: number
    distinct?: InscricoesScalarFieldEnum | InscricoesScalarFieldEnum[]
  }

  /**
   * usuarios without action
   */
  export type usuariosDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usuarios
     */
    select?: usuariosSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usuarios
     */
    omit?: usuariosOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: usuariosInclude<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    ReadUncommitted: 'ReadUncommitted',
    ReadCommitted: 'ReadCommitted',
    RepeatableRead: 'RepeatableRead',
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const EventosScalarFieldEnum: {
    id_evento: 'id_evento',
    titulo: 'titulo',
    descricao: 'descricao',
    palestrante: 'palestrante',
    carga_horaria: 'carga_horaria',
    vagas_limite: 'vagas_limite',
    data_inicio: 'data_inicio',
    data_fim: 'data_fim',
    hora_inicio: 'hora_inicio',
    hora_fim: 'hora_fim',
    objetivo_pedagogico: 'objetivo_pedagogico',
    id_local: 'id_local',
    id_usuario: 'id_usuario'
  };

  export type EventosScalarFieldEnum = (typeof EventosScalarFieldEnum)[keyof typeof EventosScalarFieldEnum]


  export const InscricoesScalarFieldEnum: {
    id_inscricao: 'id_inscricao',
    id_aluno: 'id_aluno',
    id_evento: 'id_evento',
    presenca_entrada: 'presenca_entrada',
    horario_entrada: 'horario_entrada',
    presenca_saida: 'presenca_saida',
    horario_saida: 'horario_saida',
    codigo_validacao: 'codigo_validacao',
    data_inscricao: 'data_inscricao'
  };

  export type InscricoesScalarFieldEnum = (typeof InscricoesScalarFieldEnum)[keyof typeof InscricoesScalarFieldEnum]


  export const LocalScalarFieldEnum: {
    id_local: 'id_local',
    nome_local: 'nome_local',
    capacidade: 'capacidade'
  };

  export type LocalScalarFieldEnum = (typeof LocalScalarFieldEnum)[keyof typeof LocalScalarFieldEnum]


  export const Tipo_perfilScalarFieldEnum: {
    id_tipo_perfil: 'id_tipo_perfil',
    descricao: 'descricao'
  };

  export type Tipo_perfilScalarFieldEnum = (typeof Tipo_perfilScalarFieldEnum)[keyof typeof Tipo_perfilScalarFieldEnum]


  export const UsuariosScalarFieldEnum: {
    id_usuario: 'id_usuario',
    nome: 'nome',
    email: 'email',
    senha: 'senha',
    id_tipo_perfil: 'id_tipo_perfil'
  };

  export type UsuariosScalarFieldEnum = (typeof UsuariosScalarFieldEnum)[keyof typeof UsuariosScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const QueryMode: {
    default: 'default',
    insensitive: 'insensitive'
  };

  export type QueryMode = (typeof QueryMode)[keyof typeof QueryMode]


  export const NullsOrder: {
    first: 'first',
    last: 'last'
  };

  export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder]


  /**
   * Field references
   */


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    


  /**
   * Reference to a field of type 'Int[]'
   */
  export type ListIntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int[]'>
    


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'String[]'
   */
  export type ListStringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String[]'>
    


  /**
   * Reference to a field of type 'DateTime'
   */
  export type DateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime'>
    


  /**
   * Reference to a field of type 'DateTime[]'
   */
  export type ListDateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime[]'>
    


  /**
   * Reference to a field of type 'Boolean'
   */
  export type BooleanFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Boolean'>
    


  /**
   * Reference to a field of type 'Float'
   */
  export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>
    


  /**
   * Reference to a field of type 'Float[]'
   */
  export type ListFloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float[]'>
    
  /**
   * Deep Input Types
   */


  export type eventosWhereInput = {
    AND?: eventosWhereInput | eventosWhereInput[]
    OR?: eventosWhereInput[]
    NOT?: eventosWhereInput | eventosWhereInput[]
    id_evento?: IntFilter<"eventos"> | number
    titulo?: StringFilter<"eventos"> | string
    descricao?: StringFilter<"eventos"> | string
    palestrante?: StringFilter<"eventos"> | string
    carga_horaria?: IntFilter<"eventos"> | number
    vagas_limite?: IntFilter<"eventos"> | number
    data_inicio?: DateTimeFilter<"eventos"> | Date | string
    data_fim?: DateTimeFilter<"eventos"> | Date | string
    hora_inicio?: DateTimeFilter<"eventos"> | Date | string
    hora_fim?: DateTimeFilter<"eventos"> | Date | string
    objetivo_pedagogico?: StringNullableFilter<"eventos"> | string | null
    id_local?: StringNullableFilter<"eventos"> | string | null
    id_usuario?: IntFilter<"eventos"> | number
    usuarios?: XOR<UsuariosScalarRelationFilter, usuariosWhereInput>
    local?: XOR<LocalNullableScalarRelationFilter, localWhereInput> | null
    inscricoes?: InscricoesListRelationFilter
  }

  export type eventosOrderByWithRelationInput = {
    id_evento?: SortOrder
    titulo?: SortOrder
    descricao?: SortOrder
    palestrante?: SortOrder
    carga_horaria?: SortOrder
    vagas_limite?: SortOrder
    data_inicio?: SortOrder
    data_fim?: SortOrder
    hora_inicio?: SortOrder
    hora_fim?: SortOrder
    objetivo_pedagogico?: SortOrderInput | SortOrder
    id_local?: SortOrderInput | SortOrder
    id_usuario?: SortOrder
    usuarios?: usuariosOrderByWithRelationInput
    local?: localOrderByWithRelationInput
    inscricoes?: inscricoesOrderByRelationAggregateInput
  }

  export type eventosWhereUniqueInput = Prisma.AtLeast<{
    id_evento?: number
    AND?: eventosWhereInput | eventosWhereInput[]
    OR?: eventosWhereInput[]
    NOT?: eventosWhereInput | eventosWhereInput[]
    titulo?: StringFilter<"eventos"> | string
    descricao?: StringFilter<"eventos"> | string
    palestrante?: StringFilter<"eventos"> | string
    carga_horaria?: IntFilter<"eventos"> | number
    vagas_limite?: IntFilter<"eventos"> | number
    data_inicio?: DateTimeFilter<"eventos"> | Date | string
    data_fim?: DateTimeFilter<"eventos"> | Date | string
    hora_inicio?: DateTimeFilter<"eventos"> | Date | string
    hora_fim?: DateTimeFilter<"eventos"> | Date | string
    objetivo_pedagogico?: StringNullableFilter<"eventos"> | string | null
    id_local?: StringNullableFilter<"eventos"> | string | null
    id_usuario?: IntFilter<"eventos"> | number
    usuarios?: XOR<UsuariosScalarRelationFilter, usuariosWhereInput>
    local?: XOR<LocalNullableScalarRelationFilter, localWhereInput> | null
    inscricoes?: InscricoesListRelationFilter
  }, "id_evento">

  export type eventosOrderByWithAggregationInput = {
    id_evento?: SortOrder
    titulo?: SortOrder
    descricao?: SortOrder
    palestrante?: SortOrder
    carga_horaria?: SortOrder
    vagas_limite?: SortOrder
    data_inicio?: SortOrder
    data_fim?: SortOrder
    hora_inicio?: SortOrder
    hora_fim?: SortOrder
    objetivo_pedagogico?: SortOrderInput | SortOrder
    id_local?: SortOrderInput | SortOrder
    id_usuario?: SortOrder
    _count?: eventosCountOrderByAggregateInput
    _avg?: eventosAvgOrderByAggregateInput
    _max?: eventosMaxOrderByAggregateInput
    _min?: eventosMinOrderByAggregateInput
    _sum?: eventosSumOrderByAggregateInput
  }

  export type eventosScalarWhereWithAggregatesInput = {
    AND?: eventosScalarWhereWithAggregatesInput | eventosScalarWhereWithAggregatesInput[]
    OR?: eventosScalarWhereWithAggregatesInput[]
    NOT?: eventosScalarWhereWithAggregatesInput | eventosScalarWhereWithAggregatesInput[]
    id_evento?: IntWithAggregatesFilter<"eventos"> | number
    titulo?: StringWithAggregatesFilter<"eventos"> | string
    descricao?: StringWithAggregatesFilter<"eventos"> | string
    palestrante?: StringWithAggregatesFilter<"eventos"> | string
    carga_horaria?: IntWithAggregatesFilter<"eventos"> | number
    vagas_limite?: IntWithAggregatesFilter<"eventos"> | number
    data_inicio?: DateTimeWithAggregatesFilter<"eventos"> | Date | string
    data_fim?: DateTimeWithAggregatesFilter<"eventos"> | Date | string
    hora_inicio?: DateTimeWithAggregatesFilter<"eventos"> | Date | string
    hora_fim?: DateTimeWithAggregatesFilter<"eventos"> | Date | string
    objetivo_pedagogico?: StringNullableWithAggregatesFilter<"eventos"> | string | null
    id_local?: StringNullableWithAggregatesFilter<"eventos"> | string | null
    id_usuario?: IntWithAggregatesFilter<"eventos"> | number
  }

  export type inscricoesWhereInput = {
    AND?: inscricoesWhereInput | inscricoesWhereInput[]
    OR?: inscricoesWhereInput[]
    NOT?: inscricoesWhereInput | inscricoesWhereInput[]
    id_inscricao?: IntFilter<"inscricoes"> | number
    id_aluno?: IntFilter<"inscricoes"> | number
    id_evento?: IntFilter<"inscricoes"> | number
    presenca_entrada?: BoolNullableFilter<"inscricoes"> | boolean | null
    horario_entrada?: DateTimeNullableFilter<"inscricoes"> | Date | string | null
    presenca_saida?: BoolNullableFilter<"inscricoes"> | boolean | null
    horario_saida?: DateTimeNullableFilter<"inscricoes"> | Date | string | null
    codigo_validacao?: StringNullableFilter<"inscricoes"> | string | null
    data_inscricao?: DateTimeNullableFilter<"inscricoes"> | Date | string | null
    usuarios?: XOR<UsuariosScalarRelationFilter, usuariosWhereInput>
    eventos?: XOR<EventosScalarRelationFilter, eventosWhereInput>
  }

  export type inscricoesOrderByWithRelationInput = {
    id_inscricao?: SortOrder
    id_aluno?: SortOrder
    id_evento?: SortOrder
    presenca_entrada?: SortOrderInput | SortOrder
    horario_entrada?: SortOrderInput | SortOrder
    presenca_saida?: SortOrderInput | SortOrder
    horario_saida?: SortOrderInput | SortOrder
    codigo_validacao?: SortOrderInput | SortOrder
    data_inscricao?: SortOrderInput | SortOrder
    usuarios?: usuariosOrderByWithRelationInput
    eventos?: eventosOrderByWithRelationInput
  }

  export type inscricoesWhereUniqueInput = Prisma.AtLeast<{
    id_inscricao?: number
    id_aluno_id_evento?: inscricoesId_alunoId_eventoCompoundUniqueInput
    AND?: inscricoesWhereInput | inscricoesWhereInput[]
    OR?: inscricoesWhereInput[]
    NOT?: inscricoesWhereInput | inscricoesWhereInput[]
    id_aluno?: IntFilter<"inscricoes"> | number
    id_evento?: IntFilter<"inscricoes"> | number
    presenca_entrada?: BoolNullableFilter<"inscricoes"> | boolean | null
    horario_entrada?: DateTimeNullableFilter<"inscricoes"> | Date | string | null
    presenca_saida?: BoolNullableFilter<"inscricoes"> | boolean | null
    horario_saida?: DateTimeNullableFilter<"inscricoes"> | Date | string | null
    codigo_validacao?: StringNullableFilter<"inscricoes"> | string | null
    data_inscricao?: DateTimeNullableFilter<"inscricoes"> | Date | string | null
    usuarios?: XOR<UsuariosScalarRelationFilter, usuariosWhereInput>
    eventos?: XOR<EventosScalarRelationFilter, eventosWhereInput>
  }, "id_inscricao" | "id_aluno_id_evento">

  export type inscricoesOrderByWithAggregationInput = {
    id_inscricao?: SortOrder
    id_aluno?: SortOrder
    id_evento?: SortOrder
    presenca_entrada?: SortOrderInput | SortOrder
    horario_entrada?: SortOrderInput | SortOrder
    presenca_saida?: SortOrderInput | SortOrder
    horario_saida?: SortOrderInput | SortOrder
    codigo_validacao?: SortOrderInput | SortOrder
    data_inscricao?: SortOrderInput | SortOrder
    _count?: inscricoesCountOrderByAggregateInput
    _avg?: inscricoesAvgOrderByAggregateInput
    _max?: inscricoesMaxOrderByAggregateInput
    _min?: inscricoesMinOrderByAggregateInput
    _sum?: inscricoesSumOrderByAggregateInput
  }

  export type inscricoesScalarWhereWithAggregatesInput = {
    AND?: inscricoesScalarWhereWithAggregatesInput | inscricoesScalarWhereWithAggregatesInput[]
    OR?: inscricoesScalarWhereWithAggregatesInput[]
    NOT?: inscricoesScalarWhereWithAggregatesInput | inscricoesScalarWhereWithAggregatesInput[]
    id_inscricao?: IntWithAggregatesFilter<"inscricoes"> | number
    id_aluno?: IntWithAggregatesFilter<"inscricoes"> | number
    id_evento?: IntWithAggregatesFilter<"inscricoes"> | number
    presenca_entrada?: BoolNullableWithAggregatesFilter<"inscricoes"> | boolean | null
    horario_entrada?: DateTimeNullableWithAggregatesFilter<"inscricoes"> | Date | string | null
    presenca_saida?: BoolNullableWithAggregatesFilter<"inscricoes"> | boolean | null
    horario_saida?: DateTimeNullableWithAggregatesFilter<"inscricoes"> | Date | string | null
    codigo_validacao?: StringNullableWithAggregatesFilter<"inscricoes"> | string | null
    data_inscricao?: DateTimeNullableWithAggregatesFilter<"inscricoes"> | Date | string | null
  }

  export type localWhereInput = {
    AND?: localWhereInput | localWhereInput[]
    OR?: localWhereInput[]
    NOT?: localWhereInput | localWhereInput[]
    id_local?: StringFilter<"local"> | string
    nome_local?: StringFilter<"local"> | string
    capacidade?: IntNullableFilter<"local"> | number | null
    eventos?: EventosListRelationFilter
  }

  export type localOrderByWithRelationInput = {
    id_local?: SortOrder
    nome_local?: SortOrder
    capacidade?: SortOrderInput | SortOrder
    eventos?: eventosOrderByRelationAggregateInput
  }

  export type localWhereUniqueInput = Prisma.AtLeast<{
    id_local?: string
    AND?: localWhereInput | localWhereInput[]
    OR?: localWhereInput[]
    NOT?: localWhereInput | localWhereInput[]
    nome_local?: StringFilter<"local"> | string
    capacidade?: IntNullableFilter<"local"> | number | null
    eventos?: EventosListRelationFilter
  }, "id_local">

  export type localOrderByWithAggregationInput = {
    id_local?: SortOrder
    nome_local?: SortOrder
    capacidade?: SortOrderInput | SortOrder
    _count?: localCountOrderByAggregateInput
    _avg?: localAvgOrderByAggregateInput
    _max?: localMaxOrderByAggregateInput
    _min?: localMinOrderByAggregateInput
    _sum?: localSumOrderByAggregateInput
  }

  export type localScalarWhereWithAggregatesInput = {
    AND?: localScalarWhereWithAggregatesInput | localScalarWhereWithAggregatesInput[]
    OR?: localScalarWhereWithAggregatesInput[]
    NOT?: localScalarWhereWithAggregatesInput | localScalarWhereWithAggregatesInput[]
    id_local?: StringWithAggregatesFilter<"local"> | string
    nome_local?: StringWithAggregatesFilter<"local"> | string
    capacidade?: IntNullableWithAggregatesFilter<"local"> | number | null
  }

  export type tipo_perfilWhereInput = {
    AND?: tipo_perfilWhereInput | tipo_perfilWhereInput[]
    OR?: tipo_perfilWhereInput[]
    NOT?: tipo_perfilWhereInput | tipo_perfilWhereInput[]
    id_tipo_perfil?: StringFilter<"tipo_perfil"> | string
    descricao?: StringFilter<"tipo_perfil"> | string
    usuarios?: UsuariosListRelationFilter
  }

  export type tipo_perfilOrderByWithRelationInput = {
    id_tipo_perfil?: SortOrder
    descricao?: SortOrder
    usuarios?: usuariosOrderByRelationAggregateInput
  }

  export type tipo_perfilWhereUniqueInput = Prisma.AtLeast<{
    id_tipo_perfil?: string
    AND?: tipo_perfilWhereInput | tipo_perfilWhereInput[]
    OR?: tipo_perfilWhereInput[]
    NOT?: tipo_perfilWhereInput | tipo_perfilWhereInput[]
    descricao?: StringFilter<"tipo_perfil"> | string
    usuarios?: UsuariosListRelationFilter
  }, "id_tipo_perfil">

  export type tipo_perfilOrderByWithAggregationInput = {
    id_tipo_perfil?: SortOrder
    descricao?: SortOrder
    _count?: tipo_perfilCountOrderByAggregateInput
    _max?: tipo_perfilMaxOrderByAggregateInput
    _min?: tipo_perfilMinOrderByAggregateInput
  }

  export type tipo_perfilScalarWhereWithAggregatesInput = {
    AND?: tipo_perfilScalarWhereWithAggregatesInput | tipo_perfilScalarWhereWithAggregatesInput[]
    OR?: tipo_perfilScalarWhereWithAggregatesInput[]
    NOT?: tipo_perfilScalarWhereWithAggregatesInput | tipo_perfilScalarWhereWithAggregatesInput[]
    id_tipo_perfil?: StringWithAggregatesFilter<"tipo_perfil"> | string
    descricao?: StringWithAggregatesFilter<"tipo_perfil"> | string
  }

  export type usuariosWhereInput = {
    AND?: usuariosWhereInput | usuariosWhereInput[]
    OR?: usuariosWhereInput[]
    NOT?: usuariosWhereInput | usuariosWhereInput[]
    id_usuario?: IntFilter<"usuarios"> | number
    nome?: StringFilter<"usuarios"> | string
    email?: StringFilter<"usuarios"> | string
    senha?: StringFilter<"usuarios"> | string
    id_tipo_perfil?: StringFilter<"usuarios"> | string
    eventos?: EventosListRelationFilter
    inscricoes?: InscricoesListRelationFilter
    tipo_perfil?: XOR<Tipo_perfilScalarRelationFilter, tipo_perfilWhereInput>
  }

  export type usuariosOrderByWithRelationInput = {
    id_usuario?: SortOrder
    nome?: SortOrder
    email?: SortOrder
    senha?: SortOrder
    id_tipo_perfil?: SortOrder
    eventos?: eventosOrderByRelationAggregateInput
    inscricoes?: inscricoesOrderByRelationAggregateInput
    tipo_perfil?: tipo_perfilOrderByWithRelationInput
  }

  export type usuariosWhereUniqueInput = Prisma.AtLeast<{
    id_usuario?: number
    email?: string
    AND?: usuariosWhereInput | usuariosWhereInput[]
    OR?: usuariosWhereInput[]
    NOT?: usuariosWhereInput | usuariosWhereInput[]
    nome?: StringFilter<"usuarios"> | string
    senha?: StringFilter<"usuarios"> | string
    id_tipo_perfil?: StringFilter<"usuarios"> | string
    eventos?: EventosListRelationFilter
    inscricoes?: InscricoesListRelationFilter
    tipo_perfil?: XOR<Tipo_perfilScalarRelationFilter, tipo_perfilWhereInput>
  }, "id_usuario" | "email">

  export type usuariosOrderByWithAggregationInput = {
    id_usuario?: SortOrder
    nome?: SortOrder
    email?: SortOrder
    senha?: SortOrder
    id_tipo_perfil?: SortOrder
    _count?: usuariosCountOrderByAggregateInput
    _avg?: usuariosAvgOrderByAggregateInput
    _max?: usuariosMaxOrderByAggregateInput
    _min?: usuariosMinOrderByAggregateInput
    _sum?: usuariosSumOrderByAggregateInput
  }

  export type usuariosScalarWhereWithAggregatesInput = {
    AND?: usuariosScalarWhereWithAggregatesInput | usuariosScalarWhereWithAggregatesInput[]
    OR?: usuariosScalarWhereWithAggregatesInput[]
    NOT?: usuariosScalarWhereWithAggregatesInput | usuariosScalarWhereWithAggregatesInput[]
    id_usuario?: IntWithAggregatesFilter<"usuarios"> | number
    nome?: StringWithAggregatesFilter<"usuarios"> | string
    email?: StringWithAggregatesFilter<"usuarios"> | string
    senha?: StringWithAggregatesFilter<"usuarios"> | string
    id_tipo_perfil?: StringWithAggregatesFilter<"usuarios"> | string
  }

  export type eventosCreateInput = {
    titulo: string
    descricao: string
    palestrante: string
    carga_horaria?: number
    vagas_limite?: number
    data_inicio?: Date | string
    data_fim: Date | string
    hora_inicio: Date | string
    hora_fim: Date | string
    objetivo_pedagogico?: string | null
    usuarios: usuariosCreateNestedOneWithoutEventosInput
    local?: localCreateNestedOneWithoutEventosInput
    inscricoes?: inscricoesCreateNestedManyWithoutEventosInput
  }

  export type eventosUncheckedCreateInput = {
    id_evento?: number
    titulo: string
    descricao: string
    palestrante: string
    carga_horaria?: number
    vagas_limite?: number
    data_inicio?: Date | string
    data_fim: Date | string
    hora_inicio: Date | string
    hora_fim: Date | string
    objetivo_pedagogico?: string | null
    id_local?: string | null
    id_usuario: number
    inscricoes?: inscricoesUncheckedCreateNestedManyWithoutEventosInput
  }

  export type eventosUpdateInput = {
    titulo?: StringFieldUpdateOperationsInput | string
    descricao?: StringFieldUpdateOperationsInput | string
    palestrante?: StringFieldUpdateOperationsInput | string
    carga_horaria?: IntFieldUpdateOperationsInput | number
    vagas_limite?: IntFieldUpdateOperationsInput | number
    data_inicio?: DateTimeFieldUpdateOperationsInput | Date | string
    data_fim?: DateTimeFieldUpdateOperationsInput | Date | string
    hora_inicio?: DateTimeFieldUpdateOperationsInput | Date | string
    hora_fim?: DateTimeFieldUpdateOperationsInput | Date | string
    objetivo_pedagogico?: NullableStringFieldUpdateOperationsInput | string | null
    usuarios?: usuariosUpdateOneRequiredWithoutEventosNestedInput
    local?: localUpdateOneWithoutEventosNestedInput
    inscricoes?: inscricoesUpdateManyWithoutEventosNestedInput
  }

  export type eventosUncheckedUpdateInput = {
    id_evento?: IntFieldUpdateOperationsInput | number
    titulo?: StringFieldUpdateOperationsInput | string
    descricao?: StringFieldUpdateOperationsInput | string
    palestrante?: StringFieldUpdateOperationsInput | string
    carga_horaria?: IntFieldUpdateOperationsInput | number
    vagas_limite?: IntFieldUpdateOperationsInput | number
    data_inicio?: DateTimeFieldUpdateOperationsInput | Date | string
    data_fim?: DateTimeFieldUpdateOperationsInput | Date | string
    hora_inicio?: DateTimeFieldUpdateOperationsInput | Date | string
    hora_fim?: DateTimeFieldUpdateOperationsInput | Date | string
    objetivo_pedagogico?: NullableStringFieldUpdateOperationsInput | string | null
    id_local?: NullableStringFieldUpdateOperationsInput | string | null
    id_usuario?: IntFieldUpdateOperationsInput | number
    inscricoes?: inscricoesUncheckedUpdateManyWithoutEventosNestedInput
  }

  export type eventosCreateManyInput = {
    id_evento?: number
    titulo: string
    descricao: string
    palestrante: string
    carga_horaria?: number
    vagas_limite?: number
    data_inicio?: Date | string
    data_fim: Date | string
    hora_inicio: Date | string
    hora_fim: Date | string
    objetivo_pedagogico?: string | null
    id_local?: string | null
    id_usuario: number
  }

  export type eventosUpdateManyMutationInput = {
    titulo?: StringFieldUpdateOperationsInput | string
    descricao?: StringFieldUpdateOperationsInput | string
    palestrante?: StringFieldUpdateOperationsInput | string
    carga_horaria?: IntFieldUpdateOperationsInput | number
    vagas_limite?: IntFieldUpdateOperationsInput | number
    data_inicio?: DateTimeFieldUpdateOperationsInput | Date | string
    data_fim?: DateTimeFieldUpdateOperationsInput | Date | string
    hora_inicio?: DateTimeFieldUpdateOperationsInput | Date | string
    hora_fim?: DateTimeFieldUpdateOperationsInput | Date | string
    objetivo_pedagogico?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type eventosUncheckedUpdateManyInput = {
    id_evento?: IntFieldUpdateOperationsInput | number
    titulo?: StringFieldUpdateOperationsInput | string
    descricao?: StringFieldUpdateOperationsInput | string
    palestrante?: StringFieldUpdateOperationsInput | string
    carga_horaria?: IntFieldUpdateOperationsInput | number
    vagas_limite?: IntFieldUpdateOperationsInput | number
    data_inicio?: DateTimeFieldUpdateOperationsInput | Date | string
    data_fim?: DateTimeFieldUpdateOperationsInput | Date | string
    hora_inicio?: DateTimeFieldUpdateOperationsInput | Date | string
    hora_fim?: DateTimeFieldUpdateOperationsInput | Date | string
    objetivo_pedagogico?: NullableStringFieldUpdateOperationsInput | string | null
    id_local?: NullableStringFieldUpdateOperationsInput | string | null
    id_usuario?: IntFieldUpdateOperationsInput | number
  }

  export type inscricoesCreateInput = {
    presenca_entrada?: boolean | null
    horario_entrada?: Date | string | null
    presenca_saida?: boolean | null
    horario_saida?: Date | string | null
    codigo_validacao?: string | null
    data_inscricao?: Date | string | null
    usuarios: usuariosCreateNestedOneWithoutInscricoesInput
    eventos: eventosCreateNestedOneWithoutInscricoesInput
  }

  export type inscricoesUncheckedCreateInput = {
    id_inscricao?: number
    id_aluno: number
    id_evento: number
    presenca_entrada?: boolean | null
    horario_entrada?: Date | string | null
    presenca_saida?: boolean | null
    horario_saida?: Date | string | null
    codigo_validacao?: string | null
    data_inscricao?: Date | string | null
  }

  export type inscricoesUpdateInput = {
    presenca_entrada?: NullableBoolFieldUpdateOperationsInput | boolean | null
    horario_entrada?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    presenca_saida?: NullableBoolFieldUpdateOperationsInput | boolean | null
    horario_saida?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    codigo_validacao?: NullableStringFieldUpdateOperationsInput | string | null
    data_inscricao?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    usuarios?: usuariosUpdateOneRequiredWithoutInscricoesNestedInput
    eventos?: eventosUpdateOneRequiredWithoutInscricoesNestedInput
  }

  export type inscricoesUncheckedUpdateInput = {
    id_inscricao?: IntFieldUpdateOperationsInput | number
    id_aluno?: IntFieldUpdateOperationsInput | number
    id_evento?: IntFieldUpdateOperationsInput | number
    presenca_entrada?: NullableBoolFieldUpdateOperationsInput | boolean | null
    horario_entrada?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    presenca_saida?: NullableBoolFieldUpdateOperationsInput | boolean | null
    horario_saida?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    codigo_validacao?: NullableStringFieldUpdateOperationsInput | string | null
    data_inscricao?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type inscricoesCreateManyInput = {
    id_inscricao?: number
    id_aluno: number
    id_evento: number
    presenca_entrada?: boolean | null
    horario_entrada?: Date | string | null
    presenca_saida?: boolean | null
    horario_saida?: Date | string | null
    codigo_validacao?: string | null
    data_inscricao?: Date | string | null
  }

  export type inscricoesUpdateManyMutationInput = {
    presenca_entrada?: NullableBoolFieldUpdateOperationsInput | boolean | null
    horario_entrada?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    presenca_saida?: NullableBoolFieldUpdateOperationsInput | boolean | null
    horario_saida?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    codigo_validacao?: NullableStringFieldUpdateOperationsInput | string | null
    data_inscricao?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type inscricoesUncheckedUpdateManyInput = {
    id_inscricao?: IntFieldUpdateOperationsInput | number
    id_aluno?: IntFieldUpdateOperationsInput | number
    id_evento?: IntFieldUpdateOperationsInput | number
    presenca_entrada?: NullableBoolFieldUpdateOperationsInput | boolean | null
    horario_entrada?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    presenca_saida?: NullableBoolFieldUpdateOperationsInput | boolean | null
    horario_saida?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    codigo_validacao?: NullableStringFieldUpdateOperationsInput | string | null
    data_inscricao?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type localCreateInput = {
    id_local: string
    nome_local: string
    capacidade?: number | null
    eventos?: eventosCreateNestedManyWithoutLocalInput
  }

  export type localUncheckedCreateInput = {
    id_local: string
    nome_local: string
    capacidade?: number | null
    eventos?: eventosUncheckedCreateNestedManyWithoutLocalInput
  }

  export type localUpdateInput = {
    id_local?: StringFieldUpdateOperationsInput | string
    nome_local?: StringFieldUpdateOperationsInput | string
    capacidade?: NullableIntFieldUpdateOperationsInput | number | null
    eventos?: eventosUpdateManyWithoutLocalNestedInput
  }

  export type localUncheckedUpdateInput = {
    id_local?: StringFieldUpdateOperationsInput | string
    nome_local?: StringFieldUpdateOperationsInput | string
    capacidade?: NullableIntFieldUpdateOperationsInput | number | null
    eventos?: eventosUncheckedUpdateManyWithoutLocalNestedInput
  }

  export type localCreateManyInput = {
    id_local: string
    nome_local: string
    capacidade?: number | null
  }

  export type localUpdateManyMutationInput = {
    id_local?: StringFieldUpdateOperationsInput | string
    nome_local?: StringFieldUpdateOperationsInput | string
    capacidade?: NullableIntFieldUpdateOperationsInput | number | null
  }

  export type localUncheckedUpdateManyInput = {
    id_local?: StringFieldUpdateOperationsInput | string
    nome_local?: StringFieldUpdateOperationsInput | string
    capacidade?: NullableIntFieldUpdateOperationsInput | number | null
  }

  export type tipo_perfilCreateInput = {
    id_tipo_perfil: string
    descricao: string
    usuarios?: usuariosCreateNestedManyWithoutTipo_perfilInput
  }

  export type tipo_perfilUncheckedCreateInput = {
    id_tipo_perfil: string
    descricao: string
    usuarios?: usuariosUncheckedCreateNestedManyWithoutTipo_perfilInput
  }

  export type tipo_perfilUpdateInput = {
    id_tipo_perfil?: StringFieldUpdateOperationsInput | string
    descricao?: StringFieldUpdateOperationsInput | string
    usuarios?: usuariosUpdateManyWithoutTipo_perfilNestedInput
  }

  export type tipo_perfilUncheckedUpdateInput = {
    id_tipo_perfil?: StringFieldUpdateOperationsInput | string
    descricao?: StringFieldUpdateOperationsInput | string
    usuarios?: usuariosUncheckedUpdateManyWithoutTipo_perfilNestedInput
  }

  export type tipo_perfilCreateManyInput = {
    id_tipo_perfil: string
    descricao: string
  }

  export type tipo_perfilUpdateManyMutationInput = {
    id_tipo_perfil?: StringFieldUpdateOperationsInput | string
    descricao?: StringFieldUpdateOperationsInput | string
  }

  export type tipo_perfilUncheckedUpdateManyInput = {
    id_tipo_perfil?: StringFieldUpdateOperationsInput | string
    descricao?: StringFieldUpdateOperationsInput | string
  }

  export type usuariosCreateInput = {
    nome: string
    email: string
    senha: string
    eventos?: eventosCreateNestedManyWithoutUsuariosInput
    inscricoes?: inscricoesCreateNestedManyWithoutUsuariosInput
    tipo_perfil: tipo_perfilCreateNestedOneWithoutUsuariosInput
  }

  export type usuariosUncheckedCreateInput = {
    id_usuario?: number
    nome: string
    email: string
    senha: string
    id_tipo_perfil: string
    eventos?: eventosUncheckedCreateNestedManyWithoutUsuariosInput
    inscricoes?: inscricoesUncheckedCreateNestedManyWithoutUsuariosInput
  }

  export type usuariosUpdateInput = {
    nome?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    senha?: StringFieldUpdateOperationsInput | string
    eventos?: eventosUpdateManyWithoutUsuariosNestedInput
    inscricoes?: inscricoesUpdateManyWithoutUsuariosNestedInput
    tipo_perfil?: tipo_perfilUpdateOneRequiredWithoutUsuariosNestedInput
  }

  export type usuariosUncheckedUpdateInput = {
    id_usuario?: IntFieldUpdateOperationsInput | number
    nome?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    senha?: StringFieldUpdateOperationsInput | string
    id_tipo_perfil?: StringFieldUpdateOperationsInput | string
    eventos?: eventosUncheckedUpdateManyWithoutUsuariosNestedInput
    inscricoes?: inscricoesUncheckedUpdateManyWithoutUsuariosNestedInput
  }

  export type usuariosCreateManyInput = {
    id_usuario?: number
    nome: string
    email: string
    senha: string
    id_tipo_perfil: string
  }

  export type usuariosUpdateManyMutationInput = {
    nome?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    senha?: StringFieldUpdateOperationsInput | string
  }

  export type usuariosUncheckedUpdateManyInput = {
    id_usuario?: IntFieldUpdateOperationsInput | number
    nome?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    senha?: StringFieldUpdateOperationsInput | string
    id_tipo_perfil?: StringFieldUpdateOperationsInput | string
  }

  export type IntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type DateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type StringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type UsuariosScalarRelationFilter = {
    is?: usuariosWhereInput
    isNot?: usuariosWhereInput
  }

  export type LocalNullableScalarRelationFilter = {
    is?: localWhereInput | null
    isNot?: localWhereInput | null
  }

  export type InscricoesListRelationFilter = {
    every?: inscricoesWhereInput
    some?: inscricoesWhereInput
    none?: inscricoesWhereInput
  }

  export type SortOrderInput = {
    sort: SortOrder
    nulls?: NullsOrder
  }

  export type inscricoesOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type eventosCountOrderByAggregateInput = {
    id_evento?: SortOrder
    titulo?: SortOrder
    descricao?: SortOrder
    palestrante?: SortOrder
    carga_horaria?: SortOrder
    vagas_limite?: SortOrder
    data_inicio?: SortOrder
    data_fim?: SortOrder
    hora_inicio?: SortOrder
    hora_fim?: SortOrder
    objetivo_pedagogico?: SortOrder
    id_local?: SortOrder
    id_usuario?: SortOrder
  }

  export type eventosAvgOrderByAggregateInput = {
    id_evento?: SortOrder
    carga_horaria?: SortOrder
    vagas_limite?: SortOrder
    id_usuario?: SortOrder
  }

  export type eventosMaxOrderByAggregateInput = {
    id_evento?: SortOrder
    titulo?: SortOrder
    descricao?: SortOrder
    palestrante?: SortOrder
    carga_horaria?: SortOrder
    vagas_limite?: SortOrder
    data_inicio?: SortOrder
    data_fim?: SortOrder
    hora_inicio?: SortOrder
    hora_fim?: SortOrder
    objetivo_pedagogico?: SortOrder
    id_local?: SortOrder
    id_usuario?: SortOrder
  }

  export type eventosMinOrderByAggregateInput = {
    id_evento?: SortOrder
    titulo?: SortOrder
    descricao?: SortOrder
    palestrante?: SortOrder
    carga_horaria?: SortOrder
    vagas_limite?: SortOrder
    data_inicio?: SortOrder
    data_fim?: SortOrder
    hora_inicio?: SortOrder
    hora_fim?: SortOrder
    objetivo_pedagogico?: SortOrder
    id_local?: SortOrder
    id_usuario?: SortOrder
  }

  export type eventosSumOrderByAggregateInput = {
    id_evento?: SortOrder
    carga_horaria?: SortOrder
    vagas_limite?: SortOrder
    id_usuario?: SortOrder
  }

  export type IntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type DateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type StringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type BoolNullableFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel> | null
    not?: NestedBoolNullableFilter<$PrismaModel> | boolean | null
  }

  export type DateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type EventosScalarRelationFilter = {
    is?: eventosWhereInput
    isNot?: eventosWhereInput
  }

  export type inscricoesId_alunoId_eventoCompoundUniqueInput = {
    id_aluno: number
    id_evento: number
  }

  export type inscricoesCountOrderByAggregateInput = {
    id_inscricao?: SortOrder
    id_aluno?: SortOrder
    id_evento?: SortOrder
    presenca_entrada?: SortOrder
    horario_entrada?: SortOrder
    presenca_saida?: SortOrder
    horario_saida?: SortOrder
    codigo_validacao?: SortOrder
    data_inscricao?: SortOrder
  }

  export type inscricoesAvgOrderByAggregateInput = {
    id_inscricao?: SortOrder
    id_aluno?: SortOrder
    id_evento?: SortOrder
  }

  export type inscricoesMaxOrderByAggregateInput = {
    id_inscricao?: SortOrder
    id_aluno?: SortOrder
    id_evento?: SortOrder
    presenca_entrada?: SortOrder
    horario_entrada?: SortOrder
    presenca_saida?: SortOrder
    horario_saida?: SortOrder
    codigo_validacao?: SortOrder
    data_inscricao?: SortOrder
  }

  export type inscricoesMinOrderByAggregateInput = {
    id_inscricao?: SortOrder
    id_aluno?: SortOrder
    id_evento?: SortOrder
    presenca_entrada?: SortOrder
    horario_entrada?: SortOrder
    presenca_saida?: SortOrder
    horario_saida?: SortOrder
    codigo_validacao?: SortOrder
    data_inscricao?: SortOrder
  }

  export type inscricoesSumOrderByAggregateInput = {
    id_inscricao?: SortOrder
    id_aluno?: SortOrder
    id_evento?: SortOrder
  }

  export type BoolNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel> | null
    not?: NestedBoolNullableWithAggregatesFilter<$PrismaModel> | boolean | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedBoolNullableFilter<$PrismaModel>
    _max?: NestedBoolNullableFilter<$PrismaModel>
  }

  export type DateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type IntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type EventosListRelationFilter = {
    every?: eventosWhereInput
    some?: eventosWhereInput
    none?: eventosWhereInput
  }

  export type eventosOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type localCountOrderByAggregateInput = {
    id_local?: SortOrder
    nome_local?: SortOrder
    capacidade?: SortOrder
  }

  export type localAvgOrderByAggregateInput = {
    capacidade?: SortOrder
  }

  export type localMaxOrderByAggregateInput = {
    id_local?: SortOrder
    nome_local?: SortOrder
    capacidade?: SortOrder
  }

  export type localMinOrderByAggregateInput = {
    id_local?: SortOrder
    nome_local?: SortOrder
    capacidade?: SortOrder
  }

  export type localSumOrderByAggregateInput = {
    capacidade?: SortOrder
  }

  export type IntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type UsuariosListRelationFilter = {
    every?: usuariosWhereInput
    some?: usuariosWhereInput
    none?: usuariosWhereInput
  }

  export type usuariosOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type tipo_perfilCountOrderByAggregateInput = {
    id_tipo_perfil?: SortOrder
    descricao?: SortOrder
  }

  export type tipo_perfilMaxOrderByAggregateInput = {
    id_tipo_perfil?: SortOrder
    descricao?: SortOrder
  }

  export type tipo_perfilMinOrderByAggregateInput = {
    id_tipo_perfil?: SortOrder
    descricao?: SortOrder
  }

  export type Tipo_perfilScalarRelationFilter = {
    is?: tipo_perfilWhereInput
    isNot?: tipo_perfilWhereInput
  }

  export type usuariosCountOrderByAggregateInput = {
    id_usuario?: SortOrder
    nome?: SortOrder
    email?: SortOrder
    senha?: SortOrder
    id_tipo_perfil?: SortOrder
  }

  export type usuariosAvgOrderByAggregateInput = {
    id_usuario?: SortOrder
  }

  export type usuariosMaxOrderByAggregateInput = {
    id_usuario?: SortOrder
    nome?: SortOrder
    email?: SortOrder
    senha?: SortOrder
    id_tipo_perfil?: SortOrder
  }

  export type usuariosMinOrderByAggregateInput = {
    id_usuario?: SortOrder
    nome?: SortOrder
    email?: SortOrder
    senha?: SortOrder
    id_tipo_perfil?: SortOrder
  }

  export type usuariosSumOrderByAggregateInput = {
    id_usuario?: SortOrder
  }

  export type usuariosCreateNestedOneWithoutEventosInput = {
    create?: XOR<usuariosCreateWithoutEventosInput, usuariosUncheckedCreateWithoutEventosInput>
    connectOrCreate?: usuariosCreateOrConnectWithoutEventosInput
    connect?: usuariosWhereUniqueInput
  }

  export type localCreateNestedOneWithoutEventosInput = {
    create?: XOR<localCreateWithoutEventosInput, localUncheckedCreateWithoutEventosInput>
    connectOrCreate?: localCreateOrConnectWithoutEventosInput
    connect?: localWhereUniqueInput
  }

  export type inscricoesCreateNestedManyWithoutEventosInput = {
    create?: XOR<inscricoesCreateWithoutEventosInput, inscricoesUncheckedCreateWithoutEventosInput> | inscricoesCreateWithoutEventosInput[] | inscricoesUncheckedCreateWithoutEventosInput[]
    connectOrCreate?: inscricoesCreateOrConnectWithoutEventosInput | inscricoesCreateOrConnectWithoutEventosInput[]
    createMany?: inscricoesCreateManyEventosInputEnvelope
    connect?: inscricoesWhereUniqueInput | inscricoesWhereUniqueInput[]
  }

  export type inscricoesUncheckedCreateNestedManyWithoutEventosInput = {
    create?: XOR<inscricoesCreateWithoutEventosInput, inscricoesUncheckedCreateWithoutEventosInput> | inscricoesCreateWithoutEventosInput[] | inscricoesUncheckedCreateWithoutEventosInput[]
    connectOrCreate?: inscricoesCreateOrConnectWithoutEventosInput | inscricoesCreateOrConnectWithoutEventosInput[]
    createMany?: inscricoesCreateManyEventosInputEnvelope
    connect?: inscricoesWhereUniqueInput | inscricoesWhereUniqueInput[]
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type IntFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type DateTimeFieldUpdateOperationsInput = {
    set?: Date | string
  }

  export type NullableStringFieldUpdateOperationsInput = {
    set?: string | null
  }

  export type usuariosUpdateOneRequiredWithoutEventosNestedInput = {
    create?: XOR<usuariosCreateWithoutEventosInput, usuariosUncheckedCreateWithoutEventosInput>
    connectOrCreate?: usuariosCreateOrConnectWithoutEventosInput
    upsert?: usuariosUpsertWithoutEventosInput
    connect?: usuariosWhereUniqueInput
    update?: XOR<XOR<usuariosUpdateToOneWithWhereWithoutEventosInput, usuariosUpdateWithoutEventosInput>, usuariosUncheckedUpdateWithoutEventosInput>
  }

  export type localUpdateOneWithoutEventosNestedInput = {
    create?: XOR<localCreateWithoutEventosInput, localUncheckedCreateWithoutEventosInput>
    connectOrCreate?: localCreateOrConnectWithoutEventosInput
    upsert?: localUpsertWithoutEventosInput
    disconnect?: localWhereInput | boolean
    delete?: localWhereInput | boolean
    connect?: localWhereUniqueInput
    update?: XOR<XOR<localUpdateToOneWithWhereWithoutEventosInput, localUpdateWithoutEventosInput>, localUncheckedUpdateWithoutEventosInput>
  }

  export type inscricoesUpdateManyWithoutEventosNestedInput = {
    create?: XOR<inscricoesCreateWithoutEventosInput, inscricoesUncheckedCreateWithoutEventosInput> | inscricoesCreateWithoutEventosInput[] | inscricoesUncheckedCreateWithoutEventosInput[]
    connectOrCreate?: inscricoesCreateOrConnectWithoutEventosInput | inscricoesCreateOrConnectWithoutEventosInput[]
    upsert?: inscricoesUpsertWithWhereUniqueWithoutEventosInput | inscricoesUpsertWithWhereUniqueWithoutEventosInput[]
    createMany?: inscricoesCreateManyEventosInputEnvelope
    set?: inscricoesWhereUniqueInput | inscricoesWhereUniqueInput[]
    disconnect?: inscricoesWhereUniqueInput | inscricoesWhereUniqueInput[]
    delete?: inscricoesWhereUniqueInput | inscricoesWhereUniqueInput[]
    connect?: inscricoesWhereUniqueInput | inscricoesWhereUniqueInput[]
    update?: inscricoesUpdateWithWhereUniqueWithoutEventosInput | inscricoesUpdateWithWhereUniqueWithoutEventosInput[]
    updateMany?: inscricoesUpdateManyWithWhereWithoutEventosInput | inscricoesUpdateManyWithWhereWithoutEventosInput[]
    deleteMany?: inscricoesScalarWhereInput | inscricoesScalarWhereInput[]
  }

  export type inscricoesUncheckedUpdateManyWithoutEventosNestedInput = {
    create?: XOR<inscricoesCreateWithoutEventosInput, inscricoesUncheckedCreateWithoutEventosInput> | inscricoesCreateWithoutEventosInput[] | inscricoesUncheckedCreateWithoutEventosInput[]
    connectOrCreate?: inscricoesCreateOrConnectWithoutEventosInput | inscricoesCreateOrConnectWithoutEventosInput[]
    upsert?: inscricoesUpsertWithWhereUniqueWithoutEventosInput | inscricoesUpsertWithWhereUniqueWithoutEventosInput[]
    createMany?: inscricoesCreateManyEventosInputEnvelope
    set?: inscricoesWhereUniqueInput | inscricoesWhereUniqueInput[]
    disconnect?: inscricoesWhereUniqueInput | inscricoesWhereUniqueInput[]
    delete?: inscricoesWhereUniqueInput | inscricoesWhereUniqueInput[]
    connect?: inscricoesWhereUniqueInput | inscricoesWhereUniqueInput[]
    update?: inscricoesUpdateWithWhereUniqueWithoutEventosInput | inscricoesUpdateWithWhereUniqueWithoutEventosInput[]
    updateMany?: inscricoesUpdateManyWithWhereWithoutEventosInput | inscricoesUpdateManyWithWhereWithoutEventosInput[]
    deleteMany?: inscricoesScalarWhereInput | inscricoesScalarWhereInput[]
  }

  export type usuariosCreateNestedOneWithoutInscricoesInput = {
    create?: XOR<usuariosCreateWithoutInscricoesInput, usuariosUncheckedCreateWithoutInscricoesInput>
    connectOrCreate?: usuariosCreateOrConnectWithoutInscricoesInput
    connect?: usuariosWhereUniqueInput
  }

  export type eventosCreateNestedOneWithoutInscricoesInput = {
    create?: XOR<eventosCreateWithoutInscricoesInput, eventosUncheckedCreateWithoutInscricoesInput>
    connectOrCreate?: eventosCreateOrConnectWithoutInscricoesInput
    connect?: eventosWhereUniqueInput
  }

  export type NullableBoolFieldUpdateOperationsInput = {
    set?: boolean | null
  }

  export type NullableDateTimeFieldUpdateOperationsInput = {
    set?: Date | string | null
  }

  export type usuariosUpdateOneRequiredWithoutInscricoesNestedInput = {
    create?: XOR<usuariosCreateWithoutInscricoesInput, usuariosUncheckedCreateWithoutInscricoesInput>
    connectOrCreate?: usuariosCreateOrConnectWithoutInscricoesInput
    upsert?: usuariosUpsertWithoutInscricoesInput
    connect?: usuariosWhereUniqueInput
    update?: XOR<XOR<usuariosUpdateToOneWithWhereWithoutInscricoesInput, usuariosUpdateWithoutInscricoesInput>, usuariosUncheckedUpdateWithoutInscricoesInput>
  }

  export type eventosUpdateOneRequiredWithoutInscricoesNestedInput = {
    create?: XOR<eventosCreateWithoutInscricoesInput, eventosUncheckedCreateWithoutInscricoesInput>
    connectOrCreate?: eventosCreateOrConnectWithoutInscricoesInput
    upsert?: eventosUpsertWithoutInscricoesInput
    connect?: eventosWhereUniqueInput
    update?: XOR<XOR<eventosUpdateToOneWithWhereWithoutInscricoesInput, eventosUpdateWithoutInscricoesInput>, eventosUncheckedUpdateWithoutInscricoesInput>
  }

  export type eventosCreateNestedManyWithoutLocalInput = {
    create?: XOR<eventosCreateWithoutLocalInput, eventosUncheckedCreateWithoutLocalInput> | eventosCreateWithoutLocalInput[] | eventosUncheckedCreateWithoutLocalInput[]
    connectOrCreate?: eventosCreateOrConnectWithoutLocalInput | eventosCreateOrConnectWithoutLocalInput[]
    createMany?: eventosCreateManyLocalInputEnvelope
    connect?: eventosWhereUniqueInput | eventosWhereUniqueInput[]
  }

  export type eventosUncheckedCreateNestedManyWithoutLocalInput = {
    create?: XOR<eventosCreateWithoutLocalInput, eventosUncheckedCreateWithoutLocalInput> | eventosCreateWithoutLocalInput[] | eventosUncheckedCreateWithoutLocalInput[]
    connectOrCreate?: eventosCreateOrConnectWithoutLocalInput | eventosCreateOrConnectWithoutLocalInput[]
    createMany?: eventosCreateManyLocalInputEnvelope
    connect?: eventosWhereUniqueInput | eventosWhereUniqueInput[]
  }

  export type NullableIntFieldUpdateOperationsInput = {
    set?: number | null
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type eventosUpdateManyWithoutLocalNestedInput = {
    create?: XOR<eventosCreateWithoutLocalInput, eventosUncheckedCreateWithoutLocalInput> | eventosCreateWithoutLocalInput[] | eventosUncheckedCreateWithoutLocalInput[]
    connectOrCreate?: eventosCreateOrConnectWithoutLocalInput | eventosCreateOrConnectWithoutLocalInput[]
    upsert?: eventosUpsertWithWhereUniqueWithoutLocalInput | eventosUpsertWithWhereUniqueWithoutLocalInput[]
    createMany?: eventosCreateManyLocalInputEnvelope
    set?: eventosWhereUniqueInput | eventosWhereUniqueInput[]
    disconnect?: eventosWhereUniqueInput | eventosWhereUniqueInput[]
    delete?: eventosWhereUniqueInput | eventosWhereUniqueInput[]
    connect?: eventosWhereUniqueInput | eventosWhereUniqueInput[]
    update?: eventosUpdateWithWhereUniqueWithoutLocalInput | eventosUpdateWithWhereUniqueWithoutLocalInput[]
    updateMany?: eventosUpdateManyWithWhereWithoutLocalInput | eventosUpdateManyWithWhereWithoutLocalInput[]
    deleteMany?: eventosScalarWhereInput | eventosScalarWhereInput[]
  }

  export type eventosUncheckedUpdateManyWithoutLocalNestedInput = {
    create?: XOR<eventosCreateWithoutLocalInput, eventosUncheckedCreateWithoutLocalInput> | eventosCreateWithoutLocalInput[] | eventosUncheckedCreateWithoutLocalInput[]
    connectOrCreate?: eventosCreateOrConnectWithoutLocalInput | eventosCreateOrConnectWithoutLocalInput[]
    upsert?: eventosUpsertWithWhereUniqueWithoutLocalInput | eventosUpsertWithWhereUniqueWithoutLocalInput[]
    createMany?: eventosCreateManyLocalInputEnvelope
    set?: eventosWhereUniqueInput | eventosWhereUniqueInput[]
    disconnect?: eventosWhereUniqueInput | eventosWhereUniqueInput[]
    delete?: eventosWhereUniqueInput | eventosWhereUniqueInput[]
    connect?: eventosWhereUniqueInput | eventosWhereUniqueInput[]
    update?: eventosUpdateWithWhereUniqueWithoutLocalInput | eventosUpdateWithWhereUniqueWithoutLocalInput[]
    updateMany?: eventosUpdateManyWithWhereWithoutLocalInput | eventosUpdateManyWithWhereWithoutLocalInput[]
    deleteMany?: eventosScalarWhereInput | eventosScalarWhereInput[]
  }

  export type usuariosCreateNestedManyWithoutTipo_perfilInput = {
    create?: XOR<usuariosCreateWithoutTipo_perfilInput, usuariosUncheckedCreateWithoutTipo_perfilInput> | usuariosCreateWithoutTipo_perfilInput[] | usuariosUncheckedCreateWithoutTipo_perfilInput[]
    connectOrCreate?: usuariosCreateOrConnectWithoutTipo_perfilInput | usuariosCreateOrConnectWithoutTipo_perfilInput[]
    createMany?: usuariosCreateManyTipo_perfilInputEnvelope
    connect?: usuariosWhereUniqueInput | usuariosWhereUniqueInput[]
  }

  export type usuariosUncheckedCreateNestedManyWithoutTipo_perfilInput = {
    create?: XOR<usuariosCreateWithoutTipo_perfilInput, usuariosUncheckedCreateWithoutTipo_perfilInput> | usuariosCreateWithoutTipo_perfilInput[] | usuariosUncheckedCreateWithoutTipo_perfilInput[]
    connectOrCreate?: usuariosCreateOrConnectWithoutTipo_perfilInput | usuariosCreateOrConnectWithoutTipo_perfilInput[]
    createMany?: usuariosCreateManyTipo_perfilInputEnvelope
    connect?: usuariosWhereUniqueInput | usuariosWhereUniqueInput[]
  }

  export type usuariosUpdateManyWithoutTipo_perfilNestedInput = {
    create?: XOR<usuariosCreateWithoutTipo_perfilInput, usuariosUncheckedCreateWithoutTipo_perfilInput> | usuariosCreateWithoutTipo_perfilInput[] | usuariosUncheckedCreateWithoutTipo_perfilInput[]
    connectOrCreate?: usuariosCreateOrConnectWithoutTipo_perfilInput | usuariosCreateOrConnectWithoutTipo_perfilInput[]
    upsert?: usuariosUpsertWithWhereUniqueWithoutTipo_perfilInput | usuariosUpsertWithWhereUniqueWithoutTipo_perfilInput[]
    createMany?: usuariosCreateManyTipo_perfilInputEnvelope
    set?: usuariosWhereUniqueInput | usuariosWhereUniqueInput[]
    disconnect?: usuariosWhereUniqueInput | usuariosWhereUniqueInput[]
    delete?: usuariosWhereUniqueInput | usuariosWhereUniqueInput[]
    connect?: usuariosWhereUniqueInput | usuariosWhereUniqueInput[]
    update?: usuariosUpdateWithWhereUniqueWithoutTipo_perfilInput | usuariosUpdateWithWhereUniqueWithoutTipo_perfilInput[]
    updateMany?: usuariosUpdateManyWithWhereWithoutTipo_perfilInput | usuariosUpdateManyWithWhereWithoutTipo_perfilInput[]
    deleteMany?: usuariosScalarWhereInput | usuariosScalarWhereInput[]
  }

  export type usuariosUncheckedUpdateManyWithoutTipo_perfilNestedInput = {
    create?: XOR<usuariosCreateWithoutTipo_perfilInput, usuariosUncheckedCreateWithoutTipo_perfilInput> | usuariosCreateWithoutTipo_perfilInput[] | usuariosUncheckedCreateWithoutTipo_perfilInput[]
    connectOrCreate?: usuariosCreateOrConnectWithoutTipo_perfilInput | usuariosCreateOrConnectWithoutTipo_perfilInput[]
    upsert?: usuariosUpsertWithWhereUniqueWithoutTipo_perfilInput | usuariosUpsertWithWhereUniqueWithoutTipo_perfilInput[]
    createMany?: usuariosCreateManyTipo_perfilInputEnvelope
    set?: usuariosWhereUniqueInput | usuariosWhereUniqueInput[]
    disconnect?: usuariosWhereUniqueInput | usuariosWhereUniqueInput[]
    delete?: usuariosWhereUniqueInput | usuariosWhereUniqueInput[]
    connect?: usuariosWhereUniqueInput | usuariosWhereUniqueInput[]
    update?: usuariosUpdateWithWhereUniqueWithoutTipo_perfilInput | usuariosUpdateWithWhereUniqueWithoutTipo_perfilInput[]
    updateMany?: usuariosUpdateManyWithWhereWithoutTipo_perfilInput | usuariosUpdateManyWithWhereWithoutTipo_perfilInput[]
    deleteMany?: usuariosScalarWhereInput | usuariosScalarWhereInput[]
  }

  export type eventosCreateNestedManyWithoutUsuariosInput = {
    create?: XOR<eventosCreateWithoutUsuariosInput, eventosUncheckedCreateWithoutUsuariosInput> | eventosCreateWithoutUsuariosInput[] | eventosUncheckedCreateWithoutUsuariosInput[]
    connectOrCreate?: eventosCreateOrConnectWithoutUsuariosInput | eventosCreateOrConnectWithoutUsuariosInput[]
    createMany?: eventosCreateManyUsuariosInputEnvelope
    connect?: eventosWhereUniqueInput | eventosWhereUniqueInput[]
  }

  export type inscricoesCreateNestedManyWithoutUsuariosInput = {
    create?: XOR<inscricoesCreateWithoutUsuariosInput, inscricoesUncheckedCreateWithoutUsuariosInput> | inscricoesCreateWithoutUsuariosInput[] | inscricoesUncheckedCreateWithoutUsuariosInput[]
    connectOrCreate?: inscricoesCreateOrConnectWithoutUsuariosInput | inscricoesCreateOrConnectWithoutUsuariosInput[]
    createMany?: inscricoesCreateManyUsuariosInputEnvelope
    connect?: inscricoesWhereUniqueInput | inscricoesWhereUniqueInput[]
  }

  export type tipo_perfilCreateNestedOneWithoutUsuariosInput = {
    create?: XOR<tipo_perfilCreateWithoutUsuariosInput, tipo_perfilUncheckedCreateWithoutUsuariosInput>
    connectOrCreate?: tipo_perfilCreateOrConnectWithoutUsuariosInput
    connect?: tipo_perfilWhereUniqueInput
  }

  export type eventosUncheckedCreateNestedManyWithoutUsuariosInput = {
    create?: XOR<eventosCreateWithoutUsuariosInput, eventosUncheckedCreateWithoutUsuariosInput> | eventosCreateWithoutUsuariosInput[] | eventosUncheckedCreateWithoutUsuariosInput[]
    connectOrCreate?: eventosCreateOrConnectWithoutUsuariosInput | eventosCreateOrConnectWithoutUsuariosInput[]
    createMany?: eventosCreateManyUsuariosInputEnvelope
    connect?: eventosWhereUniqueInput | eventosWhereUniqueInput[]
  }

  export type inscricoesUncheckedCreateNestedManyWithoutUsuariosInput = {
    create?: XOR<inscricoesCreateWithoutUsuariosInput, inscricoesUncheckedCreateWithoutUsuariosInput> | inscricoesCreateWithoutUsuariosInput[] | inscricoesUncheckedCreateWithoutUsuariosInput[]
    connectOrCreate?: inscricoesCreateOrConnectWithoutUsuariosInput | inscricoesCreateOrConnectWithoutUsuariosInput[]
    createMany?: inscricoesCreateManyUsuariosInputEnvelope
    connect?: inscricoesWhereUniqueInput | inscricoesWhereUniqueInput[]
  }

  export type eventosUpdateManyWithoutUsuariosNestedInput = {
    create?: XOR<eventosCreateWithoutUsuariosInput, eventosUncheckedCreateWithoutUsuariosInput> | eventosCreateWithoutUsuariosInput[] | eventosUncheckedCreateWithoutUsuariosInput[]
    connectOrCreate?: eventosCreateOrConnectWithoutUsuariosInput | eventosCreateOrConnectWithoutUsuariosInput[]
    upsert?: eventosUpsertWithWhereUniqueWithoutUsuariosInput | eventosUpsertWithWhereUniqueWithoutUsuariosInput[]
    createMany?: eventosCreateManyUsuariosInputEnvelope
    set?: eventosWhereUniqueInput | eventosWhereUniqueInput[]
    disconnect?: eventosWhereUniqueInput | eventosWhereUniqueInput[]
    delete?: eventosWhereUniqueInput | eventosWhereUniqueInput[]
    connect?: eventosWhereUniqueInput | eventosWhereUniqueInput[]
    update?: eventosUpdateWithWhereUniqueWithoutUsuariosInput | eventosUpdateWithWhereUniqueWithoutUsuariosInput[]
    updateMany?: eventosUpdateManyWithWhereWithoutUsuariosInput | eventosUpdateManyWithWhereWithoutUsuariosInput[]
    deleteMany?: eventosScalarWhereInput | eventosScalarWhereInput[]
  }

  export type inscricoesUpdateManyWithoutUsuariosNestedInput = {
    create?: XOR<inscricoesCreateWithoutUsuariosInput, inscricoesUncheckedCreateWithoutUsuariosInput> | inscricoesCreateWithoutUsuariosInput[] | inscricoesUncheckedCreateWithoutUsuariosInput[]
    connectOrCreate?: inscricoesCreateOrConnectWithoutUsuariosInput | inscricoesCreateOrConnectWithoutUsuariosInput[]
    upsert?: inscricoesUpsertWithWhereUniqueWithoutUsuariosInput | inscricoesUpsertWithWhereUniqueWithoutUsuariosInput[]
    createMany?: inscricoesCreateManyUsuariosInputEnvelope
    set?: inscricoesWhereUniqueInput | inscricoesWhereUniqueInput[]
    disconnect?: inscricoesWhereUniqueInput | inscricoesWhereUniqueInput[]
    delete?: inscricoesWhereUniqueInput | inscricoesWhereUniqueInput[]
    connect?: inscricoesWhereUniqueInput | inscricoesWhereUniqueInput[]
    update?: inscricoesUpdateWithWhereUniqueWithoutUsuariosInput | inscricoesUpdateWithWhereUniqueWithoutUsuariosInput[]
    updateMany?: inscricoesUpdateManyWithWhereWithoutUsuariosInput | inscricoesUpdateManyWithWhereWithoutUsuariosInput[]
    deleteMany?: inscricoesScalarWhereInput | inscricoesScalarWhereInput[]
  }

  export type tipo_perfilUpdateOneRequiredWithoutUsuariosNestedInput = {
    create?: XOR<tipo_perfilCreateWithoutUsuariosInput, tipo_perfilUncheckedCreateWithoutUsuariosInput>
    connectOrCreate?: tipo_perfilCreateOrConnectWithoutUsuariosInput
    upsert?: tipo_perfilUpsertWithoutUsuariosInput
    connect?: tipo_perfilWhereUniqueInput
    update?: XOR<XOR<tipo_perfilUpdateToOneWithWhereWithoutUsuariosInput, tipo_perfilUpdateWithoutUsuariosInput>, tipo_perfilUncheckedUpdateWithoutUsuariosInput>
  }

  export type eventosUncheckedUpdateManyWithoutUsuariosNestedInput = {
    create?: XOR<eventosCreateWithoutUsuariosInput, eventosUncheckedCreateWithoutUsuariosInput> | eventosCreateWithoutUsuariosInput[] | eventosUncheckedCreateWithoutUsuariosInput[]
    connectOrCreate?: eventosCreateOrConnectWithoutUsuariosInput | eventosCreateOrConnectWithoutUsuariosInput[]
    upsert?: eventosUpsertWithWhereUniqueWithoutUsuariosInput | eventosUpsertWithWhereUniqueWithoutUsuariosInput[]
    createMany?: eventosCreateManyUsuariosInputEnvelope
    set?: eventosWhereUniqueInput | eventosWhereUniqueInput[]
    disconnect?: eventosWhereUniqueInput | eventosWhereUniqueInput[]
    delete?: eventosWhereUniqueInput | eventosWhereUniqueInput[]
    connect?: eventosWhereUniqueInput | eventosWhereUniqueInput[]
    update?: eventosUpdateWithWhereUniqueWithoutUsuariosInput | eventosUpdateWithWhereUniqueWithoutUsuariosInput[]
    updateMany?: eventosUpdateManyWithWhereWithoutUsuariosInput | eventosUpdateManyWithWhereWithoutUsuariosInput[]
    deleteMany?: eventosScalarWhereInput | eventosScalarWhereInput[]
  }

  export type inscricoesUncheckedUpdateManyWithoutUsuariosNestedInput = {
    create?: XOR<inscricoesCreateWithoutUsuariosInput, inscricoesUncheckedCreateWithoutUsuariosInput> | inscricoesCreateWithoutUsuariosInput[] | inscricoesUncheckedCreateWithoutUsuariosInput[]
    connectOrCreate?: inscricoesCreateOrConnectWithoutUsuariosInput | inscricoesCreateOrConnectWithoutUsuariosInput[]
    upsert?: inscricoesUpsertWithWhereUniqueWithoutUsuariosInput | inscricoesUpsertWithWhereUniqueWithoutUsuariosInput[]
    createMany?: inscricoesCreateManyUsuariosInputEnvelope
    set?: inscricoesWhereUniqueInput | inscricoesWhereUniqueInput[]
    disconnect?: inscricoesWhereUniqueInput | inscricoesWhereUniqueInput[]
    delete?: inscricoesWhereUniqueInput | inscricoesWhereUniqueInput[]
    connect?: inscricoesWhereUniqueInput | inscricoesWhereUniqueInput[]
    update?: inscricoesUpdateWithWhereUniqueWithoutUsuariosInput | inscricoesUpdateWithWhereUniqueWithoutUsuariosInput[]
    updateMany?: inscricoesUpdateManyWithWhereWithoutUsuariosInput | inscricoesUpdateManyWithWhereWithoutUsuariosInput[]
    deleteMany?: inscricoesScalarWhereInput | inscricoesScalarWhereInput[]
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedDateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type NestedStringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type NestedIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type NestedFloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[] | ListFloatFieldRefInput<$PrismaModel>
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel>
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedDateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type NestedStringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type NestedIntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type NestedBoolNullableFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel> | null
    not?: NestedBoolNullableFilter<$PrismaModel> | boolean | null
  }

  export type NestedDateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type NestedBoolNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel> | null
    not?: NestedBoolNullableWithAggregatesFilter<$PrismaModel> | boolean | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedBoolNullableFilter<$PrismaModel>
    _max?: NestedBoolNullableFilter<$PrismaModel>
  }

  export type NestedDateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type NestedIntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type NestedFloatNullableFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableFilter<$PrismaModel> | number | null
  }

  export type usuariosCreateWithoutEventosInput = {
    nome: string
    email: string
    senha: string
    inscricoes?: inscricoesCreateNestedManyWithoutUsuariosInput
    tipo_perfil: tipo_perfilCreateNestedOneWithoutUsuariosInput
  }

  export type usuariosUncheckedCreateWithoutEventosInput = {
    id_usuario?: number
    nome: string
    email: string
    senha: string
    id_tipo_perfil: string
    inscricoes?: inscricoesUncheckedCreateNestedManyWithoutUsuariosInput
  }

  export type usuariosCreateOrConnectWithoutEventosInput = {
    where: usuariosWhereUniqueInput
    create: XOR<usuariosCreateWithoutEventosInput, usuariosUncheckedCreateWithoutEventosInput>
  }

  export type localCreateWithoutEventosInput = {
    id_local: string
    nome_local: string
    capacidade?: number | null
  }

  export type localUncheckedCreateWithoutEventosInput = {
    id_local: string
    nome_local: string
    capacidade?: number | null
  }

  export type localCreateOrConnectWithoutEventosInput = {
    where: localWhereUniqueInput
    create: XOR<localCreateWithoutEventosInput, localUncheckedCreateWithoutEventosInput>
  }

  export type inscricoesCreateWithoutEventosInput = {
    presenca_entrada?: boolean | null
    horario_entrada?: Date | string | null
    presenca_saida?: boolean | null
    horario_saida?: Date | string | null
    codigo_validacao?: string | null
    data_inscricao?: Date | string | null
    usuarios: usuariosCreateNestedOneWithoutInscricoesInput
  }

  export type inscricoesUncheckedCreateWithoutEventosInput = {
    id_inscricao?: number
    id_aluno: number
    presenca_entrada?: boolean | null
    horario_entrada?: Date | string | null
    presenca_saida?: boolean | null
    horario_saida?: Date | string | null
    codigo_validacao?: string | null
    data_inscricao?: Date | string | null
  }

  export type inscricoesCreateOrConnectWithoutEventosInput = {
    where: inscricoesWhereUniqueInput
    create: XOR<inscricoesCreateWithoutEventosInput, inscricoesUncheckedCreateWithoutEventosInput>
  }

  export type inscricoesCreateManyEventosInputEnvelope = {
    data: inscricoesCreateManyEventosInput | inscricoesCreateManyEventosInput[]
    skipDuplicates?: boolean
  }

  export type usuariosUpsertWithoutEventosInput = {
    update: XOR<usuariosUpdateWithoutEventosInput, usuariosUncheckedUpdateWithoutEventosInput>
    create: XOR<usuariosCreateWithoutEventosInput, usuariosUncheckedCreateWithoutEventosInput>
    where?: usuariosWhereInput
  }

  export type usuariosUpdateToOneWithWhereWithoutEventosInput = {
    where?: usuariosWhereInput
    data: XOR<usuariosUpdateWithoutEventosInput, usuariosUncheckedUpdateWithoutEventosInput>
  }

  export type usuariosUpdateWithoutEventosInput = {
    nome?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    senha?: StringFieldUpdateOperationsInput | string
    inscricoes?: inscricoesUpdateManyWithoutUsuariosNestedInput
    tipo_perfil?: tipo_perfilUpdateOneRequiredWithoutUsuariosNestedInput
  }

  export type usuariosUncheckedUpdateWithoutEventosInput = {
    id_usuario?: IntFieldUpdateOperationsInput | number
    nome?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    senha?: StringFieldUpdateOperationsInput | string
    id_tipo_perfil?: StringFieldUpdateOperationsInput | string
    inscricoes?: inscricoesUncheckedUpdateManyWithoutUsuariosNestedInput
  }

  export type localUpsertWithoutEventosInput = {
    update: XOR<localUpdateWithoutEventosInput, localUncheckedUpdateWithoutEventosInput>
    create: XOR<localCreateWithoutEventosInput, localUncheckedCreateWithoutEventosInput>
    where?: localWhereInput
  }

  export type localUpdateToOneWithWhereWithoutEventosInput = {
    where?: localWhereInput
    data: XOR<localUpdateWithoutEventosInput, localUncheckedUpdateWithoutEventosInput>
  }

  export type localUpdateWithoutEventosInput = {
    id_local?: StringFieldUpdateOperationsInput | string
    nome_local?: StringFieldUpdateOperationsInput | string
    capacidade?: NullableIntFieldUpdateOperationsInput | number | null
  }

  export type localUncheckedUpdateWithoutEventosInput = {
    id_local?: StringFieldUpdateOperationsInput | string
    nome_local?: StringFieldUpdateOperationsInput | string
    capacidade?: NullableIntFieldUpdateOperationsInput | number | null
  }

  export type inscricoesUpsertWithWhereUniqueWithoutEventosInput = {
    where: inscricoesWhereUniqueInput
    update: XOR<inscricoesUpdateWithoutEventosInput, inscricoesUncheckedUpdateWithoutEventosInput>
    create: XOR<inscricoesCreateWithoutEventosInput, inscricoesUncheckedCreateWithoutEventosInput>
  }

  export type inscricoesUpdateWithWhereUniqueWithoutEventosInput = {
    where: inscricoesWhereUniqueInput
    data: XOR<inscricoesUpdateWithoutEventosInput, inscricoesUncheckedUpdateWithoutEventosInput>
  }

  export type inscricoesUpdateManyWithWhereWithoutEventosInput = {
    where: inscricoesScalarWhereInput
    data: XOR<inscricoesUpdateManyMutationInput, inscricoesUncheckedUpdateManyWithoutEventosInput>
  }

  export type inscricoesScalarWhereInput = {
    AND?: inscricoesScalarWhereInput | inscricoesScalarWhereInput[]
    OR?: inscricoesScalarWhereInput[]
    NOT?: inscricoesScalarWhereInput | inscricoesScalarWhereInput[]
    id_inscricao?: IntFilter<"inscricoes"> | number
    id_aluno?: IntFilter<"inscricoes"> | number
    id_evento?: IntFilter<"inscricoes"> | number
    presenca_entrada?: BoolNullableFilter<"inscricoes"> | boolean | null
    horario_entrada?: DateTimeNullableFilter<"inscricoes"> | Date | string | null
    presenca_saida?: BoolNullableFilter<"inscricoes"> | boolean | null
    horario_saida?: DateTimeNullableFilter<"inscricoes"> | Date | string | null
    codigo_validacao?: StringNullableFilter<"inscricoes"> | string | null
    data_inscricao?: DateTimeNullableFilter<"inscricoes"> | Date | string | null
  }

  export type usuariosCreateWithoutInscricoesInput = {
    nome: string
    email: string
    senha: string
    eventos?: eventosCreateNestedManyWithoutUsuariosInput
    tipo_perfil: tipo_perfilCreateNestedOneWithoutUsuariosInput
  }

  export type usuariosUncheckedCreateWithoutInscricoesInput = {
    id_usuario?: number
    nome: string
    email: string
    senha: string
    id_tipo_perfil: string
    eventos?: eventosUncheckedCreateNestedManyWithoutUsuariosInput
  }

  export type usuariosCreateOrConnectWithoutInscricoesInput = {
    where: usuariosWhereUniqueInput
    create: XOR<usuariosCreateWithoutInscricoesInput, usuariosUncheckedCreateWithoutInscricoesInput>
  }

  export type eventosCreateWithoutInscricoesInput = {
    titulo: string
    descricao: string
    palestrante: string
    carga_horaria?: number
    vagas_limite?: number
    data_inicio?: Date | string
    data_fim: Date | string
    hora_inicio: Date | string
    hora_fim: Date | string
    objetivo_pedagogico?: string | null
    usuarios: usuariosCreateNestedOneWithoutEventosInput
    local?: localCreateNestedOneWithoutEventosInput
  }

  export type eventosUncheckedCreateWithoutInscricoesInput = {
    id_evento?: number
    titulo: string
    descricao: string
    palestrante: string
    carga_horaria?: number
    vagas_limite?: number
    data_inicio?: Date | string
    data_fim: Date | string
    hora_inicio: Date | string
    hora_fim: Date | string
    objetivo_pedagogico?: string | null
    id_local?: string | null
    id_usuario: number
  }

  export type eventosCreateOrConnectWithoutInscricoesInput = {
    where: eventosWhereUniqueInput
    create: XOR<eventosCreateWithoutInscricoesInput, eventosUncheckedCreateWithoutInscricoesInput>
  }

  export type usuariosUpsertWithoutInscricoesInput = {
    update: XOR<usuariosUpdateWithoutInscricoesInput, usuariosUncheckedUpdateWithoutInscricoesInput>
    create: XOR<usuariosCreateWithoutInscricoesInput, usuariosUncheckedCreateWithoutInscricoesInput>
    where?: usuariosWhereInput
  }

  export type usuariosUpdateToOneWithWhereWithoutInscricoesInput = {
    where?: usuariosWhereInput
    data: XOR<usuariosUpdateWithoutInscricoesInput, usuariosUncheckedUpdateWithoutInscricoesInput>
  }

  export type usuariosUpdateWithoutInscricoesInput = {
    nome?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    senha?: StringFieldUpdateOperationsInput | string
    eventos?: eventosUpdateManyWithoutUsuariosNestedInput
    tipo_perfil?: tipo_perfilUpdateOneRequiredWithoutUsuariosNestedInput
  }

  export type usuariosUncheckedUpdateWithoutInscricoesInput = {
    id_usuario?: IntFieldUpdateOperationsInput | number
    nome?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    senha?: StringFieldUpdateOperationsInput | string
    id_tipo_perfil?: StringFieldUpdateOperationsInput | string
    eventos?: eventosUncheckedUpdateManyWithoutUsuariosNestedInput
  }

  export type eventosUpsertWithoutInscricoesInput = {
    update: XOR<eventosUpdateWithoutInscricoesInput, eventosUncheckedUpdateWithoutInscricoesInput>
    create: XOR<eventosCreateWithoutInscricoesInput, eventosUncheckedCreateWithoutInscricoesInput>
    where?: eventosWhereInput
  }

  export type eventosUpdateToOneWithWhereWithoutInscricoesInput = {
    where?: eventosWhereInput
    data: XOR<eventosUpdateWithoutInscricoesInput, eventosUncheckedUpdateWithoutInscricoesInput>
  }

  export type eventosUpdateWithoutInscricoesInput = {
    titulo?: StringFieldUpdateOperationsInput | string
    descricao?: StringFieldUpdateOperationsInput | string
    palestrante?: StringFieldUpdateOperationsInput | string
    carga_horaria?: IntFieldUpdateOperationsInput | number
    vagas_limite?: IntFieldUpdateOperationsInput | number
    data_inicio?: DateTimeFieldUpdateOperationsInput | Date | string
    data_fim?: DateTimeFieldUpdateOperationsInput | Date | string
    hora_inicio?: DateTimeFieldUpdateOperationsInput | Date | string
    hora_fim?: DateTimeFieldUpdateOperationsInput | Date | string
    objetivo_pedagogico?: NullableStringFieldUpdateOperationsInput | string | null
    usuarios?: usuariosUpdateOneRequiredWithoutEventosNestedInput
    local?: localUpdateOneWithoutEventosNestedInput
  }

  export type eventosUncheckedUpdateWithoutInscricoesInput = {
    id_evento?: IntFieldUpdateOperationsInput | number
    titulo?: StringFieldUpdateOperationsInput | string
    descricao?: StringFieldUpdateOperationsInput | string
    palestrante?: StringFieldUpdateOperationsInput | string
    carga_horaria?: IntFieldUpdateOperationsInput | number
    vagas_limite?: IntFieldUpdateOperationsInput | number
    data_inicio?: DateTimeFieldUpdateOperationsInput | Date | string
    data_fim?: DateTimeFieldUpdateOperationsInput | Date | string
    hora_inicio?: DateTimeFieldUpdateOperationsInput | Date | string
    hora_fim?: DateTimeFieldUpdateOperationsInput | Date | string
    objetivo_pedagogico?: NullableStringFieldUpdateOperationsInput | string | null
    id_local?: NullableStringFieldUpdateOperationsInput | string | null
    id_usuario?: IntFieldUpdateOperationsInput | number
  }

  export type eventosCreateWithoutLocalInput = {
    titulo: string
    descricao: string
    palestrante: string
    carga_horaria?: number
    vagas_limite?: number
    data_inicio?: Date | string
    data_fim: Date | string
    hora_inicio: Date | string
    hora_fim: Date | string
    objetivo_pedagogico?: string | null
    usuarios: usuariosCreateNestedOneWithoutEventosInput
    inscricoes?: inscricoesCreateNestedManyWithoutEventosInput
  }

  export type eventosUncheckedCreateWithoutLocalInput = {
    id_evento?: number
    titulo: string
    descricao: string
    palestrante: string
    carga_horaria?: number
    vagas_limite?: number
    data_inicio?: Date | string
    data_fim: Date | string
    hora_inicio: Date | string
    hora_fim: Date | string
    objetivo_pedagogico?: string | null
    id_usuario: number
    inscricoes?: inscricoesUncheckedCreateNestedManyWithoutEventosInput
  }

  export type eventosCreateOrConnectWithoutLocalInput = {
    where: eventosWhereUniqueInput
    create: XOR<eventosCreateWithoutLocalInput, eventosUncheckedCreateWithoutLocalInput>
  }

  export type eventosCreateManyLocalInputEnvelope = {
    data: eventosCreateManyLocalInput | eventosCreateManyLocalInput[]
    skipDuplicates?: boolean
  }

  export type eventosUpsertWithWhereUniqueWithoutLocalInput = {
    where: eventosWhereUniqueInput
    update: XOR<eventosUpdateWithoutLocalInput, eventosUncheckedUpdateWithoutLocalInput>
    create: XOR<eventosCreateWithoutLocalInput, eventosUncheckedCreateWithoutLocalInput>
  }

  export type eventosUpdateWithWhereUniqueWithoutLocalInput = {
    where: eventosWhereUniqueInput
    data: XOR<eventosUpdateWithoutLocalInput, eventosUncheckedUpdateWithoutLocalInput>
  }

  export type eventosUpdateManyWithWhereWithoutLocalInput = {
    where: eventosScalarWhereInput
    data: XOR<eventosUpdateManyMutationInput, eventosUncheckedUpdateManyWithoutLocalInput>
  }

  export type eventosScalarWhereInput = {
    AND?: eventosScalarWhereInput | eventosScalarWhereInput[]
    OR?: eventosScalarWhereInput[]
    NOT?: eventosScalarWhereInput | eventosScalarWhereInput[]
    id_evento?: IntFilter<"eventos"> | number
    titulo?: StringFilter<"eventos"> | string
    descricao?: StringFilter<"eventos"> | string
    palestrante?: StringFilter<"eventos"> | string
    carga_horaria?: IntFilter<"eventos"> | number
    vagas_limite?: IntFilter<"eventos"> | number
    data_inicio?: DateTimeFilter<"eventos"> | Date | string
    data_fim?: DateTimeFilter<"eventos"> | Date | string
    hora_inicio?: DateTimeFilter<"eventos"> | Date | string
    hora_fim?: DateTimeFilter<"eventos"> | Date | string
    objetivo_pedagogico?: StringNullableFilter<"eventos"> | string | null
    id_local?: StringNullableFilter<"eventos"> | string | null
    id_usuario?: IntFilter<"eventos"> | number
  }

  export type usuariosCreateWithoutTipo_perfilInput = {
    nome: string
    email: string
    senha: string
    eventos?: eventosCreateNestedManyWithoutUsuariosInput
    inscricoes?: inscricoesCreateNestedManyWithoutUsuariosInput
  }

  export type usuariosUncheckedCreateWithoutTipo_perfilInput = {
    id_usuario?: number
    nome: string
    email: string
    senha: string
    eventos?: eventosUncheckedCreateNestedManyWithoutUsuariosInput
    inscricoes?: inscricoesUncheckedCreateNestedManyWithoutUsuariosInput
  }

  export type usuariosCreateOrConnectWithoutTipo_perfilInput = {
    where: usuariosWhereUniqueInput
    create: XOR<usuariosCreateWithoutTipo_perfilInput, usuariosUncheckedCreateWithoutTipo_perfilInput>
  }

  export type usuariosCreateManyTipo_perfilInputEnvelope = {
    data: usuariosCreateManyTipo_perfilInput | usuariosCreateManyTipo_perfilInput[]
    skipDuplicates?: boolean
  }

  export type usuariosUpsertWithWhereUniqueWithoutTipo_perfilInput = {
    where: usuariosWhereUniqueInput
    update: XOR<usuariosUpdateWithoutTipo_perfilInput, usuariosUncheckedUpdateWithoutTipo_perfilInput>
    create: XOR<usuariosCreateWithoutTipo_perfilInput, usuariosUncheckedCreateWithoutTipo_perfilInput>
  }

  export type usuariosUpdateWithWhereUniqueWithoutTipo_perfilInput = {
    where: usuariosWhereUniqueInput
    data: XOR<usuariosUpdateWithoutTipo_perfilInput, usuariosUncheckedUpdateWithoutTipo_perfilInput>
  }

  export type usuariosUpdateManyWithWhereWithoutTipo_perfilInput = {
    where: usuariosScalarWhereInput
    data: XOR<usuariosUpdateManyMutationInput, usuariosUncheckedUpdateManyWithoutTipo_perfilInput>
  }

  export type usuariosScalarWhereInput = {
    AND?: usuariosScalarWhereInput | usuariosScalarWhereInput[]
    OR?: usuariosScalarWhereInput[]
    NOT?: usuariosScalarWhereInput | usuariosScalarWhereInput[]
    id_usuario?: IntFilter<"usuarios"> | number
    nome?: StringFilter<"usuarios"> | string
    email?: StringFilter<"usuarios"> | string
    senha?: StringFilter<"usuarios"> | string
    id_tipo_perfil?: StringFilter<"usuarios"> | string
  }

  export type eventosCreateWithoutUsuariosInput = {
    titulo: string
    descricao: string
    palestrante: string
    carga_horaria?: number
    vagas_limite?: number
    data_inicio?: Date | string
    data_fim: Date | string
    hora_inicio: Date | string
    hora_fim: Date | string
    objetivo_pedagogico?: string | null
    local?: localCreateNestedOneWithoutEventosInput
    inscricoes?: inscricoesCreateNestedManyWithoutEventosInput
  }

  export type eventosUncheckedCreateWithoutUsuariosInput = {
    id_evento?: number
    titulo: string
    descricao: string
    palestrante: string
    carga_horaria?: number
    vagas_limite?: number
    data_inicio?: Date | string
    data_fim: Date | string
    hora_inicio: Date | string
    hora_fim: Date | string
    objetivo_pedagogico?: string | null
    id_local?: string | null
    inscricoes?: inscricoesUncheckedCreateNestedManyWithoutEventosInput
  }

  export type eventosCreateOrConnectWithoutUsuariosInput = {
    where: eventosWhereUniqueInput
    create: XOR<eventosCreateWithoutUsuariosInput, eventosUncheckedCreateWithoutUsuariosInput>
  }

  export type eventosCreateManyUsuariosInputEnvelope = {
    data: eventosCreateManyUsuariosInput | eventosCreateManyUsuariosInput[]
    skipDuplicates?: boolean
  }

  export type inscricoesCreateWithoutUsuariosInput = {
    presenca_entrada?: boolean | null
    horario_entrada?: Date | string | null
    presenca_saida?: boolean | null
    horario_saida?: Date | string | null
    codigo_validacao?: string | null
    data_inscricao?: Date | string | null
    eventos: eventosCreateNestedOneWithoutInscricoesInput
  }

  export type inscricoesUncheckedCreateWithoutUsuariosInput = {
    id_inscricao?: number
    id_evento: number
    presenca_entrada?: boolean | null
    horario_entrada?: Date | string | null
    presenca_saida?: boolean | null
    horario_saida?: Date | string | null
    codigo_validacao?: string | null
    data_inscricao?: Date | string | null
  }

  export type inscricoesCreateOrConnectWithoutUsuariosInput = {
    where: inscricoesWhereUniqueInput
    create: XOR<inscricoesCreateWithoutUsuariosInput, inscricoesUncheckedCreateWithoutUsuariosInput>
  }

  export type inscricoesCreateManyUsuariosInputEnvelope = {
    data: inscricoesCreateManyUsuariosInput | inscricoesCreateManyUsuariosInput[]
    skipDuplicates?: boolean
  }

  export type tipo_perfilCreateWithoutUsuariosInput = {
    id_tipo_perfil: string
    descricao: string
  }

  export type tipo_perfilUncheckedCreateWithoutUsuariosInput = {
    id_tipo_perfil: string
    descricao: string
  }

  export type tipo_perfilCreateOrConnectWithoutUsuariosInput = {
    where: tipo_perfilWhereUniqueInput
    create: XOR<tipo_perfilCreateWithoutUsuariosInput, tipo_perfilUncheckedCreateWithoutUsuariosInput>
  }

  export type eventosUpsertWithWhereUniqueWithoutUsuariosInput = {
    where: eventosWhereUniqueInput
    update: XOR<eventosUpdateWithoutUsuariosInput, eventosUncheckedUpdateWithoutUsuariosInput>
    create: XOR<eventosCreateWithoutUsuariosInput, eventosUncheckedCreateWithoutUsuariosInput>
  }

  export type eventosUpdateWithWhereUniqueWithoutUsuariosInput = {
    where: eventosWhereUniqueInput
    data: XOR<eventosUpdateWithoutUsuariosInput, eventosUncheckedUpdateWithoutUsuariosInput>
  }

  export type eventosUpdateManyWithWhereWithoutUsuariosInput = {
    where: eventosScalarWhereInput
    data: XOR<eventosUpdateManyMutationInput, eventosUncheckedUpdateManyWithoutUsuariosInput>
  }

  export type inscricoesUpsertWithWhereUniqueWithoutUsuariosInput = {
    where: inscricoesWhereUniqueInput
    update: XOR<inscricoesUpdateWithoutUsuariosInput, inscricoesUncheckedUpdateWithoutUsuariosInput>
    create: XOR<inscricoesCreateWithoutUsuariosInput, inscricoesUncheckedCreateWithoutUsuariosInput>
  }

  export type inscricoesUpdateWithWhereUniqueWithoutUsuariosInput = {
    where: inscricoesWhereUniqueInput
    data: XOR<inscricoesUpdateWithoutUsuariosInput, inscricoesUncheckedUpdateWithoutUsuariosInput>
  }

  export type inscricoesUpdateManyWithWhereWithoutUsuariosInput = {
    where: inscricoesScalarWhereInput
    data: XOR<inscricoesUpdateManyMutationInput, inscricoesUncheckedUpdateManyWithoutUsuariosInput>
  }

  export type tipo_perfilUpsertWithoutUsuariosInput = {
    update: XOR<tipo_perfilUpdateWithoutUsuariosInput, tipo_perfilUncheckedUpdateWithoutUsuariosInput>
    create: XOR<tipo_perfilCreateWithoutUsuariosInput, tipo_perfilUncheckedCreateWithoutUsuariosInput>
    where?: tipo_perfilWhereInput
  }

  export type tipo_perfilUpdateToOneWithWhereWithoutUsuariosInput = {
    where?: tipo_perfilWhereInput
    data: XOR<tipo_perfilUpdateWithoutUsuariosInput, tipo_perfilUncheckedUpdateWithoutUsuariosInput>
  }

  export type tipo_perfilUpdateWithoutUsuariosInput = {
    id_tipo_perfil?: StringFieldUpdateOperationsInput | string
    descricao?: StringFieldUpdateOperationsInput | string
  }

  export type tipo_perfilUncheckedUpdateWithoutUsuariosInput = {
    id_tipo_perfil?: StringFieldUpdateOperationsInput | string
    descricao?: StringFieldUpdateOperationsInput | string
  }

  export type inscricoesCreateManyEventosInput = {
    id_inscricao?: number
    id_aluno: number
    presenca_entrada?: boolean | null
    horario_entrada?: Date | string | null
    presenca_saida?: boolean | null
    horario_saida?: Date | string | null
    codigo_validacao?: string | null
    data_inscricao?: Date | string | null
  }

  export type inscricoesUpdateWithoutEventosInput = {
    presenca_entrada?: NullableBoolFieldUpdateOperationsInput | boolean | null
    horario_entrada?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    presenca_saida?: NullableBoolFieldUpdateOperationsInput | boolean | null
    horario_saida?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    codigo_validacao?: NullableStringFieldUpdateOperationsInput | string | null
    data_inscricao?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    usuarios?: usuariosUpdateOneRequiredWithoutInscricoesNestedInput
  }

  export type inscricoesUncheckedUpdateWithoutEventosInput = {
    id_inscricao?: IntFieldUpdateOperationsInput | number
    id_aluno?: IntFieldUpdateOperationsInput | number
    presenca_entrada?: NullableBoolFieldUpdateOperationsInput | boolean | null
    horario_entrada?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    presenca_saida?: NullableBoolFieldUpdateOperationsInput | boolean | null
    horario_saida?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    codigo_validacao?: NullableStringFieldUpdateOperationsInput | string | null
    data_inscricao?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type inscricoesUncheckedUpdateManyWithoutEventosInput = {
    id_inscricao?: IntFieldUpdateOperationsInput | number
    id_aluno?: IntFieldUpdateOperationsInput | number
    presenca_entrada?: NullableBoolFieldUpdateOperationsInput | boolean | null
    horario_entrada?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    presenca_saida?: NullableBoolFieldUpdateOperationsInput | boolean | null
    horario_saida?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    codigo_validacao?: NullableStringFieldUpdateOperationsInput | string | null
    data_inscricao?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type eventosCreateManyLocalInput = {
    id_evento?: number
    titulo: string
    descricao: string
    palestrante: string
    carga_horaria?: number
    vagas_limite?: number
    data_inicio?: Date | string
    data_fim: Date | string
    hora_inicio: Date | string
    hora_fim: Date | string
    objetivo_pedagogico?: string | null
    id_usuario: number
  }

  export type eventosUpdateWithoutLocalInput = {
    titulo?: StringFieldUpdateOperationsInput | string
    descricao?: StringFieldUpdateOperationsInput | string
    palestrante?: StringFieldUpdateOperationsInput | string
    carga_horaria?: IntFieldUpdateOperationsInput | number
    vagas_limite?: IntFieldUpdateOperationsInput | number
    data_inicio?: DateTimeFieldUpdateOperationsInput | Date | string
    data_fim?: DateTimeFieldUpdateOperationsInput | Date | string
    hora_inicio?: DateTimeFieldUpdateOperationsInput | Date | string
    hora_fim?: DateTimeFieldUpdateOperationsInput | Date | string
    objetivo_pedagogico?: NullableStringFieldUpdateOperationsInput | string | null
    usuarios?: usuariosUpdateOneRequiredWithoutEventosNestedInput
    inscricoes?: inscricoesUpdateManyWithoutEventosNestedInput
  }

  export type eventosUncheckedUpdateWithoutLocalInput = {
    id_evento?: IntFieldUpdateOperationsInput | number
    titulo?: StringFieldUpdateOperationsInput | string
    descricao?: StringFieldUpdateOperationsInput | string
    palestrante?: StringFieldUpdateOperationsInput | string
    carga_horaria?: IntFieldUpdateOperationsInput | number
    vagas_limite?: IntFieldUpdateOperationsInput | number
    data_inicio?: DateTimeFieldUpdateOperationsInput | Date | string
    data_fim?: DateTimeFieldUpdateOperationsInput | Date | string
    hora_inicio?: DateTimeFieldUpdateOperationsInput | Date | string
    hora_fim?: DateTimeFieldUpdateOperationsInput | Date | string
    objetivo_pedagogico?: NullableStringFieldUpdateOperationsInput | string | null
    id_usuario?: IntFieldUpdateOperationsInput | number
    inscricoes?: inscricoesUncheckedUpdateManyWithoutEventosNestedInput
  }

  export type eventosUncheckedUpdateManyWithoutLocalInput = {
    id_evento?: IntFieldUpdateOperationsInput | number
    titulo?: StringFieldUpdateOperationsInput | string
    descricao?: StringFieldUpdateOperationsInput | string
    palestrante?: StringFieldUpdateOperationsInput | string
    carga_horaria?: IntFieldUpdateOperationsInput | number
    vagas_limite?: IntFieldUpdateOperationsInput | number
    data_inicio?: DateTimeFieldUpdateOperationsInput | Date | string
    data_fim?: DateTimeFieldUpdateOperationsInput | Date | string
    hora_inicio?: DateTimeFieldUpdateOperationsInput | Date | string
    hora_fim?: DateTimeFieldUpdateOperationsInput | Date | string
    objetivo_pedagogico?: NullableStringFieldUpdateOperationsInput | string | null
    id_usuario?: IntFieldUpdateOperationsInput | number
  }

  export type usuariosCreateManyTipo_perfilInput = {
    id_usuario?: number
    nome: string
    email: string
    senha: string
  }

  export type usuariosUpdateWithoutTipo_perfilInput = {
    nome?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    senha?: StringFieldUpdateOperationsInput | string
    eventos?: eventosUpdateManyWithoutUsuariosNestedInput
    inscricoes?: inscricoesUpdateManyWithoutUsuariosNestedInput
  }

  export type usuariosUncheckedUpdateWithoutTipo_perfilInput = {
    id_usuario?: IntFieldUpdateOperationsInput | number
    nome?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    senha?: StringFieldUpdateOperationsInput | string
    eventos?: eventosUncheckedUpdateManyWithoutUsuariosNestedInput
    inscricoes?: inscricoesUncheckedUpdateManyWithoutUsuariosNestedInput
  }

  export type usuariosUncheckedUpdateManyWithoutTipo_perfilInput = {
    id_usuario?: IntFieldUpdateOperationsInput | number
    nome?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    senha?: StringFieldUpdateOperationsInput | string
  }

  export type eventosCreateManyUsuariosInput = {
    id_evento?: number
    titulo: string
    descricao: string
    palestrante: string
    carga_horaria?: number
    vagas_limite?: number
    data_inicio?: Date | string
    data_fim: Date | string
    hora_inicio: Date | string
    hora_fim: Date | string
    objetivo_pedagogico?: string | null
    id_local?: string | null
  }

  export type inscricoesCreateManyUsuariosInput = {
    id_inscricao?: number
    id_evento: number
    presenca_entrada?: boolean | null
    horario_entrada?: Date | string | null
    presenca_saida?: boolean | null
    horario_saida?: Date | string | null
    codigo_validacao?: string | null
    data_inscricao?: Date | string | null
  }

  export type eventosUpdateWithoutUsuariosInput = {
    titulo?: StringFieldUpdateOperationsInput | string
    descricao?: StringFieldUpdateOperationsInput | string
    palestrante?: StringFieldUpdateOperationsInput | string
    carga_horaria?: IntFieldUpdateOperationsInput | number
    vagas_limite?: IntFieldUpdateOperationsInput | number
    data_inicio?: DateTimeFieldUpdateOperationsInput | Date | string
    data_fim?: DateTimeFieldUpdateOperationsInput | Date | string
    hora_inicio?: DateTimeFieldUpdateOperationsInput | Date | string
    hora_fim?: DateTimeFieldUpdateOperationsInput | Date | string
    objetivo_pedagogico?: NullableStringFieldUpdateOperationsInput | string | null
    local?: localUpdateOneWithoutEventosNestedInput
    inscricoes?: inscricoesUpdateManyWithoutEventosNestedInput
  }

  export type eventosUncheckedUpdateWithoutUsuariosInput = {
    id_evento?: IntFieldUpdateOperationsInput | number
    titulo?: StringFieldUpdateOperationsInput | string
    descricao?: StringFieldUpdateOperationsInput | string
    palestrante?: StringFieldUpdateOperationsInput | string
    carga_horaria?: IntFieldUpdateOperationsInput | number
    vagas_limite?: IntFieldUpdateOperationsInput | number
    data_inicio?: DateTimeFieldUpdateOperationsInput | Date | string
    data_fim?: DateTimeFieldUpdateOperationsInput | Date | string
    hora_inicio?: DateTimeFieldUpdateOperationsInput | Date | string
    hora_fim?: DateTimeFieldUpdateOperationsInput | Date | string
    objetivo_pedagogico?: NullableStringFieldUpdateOperationsInput | string | null
    id_local?: NullableStringFieldUpdateOperationsInput | string | null
    inscricoes?: inscricoesUncheckedUpdateManyWithoutEventosNestedInput
  }

  export type eventosUncheckedUpdateManyWithoutUsuariosInput = {
    id_evento?: IntFieldUpdateOperationsInput | number
    titulo?: StringFieldUpdateOperationsInput | string
    descricao?: StringFieldUpdateOperationsInput | string
    palestrante?: StringFieldUpdateOperationsInput | string
    carga_horaria?: IntFieldUpdateOperationsInput | number
    vagas_limite?: IntFieldUpdateOperationsInput | number
    data_inicio?: DateTimeFieldUpdateOperationsInput | Date | string
    data_fim?: DateTimeFieldUpdateOperationsInput | Date | string
    hora_inicio?: DateTimeFieldUpdateOperationsInput | Date | string
    hora_fim?: DateTimeFieldUpdateOperationsInput | Date | string
    objetivo_pedagogico?: NullableStringFieldUpdateOperationsInput | string | null
    id_local?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type inscricoesUpdateWithoutUsuariosInput = {
    presenca_entrada?: NullableBoolFieldUpdateOperationsInput | boolean | null
    horario_entrada?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    presenca_saida?: NullableBoolFieldUpdateOperationsInput | boolean | null
    horario_saida?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    codigo_validacao?: NullableStringFieldUpdateOperationsInput | string | null
    data_inscricao?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    eventos?: eventosUpdateOneRequiredWithoutInscricoesNestedInput
  }

  export type inscricoesUncheckedUpdateWithoutUsuariosInput = {
    id_inscricao?: IntFieldUpdateOperationsInput | number
    id_evento?: IntFieldUpdateOperationsInput | number
    presenca_entrada?: NullableBoolFieldUpdateOperationsInput | boolean | null
    horario_entrada?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    presenca_saida?: NullableBoolFieldUpdateOperationsInput | boolean | null
    horario_saida?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    codigo_validacao?: NullableStringFieldUpdateOperationsInput | string | null
    data_inscricao?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }

  export type inscricoesUncheckedUpdateManyWithoutUsuariosInput = {
    id_inscricao?: IntFieldUpdateOperationsInput | number
    id_evento?: IntFieldUpdateOperationsInput | number
    presenca_entrada?: NullableBoolFieldUpdateOperationsInput | boolean | null
    horario_entrada?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    presenca_saida?: NullableBoolFieldUpdateOperationsInput | boolean | null
    horario_saida?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    codigo_validacao?: NullableStringFieldUpdateOperationsInput | string | null
    data_inscricao?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
  }



  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}