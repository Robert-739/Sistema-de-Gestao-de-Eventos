import Link from "next/link"
import { LayoutDashboard, CalendarPlus, QrCode, LogOut, GraduationCap } from "lucide-react"
import { prisma } from "@/lib/prisma"
import { cookies } from "next/headers"
import { redirect } from "next/navigation"

export default async function CoordenadorLayout({
  children,
}: {
  children: React.ReactNode
}) {
  // 1. Acessa os cookies de forma assíncrona no servidor
  const cookieStore = await cookies()
  const usuarioId = cookieStore.get("usuario_id")?.value || ""

  // 2. Busca o nome e o e-mail real do coordenador no banco usando o ID do cookie
  const usuario = await prisma.usuarios.findUnique({
    where: {
      id_usuario: Number(usuarioId) || 0,
    },
    select: {
      nome: true,
      email: true,
    }
  })

  const nomeUsuario = usuario?.nome || "Coordenador"
  const emailUsuario = usuario?.email || "coordenador@einstein.com"

  const obtenerIniciais = (nome: string) => {
    const partes = nome.trim().split(" ")
    if (partes.length >= 2) {
      return `${partes[0][0]}${partes[partes.length - 1][0]}`.toUpperCase()
    }
    return partes[0] ? partes[0][0].toUpperCase() : "CO"
  }

  const iniciais = obtenerIniciais(nomeUsuario)

  // Server Action compartilhada para o logout
  async function fazerLogout() {
    "use server"
    const cookieStore = await cookies()
    cookieStore.delete("usuario_id")
    cookieStore.delete("usuario_perfil")
    redirect("/login")
  }

  return (
    <div className="flex min-h-screen bg-gray-50 text-black">
      
      {/* SIDEBAR FIXA */}
      <aside className="w-64 bg-slate-900 text-white flex flex-col justify-between p-5 border-r border-slate-800 shrink-0 hidden md:flex">
        <div>
          <div className="flex items-center gap-2.5 px-2 py-4 border-b border-slate-800 mb-6">
            <div className="bg-yellow-500 p-1.5 rounded-lg text-white">
              <GraduationCap size={20} />
            </div>
            <span className="font-bold text-sm tracking-wide bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
              CheckIn Acadêmico
            </span>
          </div>

          <nav className="flex flex-col gap-1">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider px-2 mb-2">
              Navegação
            </span>

            <Link 
              href="/dashboard/coordenador" 
              className="flex items-center gap-3 px-3 py-2.5 text-xs font-semibold rounded-xl text-slate-300 hover:bg-slate-800 hover:text-white transition-all group"
            >
              <LayoutDashboard size={16} className="text-slate-400 group-hover:text-yellow-500 transition-colors" />
              Painel Geral
            </Link>

            <Link 
              href="/dashboard/coordenador/novo-evento" 
              className="flex items-center gap-3 px-3 py-2.5 text-xs font-semibold rounded-xl text-slate-300 hover:bg-slate-800 hover:text-white transition-all group"
            >
              <CalendarPlus size={16} className="text-slate-400 group-hover:text-yellow-500 transition-colors" />
              Criar Novo Evento
            </Link>

            <Link 
              href="/dashboard/coordenador/scanner" 
              className="flex items-center gap-3 px-3 py-2.5 text-xs font-semibold rounded-xl text-slate-300 hover:bg-slate-800 hover:text-white transition-all group"
            >
              <QrCode size={16} className="text-slate-400 group-hover:text-yellow-500 transition-colors" />
              Escanear QR Code
            </Link>
          </nav>
        </div>

        <div className="border-t border-slate-800 pt-4 flex flex-col gap-3">
          <div className="flex items-center gap-2.5 px-2">
            <div className="w-8 h-8 rounded-full bg-yellow-500 flex items-center justify-center text-xs font-bold text-white uppercase shrink-0">
              {iniciais}
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-xs font-bold truncate text-slate-200" title={nomeUsuario}>
                {nomeUsuario}
              </span>
              <span className="text-[10px] text-slate-400 truncate" title={emailUsuario}>
                {emailUsuario}
              </span>
            </div>
          </div>

          <form action={fazerLogout}>
            <button 
              type="submit"
              className="w-full flex items-center gap-3 px-3 py-2 text-xs font-semibold text-red-400 hover:bg-red-500/10 rounded-xl transition-all text-left"
            >
              <LogOut size={16} />
              Sair do Sistema
            </button>
          </form>
        </div>
      </aside>

      {/* CONTEÚDO PRINCIPAL */}
      <main className="flex-1 overflow-y-auto max-h-screen">
        {/* Topbar para Mobile */}
        <header className="bg-slate-900 text-white p-4 flex items-center justify-between md:hidden shadow-md">
          <div className="flex items-center gap-2">
            <GraduationCap size={18} className="text-blue-500" />
            <span className="font-bold text-xs">CheckIn</span>
          </div>
          <div className="flex items-center gap-3 text-xs font-semibold">
            <Link href="/dashboard/coordenador" className="text-slate-300 hover:text-white">Painel</Link>
            <Link href="/dashboard/coordenador/scanner" className="bg-blue-600 px-2 py-0.5 rounded-md text-[11px] text-white">Scanner</Link>
            
            {/* BOTÃO SAIR NO CELULAR */}
            <form action={fazerLogout}>
              <button type="submit" className="text-red-400 hover:text-red-500 flex items-center gap-0.5 ml-1">
                <LogOut size={13} /> Sair
              </button>
            </form>
          </div>
        </header>

        <div className="w-full">
          {children}
        </div>
      </main>

    </div>
  )
}